import 'package:flutter_test/flutter_test.dart';
import 'package:groot/core/errors.dart';
import 'package:groot/models/break_event.dart';
import 'package:groot/models/calc_rules.dart';
import 'package:groot/models/downtime_event.dart';
import 'package:groot/models/schedule_entry.dart';
import 'package:groot/models/schedule_report.dart';
import 'package:groot/models/time_period.dart';
import 'package:groot/models/user.dart';
import 'package:groot/services/time_calculation_engine.dart';

int hm(int h, [int m = 0]) => h * 60 + m;

List<User> makeUsers(List<String> names) {
  return <User>[
    for (int i = 0; i < names.length; i++)
      User(id: 'u${i + 1}', name: names[i]),
  ];
}

final List<String> names4 = <String>['أحمد', 'محمد', 'علي', 'خالد'];

BreakEvent prayer(String id, String name, int start, int dur) =>
    BreakEvent.prayer(
      id: id,
      name: name,
      startMinuteOfDay: start,
      durationMinutes: dur,
    );

BreakEvent rest(String id, String name, int start, int dur) => BreakEvent.rest(
      id: id,
      name: name,
      startMinuteOfDay: start,
      durationMinutes: dur,
    );

DowntimeEvent down(String id, int start, int dur, [String? desc]) =>
    DowntimeEvent(
      id: id,
      dateKey: '2026-01-01',
      startMinuteOfDay: start,
      durationMinutes: dur,
      description: desc,
    );

ScheduleReport run({
  required int start,
  required int end,
  required List<String> users,
  List<BreakEvent> breaks = const <BreakEvent>[],
  List<DowntimeEvent> downtimes = const <DowntimeEvent>[],
  CalcRules rules = const CalcRules(breakPolicy: BreakPolicy.extendSchedule),
}) {
  return TimeCalculationEngine.compute(
    ScheduleInput(
      period: TimePeriod(startMinuteOfDay: start, endMinuteOfDay: end),
      users: makeUsers(users),
      breaks: breaks,
      downtimes: downtimes,
      rules: rules,
    ),
  );
}

/// فحص التوافق الرياضي: لا دقيقة تُفقد ولا دقيقة تُخلق من العدم.
void expectConsistent(ScheduleReport r) {
  final ScheduleSummary s = r.summary;
  expect(
    s.spanMinutes,
    s.operatingMinutes + s.prayerMinutes + s.restMinutes + s.downtimeMinutes,
    reason: 'امتداد الجدول يجب أن يساوي التشغيل + التوقفات + الأعطال',
  );
  expect(
    s.operatingMinutes,
    s.plannedOperatingMinutes - s.deductedLostMinutes,
    reason: 'التشغيل الفعلي = المخطط - المخصوم بسبب الأعطال',
  );

  // الخط الزمني متصل بلا فجوات ولا تداخل.
  int cursor = r.scheduleStartMinute;
  for (final TimelineSegment seg in r.timeline) {
    expect(seg.startMinute, cursor, reason: 'يوجد فجوة أو تداخل في الخط الزمني');
    expect(seg.endMinute > seg.startMinute, isTrue);
    cursor = seg.endMinute;
  }
  expect(cursor, r.scheduleEndMinute);

  // مجموع تشغيل المستخدمين = إجمالي التشغيل.
  int sum = 0;
  for (final ScheduleEntry e in r.entries) {
    sum += e.operatingMinutes;
  }
  expect(sum, s.operatingMinutes);
}

void main() {
  group('Test 1 — 13:00→21:00، 4 مستخدمين، بدون توقف', () {
    test('قسمة متساوية وبداية ونهاية دقيقة', () {
      final ScheduleReport r =
          run(start: hm(13), end: hm(21), users: names4);
      expect(r.summary.periodMinutes, 480);
      expect(r.summary.spanMinutes, 480);
      expect(r.scheduleEndMinute, hm(21));
      for (final ScheduleEntry e in r.entries) {
        expect(e.operatingMinutes, 120);
        expect(e.plannedShareMinutes, 120);
      }
      expect(r.entries[0].turnStartMinute, hm(13));
      expect(r.entries[0].turnEndMinute, hm(15));
      expect(r.entries[3].turnStartMinute, hm(19));
      expect(r.entries[3].turnEndMinute, hm(21));
      expectConsistent(r);
    });
  });

  group('Test 2 — 13:00→05:00، 4 مستخدمين، بدون توقف', () {
    test('عبور منتصف الليل: 16 ساعة = 960 دقيقة', () {
      final ScheduleReport r = run(start: hm(13), end: hm(5), users: names4);
      expect(r.summary.periodMinutes, 960);
      expect(r.summary.spanMinutes, 960);
      expect(r.scheduleEndMinute, 1740); // 05:00 في اليوم التالي
      for (final ScheduleEntry e in r.entries) {
        expect(e.operatingMinutes, 240);
      }
      expect(r.entries[2].turnStartMinute, 1260); // 21:00
      expect(r.entries[3].turnStartMinute, 1500); // 01:00
      expect(r.entries[3].turnEndMinute, 1740); // 05:00
      expectConsistent(r);
    });
  });

  group('Test 3 — صلاة واحدة', () {
    test('التوقف لا يُخصم من الحصة ويزحزح ما بعده (مثال البند 12)', () {
      final ScheduleReport r = run(
        start: hm(13),
        end: hm(5),
        users: names4,
        breaks: <BreakEvent>[prayer('asr', 'العصر', hm(15), 25)],
      );
      // 13:00→15:00 تشغيل، 15:00→15:25 صلاة، 15:25→17:25 تشغيل
      expect(r.timeline[0].type, SegmentType.operating);
      expect(r.timeline[0].startMinute, hm(13));
      expect(r.timeline[0].endMinute, hm(15));
      expect(r.timeline[1].type, SegmentType.prayer);
      expect(r.timeline[1].endMinute, hm(15, 25));
      expect(r.timeline[2].endMinute, hm(17, 25));

      expect(r.entries[0].operatingMinutes, 240);
      expect(r.entries[0].prayerMinutes, 25);
      expect(r.entries[0].turnEndMinute, hm(17, 25));
      expect(r.summary.spanMinutes, 985);
      expect(r.summary.operatingMinutes, 960);
      expect(r.overtimeMinutes, 25);
      expectConsistent(r);
    });
  });

  group('Test 4 — عدة صلوات وراحة', () {
    test('كل مستخدم يحتفظ بحصته كاملة والجدول يمتد', () {
      final ScheduleReport r = run(
        start: hm(13),
        end: hm(5),
        users: names4,
        breaks: <BreakEvent>[
          prayer('asr', 'العصر', hm(15), 25),
          prayer('mg', 'المغرب', hm(18), 45),
          prayer('is', 'العشاء', hm(20), 30),
          rest('rs', 'الراحة', hm(23), 40),
        ],
      );
      expect(r.summary.prayerMinutes, 100);
      expect(r.summary.restMinutes, 40);
      expect(r.summary.operatingMinutes, 960);
      expect(r.summary.spanMinutes, 1100);
      expect(r.scheduleEndMinute, 780 + 1100); // 07:20 اليوم التالي
      for (final ScheduleEntry e in r.entries) {
        expect(e.operatingMinutes, 240);
      }
      expect(r.entries[1].prayerMinutes, 75);
      expect(r.entries[2].restMinutes, 40);
      expectConsistent(r);
    });
  });

  group('Test 5 — عطل 20 دقيقة', () {
    test('توزيع مشترك (الافتراضي): 5 دقائق على كل مستخدم', () {
      final ScheduleReport r = run(
        start: hm(13),
        end: hm(5),
        users: names4,
        downtimes: <DowntimeEvent>[down('d1', hm(15), 20, 'عطل شبكة')],
      );
      for (final ScheduleEntry e in r.entries) {
        expect(e.operatingMinutes, 235);
        expect(e.lostShareMinutes, 5);
      }
      expect(r.entries[0].downtimeMinutes, 20);
      expect(r.summary.operatingMinutes, 940);
      expect(r.summary.downtimeMinutes, 20);
      // العطل لا يمدّد نهاية الجدول.
      expect(r.scheduleEndMinute, 1740);
      expect(r.summary.spanMinutes, 960);
      expectConsistent(r);
    });

    test('سياسة: صاحب الدور وحده يتحمّل العطل', () {
      final ScheduleReport r = run(
        start: hm(13),
        end: hm(5),
        users: names4,
        downtimes: <DowntimeEvent>[down('d1', hm(15), 20)],
        rules: const CalcRules(
            downtimePolicy: DowntimePolicy.currentUserAbsorbs),
      );
      expect(r.entries[0].operatingMinutes, 220);
      expect(r.entries[0].lostShareMinutes, 20);
      expect(r.entries[1].operatingMinutes, 240);
      expect(r.entries[0].turnEndMinute, hm(17)); // لم يُمدَّد دوره
      expect(r.scheduleEndMinute, 1740);
      expectConsistent(r);
    });

    test('سياسة: من لم يبدأ دوره فقط', () {
      final ScheduleReport r = run(
        start: hm(13),
        end: hm(5),
        users: names4,
        downtimes: <DowntimeEvent>[down('d1', hm(15), 20)],
        rules:
            const CalcRules(downtimePolicy: DowntimePolicy.futureUsersOnly),
      );
      expect(r.entries[0].operatingMinutes, 240);
      expect(r.entries[1].operatingMinutes, 233);
      expect(r.entries[2].operatingMinutes, 233);
      expect(r.entries[3].operatingMinutes, 234);
      expect(r.scheduleEndMinute, 1740);
      expectConsistent(r);
    });
  });

  group('Test 6 — عدة أعطال', () {
    test('ثلاثة أعطال 20 + 15 + 10 تُعالج بترتيبها الزمني', () {
      final ScheduleReport r = run(
        start: hm(13),
        end: hm(5),
        users: names4,
        downtimes: <DowntimeEvent>[
          down('d1', hm(15), 20),
          down('d2', hm(19), 15),
          down('d3', hm(1), 10),
        ],
      );
      expect(r.summary.downtimeMinutes, 45);
      expect(r.summary.operatingMinutes, 915);
      expect(r.entries[0].operatingMinutes, 235);
      expect(r.entries[1].operatingMinutes, 230);
      expect(r.entries[2].operatingMinutes, 225);
      expect(r.entries[3].operatingMinutes, 225);
      expect(r.entries[0].lostShareMinutes, 5);
      expect(r.entries[1].lostShareMinutes, 10);
      expect(r.entries[2].lostShareMinutes, 15);
      expect(r.entries[3].lostShareMinutes, 15);
      expect(r.scheduleEndMinute, 1740);
      expectConsistent(r);
    });
  });

  group('Test 7 — عطل أثناء دور مستخدم', () {
    test('العطل في دور الثالث يقسَّم عليه وعلى الرابع فقط', () {
      final ScheduleReport r = run(
        start: hm(13),
        end: hm(5),
        users: names4,
        downtimes: <DowntimeEvent>[down('d4', hm(22), 30)],
      );
      expect(r.entries[0].operatingMinutes, 240);
      expect(r.entries[1].operatingMinutes, 240);
      expect(r.entries[2].operatingMinutes, 225);
      expect(r.entries[3].operatingMinutes, 225);
      expect(r.entries[2].downtimeMinutes, 30);
      expect(r.entries[3].downtimeMinutes, 0);
      expect(r.summary.operatingMinutes, 930);
      expectConsistent(r);
    });
  });

  group('Test 8 — صلاة أثناء دور مستخدم', () {
    test('الصلاة توقف الحصة مؤقتًا ثم تُستأنف', () {
      final ScheduleReport r = run(
        start: hm(13),
        end: hm(5),
        users: names4,
        breaks: <BreakEvent>[prayer('mg', 'المغرب', hm(18), 45)],
      );
      expect(r.entries[1].operatingMinutes, 240);
      expect(r.entries[1].prayerMinutes, 45);
      expect(r.entries[1].turnStartMinute, hm(17));
      expect(r.entries[1].turnEndMinute, hm(21, 45));
      expect(r.summary.spanMinutes, 1005);
      expectConsistent(r);
    });
  });

  group('Test 9 — صلاة عند انتقال مستخدم', () {
    test('التوقف يقع قبل بدء المستخدم التالي ولا يُنسب لأحد', () {
      final ScheduleReport r = run(
        start: hm(13),
        end: hm(5),
        users: names4,
        breaks: <BreakEvent>[prayer('ed', 'توقف الانتقال', hm(17), 20)],
      );
      final TimelineSegment seg = r.timeline[1];
      expect(seg.type, SegmentType.prayer);
      expect(seg.betweenTurns, isTrue);
      expect(seg.userId, isNull);
      expect(r.entries[0].turnEndMinute, hm(17));
      expect(r.entries[0].prayerMinutes, 0);
      expect(r.entries[1].turnStartMinute, hm(17, 20));
      expect(r.entries[1].prayerMinutes, 0);
      for (final ScheduleEntry e in r.entries) {
        expect(e.operatingMinutes, 240);
      }
      expect(r.summary.spanMinutes, 980);
      expectConsistent(r);
    });
  });

  group('Test 10 — صلاة + عطل في أوقات متقاربة', () {
    test('العطل المتداخل مع الصلاة لا يُخصم مرتين', () {
      final ScheduleReport r = run(
        start: hm(13),
        end: hm(5),
        users: names4,
        breaks: <BreakEvent>[prayer('mg', 'المغرب', hm(18), 45)],
        downtimes: <DowntimeEvent>[down('dov', hm(18, 30), 30, 'عطل')],
      );
      // 18:00→18:45 صلاة، 18:45→19:00 عطل (15 دقيقة فقط)
      expect(r.summary.prayerMinutes, 45);
      expect(r.summary.downtimeMinutes, 15);
      expect(r.summary.operatingMinutes, 945);
      expect(r.entries[0].operatingMinutes, 240);
      expect(r.entries[1].operatingMinutes, 235);
      expect(r.entries[2].operatingMinutes, 235);
      expect(r.entries[3].operatingMinutes, 235);
      expect(r.warnings.isNotEmpty, isTrue);
      expectConsistent(r);
    });

    test('عطل داخل عطل: تُقصّ التداخلات ولا تتكرر الدقائق', () {
      final ScheduleReport r = run(
        start: hm(13),
        end: hm(5),
        users: names4,
        downtimes: <DowntimeEvent>[
          down('a', hm(15), 30),
          down('b', hm(15, 10), 30), // يتداخل مع السابق
        ],
      );
      // الاتحاد = 15:00→15:40 = 40 دقيقة فقط
      expect(r.summary.downtimeMinutes, 40);
      expect(r.summary.operatingMinutes, 920);
      expect(r.warnings.isNotEmpty, isTrue);
      expectConsistent(r);
    });

    test('صلاة تتداخل مع صلاة: تُقصّ الثانية', () {
      final ScheduleReport r = run(
        start: hm(13),
        end: hm(5),
        users: names4,
        breaks: <BreakEvent>[
          prayer('p1', 'صلاة 1', hm(15), 30),
          prayer('p2', 'صلاة 2', hm(15, 20), 30),
        ],
      );
      expect(r.summary.prayerMinutes, 50); // 15:00→15:50
      expect(r.summary.operatingMinutes, 960);
      expect(r.warnings.isNotEmpty, isTrue);
      expectConsistent(r);
    });

    test('حدث خارج فترة التشغيل يُتجاهل مع تنبيه', () {
      final ScheduleReport r = run(
        start: hm(13),
        end: hm(21),
        users: names4,
        breaks: <BreakEvent>[prayer('x', 'خارج الفترة', hm(23), 30)],
      );
      expect(r.summary.prayerMinutes, 0);
      expect(r.summary.spanMinutes, 480);
      expect(r.warnings.isNotEmpty, isTrue);
      expectConsistent(r);
    });
  });

  group('Test 11 — فترة لا تعبر منتصف الليل', () {
    test('08:00→16:00 مع صلاة عند الانتقال وعطل', () {
      final ScheduleReport r = run(
        start: hm(8),
        end: hm(16),
        users: names4,
        breaks: <BreakEvent>[prayer('z', 'الظهر', hm(12), 25)],
        downtimes: <DowntimeEvent>[down('dz', hm(14), 20)],
      );
      expect(r.summary.periodMinutes, 480);
      expect(r.summary.spanMinutes, 505);
      expect(r.scheduleEndMinute, hm(16, 25));
      expect(r.entries[0].operatingMinutes, 120);
      expect(r.entries[1].operatingMinutes, 120);
      expect(r.entries[2].operatingMinutes, 110);
      expect(r.entries[3].operatingMinutes, 110);
      expectConsistent(r);
    });
  });

  group('Test 12 — فترة تعبر منتصف الليل', () {
    test('أحداث بعد منتصف الليل تُحسب على الخط الزمني الصحيح', () {
      final ScheduleReport r = run(
        start: hm(20),
        end: hm(6),
        users: names4,
        breaks: <BreakEvent>[prayer('f', 'الفجر', hm(4), 20)],
        downtimes: <DowntimeEvent>[down('dn', hm(1), 25)],
      );
      expect(r.summary.periodMinutes, 600);
      expect(r.summary.spanMinutes, 620);
      expect(r.entries[0].operatingMinutes, 150);
      expect(r.entries[1].operatingMinutes, 150);
      expect(r.entries[2].operatingMinutes, 137);
      expect(r.entries[3].operatingMinutes, 138);
      expect(r.entries[3].prayerMinutes, 20);
      // العطل وقع عند لحظة انتقال، فلم يُنسب لأحد.
      expect(r.entries[1].downtimeMinutes, 0);
      expect(r.entries[2].downtimeMinutes, 0);
      expectConsistent(r);
    });
  });

  group('Test 13 — عدد لا يقبل القسمة بالتساوي', () {
    test('5 مستخدمين على 960 دقيقة = 192 لكل واحد', () {
      final ScheduleReport r = run(
        start: hm(13),
        end: hm(5),
        users: <String>['م1', 'م2', 'م3', 'م4', 'م5'],
      );
      for (final ScheduleEntry e in r.entries) {
        expect(e.operatingMinutes, 192);
      }
      expectConsistent(r);
    });

    test('7 مستخدمين: الدقيقة الزائدة للأول ولا تُفقد دقيقة', () {
      final ScheduleReport r = run(
        start: hm(13),
        end: hm(5),
        users: <String>['م1', 'م2', 'م3', 'م4', 'م5', 'م6', 'م7'],
      );
      expect(r.entries[0].operatingMinutes, 138);
      for (int i = 1; i < 7; i++) {
        expect(r.entries[i].operatingMinutes, 137);
      }
      expect(r.summary.operatingMinutes, 960);
      expectConsistent(r);
    });

    test('سياسة الأواخر: الدقيقة الزائدة للأخير', () {
      final ScheduleReport r = run(
        start: hm(13),
        end: hm(5),
        users: <String>['م1', 'م2', 'م3', 'م4', 'م5', 'م6', 'م7'],
        rules: const CalcRules(remainderPolicy: RemainderPolicy.lastUsers),
      );
      expect(r.entries[6].operatingMinutes, 138);
      expect(r.entries[0].operatingMinutes, 137);
      expect(r.summary.operatingMinutes, 960);
      expectConsistent(r);
    });
  });

  group('Test 14/15 — أعداد أكبر', () {
    test('مجموعة من 5 مستخدمين مع صلوات وأعطال', () {
      final ScheduleReport r = run(
        start: hm(13),
        end: hm(5),
        users: <String>['م1', 'م2', 'م3', 'م4', 'م5'],
        breaks: <BreakEvent>[
          prayer('asr', 'العصر', hm(15), 25),
          prayer('mg', 'المغرب', hm(18), 45),
          prayer('is', 'العشاء', hm(20), 30),
          rest('rs', 'الراحة', hm(23), 40),
        ],
        downtimes: <DowntimeEvent>[
          down('x1', hm(16), 20),
          down('x2', hm(2), 15),
        ],
      );
      expect(r.summary.prayerMinutes, 100);
      expect(r.summary.restMinutes, 40);
      expect(r.summary.downtimeMinutes, 35);
      expect(r.summary.operatingMinutes, 925);
      expect(r.entries[0].operatingMinutes, 188);
      expect(r.entries[3].operatingMinutes, 180);
      expect(r.entries[4].operatingMinutes, 181);
      expectConsistent(r);
    });

    test('12 مستخدمًا على فترة واحدة', () {
      final ScheduleReport r = run(
        start: hm(13),
        end: hm(5),
        users: <String>[for (int i = 1; i <= 12; i++) 'م$i'],
      );
      expect(r.entries.length, 12);
      expect(r.summary.operatingMinutes, 960);
      expectConsistent(r);
    });
  });


  group('المثال المعتمد — 13:40 ← 04:55 بمواقيت القاهرة الحقيقية', () {
    ScheduleReport approved() => run(
          start: hm(13, 40),
          end: hm(4, 55),
          users: names4,
          breaks: <BreakEvent>[
            prayer('asr', 'صلاة العصر', hm(16, 13), 25),
            prayer('mg', 'صلاة المغرب', hm(18, 48), 45),
            prayer('is', 'صلاة العشاء', hm(20, 5), 30),
            rest('rs', 'الراحة', hm(23), 30),
          ],
          rules: const CalcRules(breakPolicy: BreakPolicy.deductFromShares),
        );

    test('الفترة والتوقفات وصافي التشغيل', () {
      final ScheduleReport r = approved();
      expect(r.summary.periodMinutes, 915);
      expect(r.summary.prayerMinutes + r.summary.restMinutes, 130);
      expect(r.summary.plannedOperatingMinutes, 785);
      expectConsistent(r);
    });

    test('الحصص: 197 ثم 196 ثلاث مرات', () {
      final ScheduleReport r = approved();
      expect(
        r.entries.map((ScheduleEntry e) => e.plannedShareMinutes).toList(),
        <int>[197, 196, 196, 196],
      );
    });

    test('أوقات التسليم بين المستخدمين', () {
      final ScheduleReport r = approved();
      expect(r.entries[0].turnStartMinute, hm(13, 40));
      expect(r.entries[0].turnEndMinute, hm(17, 22));
      expect(r.entries[1].turnEndMinute, hm(21, 53));
      expect(r.entries[2].turnEndMinute, 1440 + hm(1, 39));
      expect(r.entries[3].turnEndMinute, 1440 + hm(4, 55));
    });

    test('الجدول ينتهي عند وقت النهاية بالضبط', () {
      final ScheduleReport r = approved();
      expect(r.scheduleEndMinute, r.nominalEndMinute);
      expect(r.overtimeMinutes, 0);
    });

    test('التوقفات موزعة على أصحابها', () {
      final ScheduleReport r = approved();
      expect(r.entries[0].prayerMinutes, 25);
      expect(r.entries[1].prayerMinutes, 75);
      expect(r.entries[2].restMinutes, 30);
      expect(r.entries[3].pauseMinutes, 0);
    });
  });

  group('حالات حافة والتحقق من المدخلات', () {
    test('عطل يستهلك كل الوقت المتبقي', () {
      final ScheduleReport r = run(
        start: hm(13),
        end: hm(13, 20),
        users: <String>['م1', 'م2'],
        downtimes: <DowntimeEvent>[down('b', hm(13, 5), 15)],
      );
      expect(r.entries[0].operatingMinutes, 5);
      expect(r.entries[1].operatingMinutes, 0);
      expect(r.summary.operatingMinutes, 5);
      expect(r.summary.unallocatedLostMinutes, 0);
      expectConsistent(r);
    });

    test('سياسة الفترة الثابتة: خصم التوقفات من الحصص', () {
      final ScheduleReport r = run(
        start: hm(13),
        end: hm(5),
        users: names4,
        breaks: <BreakEvent>[
          prayer('asr', 'العصر', hm(15), 25),
          prayer('mg', 'المغرب', hm(18), 45),
          prayer('is', 'العشاء', hm(20), 30),
          rest('rs', 'الراحة', hm(23), 40),
        ],
        rules: const CalcRules(breakPolicy: BreakPolicy.deductFromShares),
      );
      expect(r.summary.plannedOperatingMinutes, 820);
      for (final ScheduleEntry e in r.entries) {
        expect(e.operatingMinutes, 205);
      }
      // الجدول ينتهي عند وقت النهاية بالضبط.
      expect(r.scheduleEndMinute, 1740);
      expect(r.summary.spanMinutes, 960);
      expectConsistent(r);
    });

    test('نفس المدخلات تعطي نفس النتيجة دائمًا (حتمية)', () {
      for (int i = 0; i < 3; i++) {
        final ScheduleReport r = run(
          start: hm(13),
          end: hm(5),
          users: names4,
          breaks: <BreakEvent>[prayer('asr', 'العصر', hm(15), 25)],
          downtimes: <DowntimeEvent>[down('d1', hm(19), 20)],
        );
        expect(r.scheduleEndMinute, 1765);
        expect(r.summary.operatingMinutes, 940);
        expect(r.entries[0].operatingMinutes, 240);
        expect(r.entries[1].operatingMinutes, 233);
        expect(r.entries[2].operatingMinutes, 233);
        expect(r.entries[3].operatingMinutes, 234);
        expectConsistent(r);
      }
    });

    test('مستخدم بدون اسم يرفع خطأ عربيًا واضحًا', () {
      expect(
        () => TimeCalculationEngine.compute(
          ScheduleInput(
            period: const TimePeriod(startMinuteOfDay: 780, endMinuteOfDay: 300),
            users: <User>[User(id: 'u1', name: '  ')],
          ),
        ),
        throwsA(isA<ScheduleValidationException>()),
      );
    });

    test('لا مستخدمين يرفع خطأ', () {
      expect(
        () => TimeCalculationEngine.compute(
          const ScheduleInput(
            period: TimePeriod(startMinuteOfDay: 780, endMinuteOfDay: 300),
            users: <User>[],
          ),
        ),
        throwsA(isA<ScheduleValidationException>()),
      );
    });

    test('وقت بداية = وقت نهاية يرفع خطأ', () {
      expect(
        () => TimeCalculationEngine.compute(
          ScheduleInput(
            period: const TimePeriod(startMinuteOfDay: 780, endMinuteOfDay: 780),
            users: makeUsers(names4),
          ),
        ),
        throwsA(isA<ScheduleValidationException>()),
      );
    });

    test('مدة عطل سالبة أو صفر يرفع خطأ', () {
      expect(
        () => TimeCalculationEngine.compute(
          ScheduleInput(
            period: const TimePeriod(startMinuteOfDay: 780, endMinuteOfDay: 300),
            users: makeUsers(names4),
            downtimes: <DowntimeEvent>[down('bad', hm(15), 0)],
          ),
        ),
        throwsA(isA<ScheduleValidationException>()),
      );
    });

    test('الفترة أقصر من عدد المستخدمين ترفع خطأ', () {
      expect(
        () => TimeCalculationEngine.compute(
          ScheduleInput(
            period: const TimePeriod(startMinuteOfDay: 780, endMinuteOfDay: 782),
            users: makeUsers(names4),
          ),
        ),
        throwsA(isA<ScheduleValidationException>()),
      );
    });
  });
}
