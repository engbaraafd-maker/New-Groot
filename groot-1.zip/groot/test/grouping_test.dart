import 'package:flutter_test/flutter_test.dart';
import 'package:groot/core/time_utils.dart';
import 'package:groot/models/group.dart';
import 'package:groot/models/user.dart';
import 'package:groot/services/grouping_service.dart';

List<User> makeUsers(int count) => <User>[
      for (int i = 1; i <= count; i++) User(id: 'u$i', name: 'م$i'),
    ];

void main() {
  group('تقسيم الأعداد', () {
    test('لا تُفقد دقيقة ولا تُخلق دقيقة', () {
      for (int total = 0; total <= 200; total += 7) {
        for (int count = 1; count <= 9; count++) {
          final List<int> a = TimeUtils.splitEvenly(total, count);
          final List<int> b =
              TimeUtils.splitEvenly(total, count, extraToFirst: false);
          expect(a.fold<int>(0, (int s, int v) => s + v), total);
          expect(b.fold<int>(0, (int s, int v) => s + v), total);
          // الفرق بين أكبر وأصغر حصة لا يتجاوز دقيقة واحدة.
          final int maxA = a.reduce((int x, int y) => x > y ? x : y);
          final int minA = a.reduce((int x, int y) => x < y ? x : y);
          expect(maxA - minA <= 1, isTrue);
        }
      }
    });

    test('الزيادة للأوائل أو للأواخر', () {
      expect(TimeUtils.splitEvenly(14, 3), <int>[5, 5, 4]);
      expect(TimeUtils.splitEvenly(14, 3, extraToFirst: false),
          <int>[4, 5, 5]);
    });
  });

  group('إنشاء المجموعات', () {
    test('12 مستخدمًا على 3 أجهزة = 3 مجموعات × 4', () {
      final List<User> users = makeUsers(12);
      final List<Group> groups =
          GroupingService.buildGroups(users: users, groupCount: 3);
      expect(groups.length, 3);
      for (final Group g in groups) {
        expect(g.size, 4);
      }
      expect(groups[0].memberIds, <String>['u1', 'u2', 'u3', 'u4']);
      expect(groups[2].memberIds, <String>['u9', 'u10', 'u11', 'u12']);
    });

    test('14 مستخدمًا على 3 أجهزة: لا يُفقد أحد', () {
      final List<User> users = makeUsers(14);
      final List<Group> groups =
          GroupingService.buildGroups(users: users, groupCount: 3);
      expect(groups.map((Group g) => g.size).toList(), <int>[5, 5, 4]);
      final Set<String> all = <String>{};
      for (final Group g in groups) {
        all.addAll(g.memberIds);
      }
      expect(all.length, 14);
    });

    test('15 مستخدمًا على 4 أجهزة', () {
      final List<Group> groups =
          GroupingService.buildGroups(users: makeUsers(15), groupCount: 4);
      expect(groups.map((Group g) => g.size).toList(), <int>[4, 4, 4, 3]);
    });

    test('عدد مستخدمين أقل من عدد الأجهزة', () {
      final List<Group> groups =
          GroupingService.buildGroups(users: makeUsers(2), groupCount: 5);
      expect(groups.length, 5);
      expect(groups.map((Group g) => g.size).toList(), <int>[1, 1, 0, 0, 0]);
    });

    test('المستخدمون الجدد يظهرون كغير موزعين ولا تتغير المجموعات تلقائيًا', () {
      final List<User> users = makeUsers(6);
      final List<Group> groups =
          GroupingService.buildGroups(users: users, groupCount: 2);
      GroupingService.applyGroupIds(users, groups);
      expect(GroupingService.unassignedUsers(users, groups), isEmpty);

      users.add(User(id: 'u7', name: 'م7'));
      expect(GroupingService.unassignedUsers(users, groups).length, 1);
      // المجموعات لم تتغير من تلقاء نفسها.
      expect(groups[0].memberIds.length, 3);
      expect(groups[1].memberIds.length, 3);
    });

    test('حذف مستخدم ينظّف المجموعات', () {
      final List<User> users = makeUsers(6);
      final List<Group> groups =
          GroupingService.buildGroups(users: users, groupCount: 2);
      users.removeWhere((User u) => u.id == 'u2');
      GroupingService.pruneDeletedUsers(groups, users);
      expect(groups[0].memberIds.contains('u2'), isFalse);
      expect(groups[0].memberIds.length, 2);
    });

    test('أسماء المجموعات المعدّلة تبقى بعد إعادة التوزيع', () {
      final List<User> users = makeUsers(6);
      final List<Group> first =
          GroupingService.buildGroups(users: users, groupCount: 2);
      first[0].name = 'فريق الصباح';
      final List<Group> second = GroupingService.buildGroups(
        users: users,
        groupCount: 2,
        previous: first,
      );
      expect(second[0].name, 'فريق الصباح');
    });
  });

  group('أدوات الوقت', () {
    test('التحويل بين النص والدقائق', () {
      expect(TimeUtils.tryParseHm('13:00'), 780);
      expect(TimeUtils.tryParseHm('05:00'), 300);
      expect(TimeUtils.tryParseHm('24:00'), 0);
      expect(TimeUtils.tryParseHm('25:00'), isNull);
      expect(TimeUtils.tryParseHm('12:60'), isNull);
      expect(TimeUtils.tryParseHm('abc'), isNull);
    });

    test('العرض يعالج ما بعد منتصف الليل', () {
      expect(TimeUtils.formatHm(1740), '05:00');
      expect(TimeUtils.formatHmWithDay(1740), '05:00 (اليوم التالي)');
      expect(TimeUtils.formatHm(780), '13:00');
    });

    test('طول الفترة مع عبور منتصف الليل', () {
      expect(TimeUtils.periodLength(780, 300), 960);
      expect(TimeUtils.periodLength(480, 960), 480);
      expect(TimeUtils.crossesMidnight(780, 300), isTrue);
      expect(TimeUtils.crossesMidnight(480, 960), isFalse);
    });

    test('رفع وقت الحدث إلى الخط الزمني للجدول', () {
      expect(TimeUtils.liftIntoWindow(300, 780), 1740); // 05:00 بعد 13:00
      expect(TimeUtils.liftIntoWindow(900, 780), 900); // 15:00 بعد 13:00
      expect(TimeUtils.liftIntoWindow(780, 780), 780);
    });

    test('عدد الأيام بين تاريخين', () {
      expect(
        TimeUtils.daysBetween(DateTime(2026, 1, 1), DateTime(2026, 1, 4)),
        3,
      );
      expect(
        TimeUtils.daysBetween(DateTime(2026, 3, 1), DateTime(2026, 2, 28)),
        -1,
      );
    });

    test('تنسيق المدة', () {
      expect(TimeUtils.formatDuration(0), '0 د');
      expect(TimeUtils.formatDuration(45), '45 د');
      expect(TimeUtils.formatDuration(120), '2 س');
      expect(TimeUtils.formatDuration(145), '2 س 25 د');
    });
  });
}
