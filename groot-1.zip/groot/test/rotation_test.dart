import 'package:flutter_test/flutter_test.dart';
import 'package:groot/models/device.dart';
import 'package:groot/models/group.dart';
import 'package:groot/models/user.dart';
import 'package:groot/services/rotation_service.dart';

void main() {
  group('تدوير المجموعات بين الأجهزة', () {
    test('ثلاثة أجهزة: النمط المطلوب حرفيًا ثم يعود في اليوم الرابع', () {
      List<int> pattern(int day) => <int>[
            for (int j = 0; j < 3; j++)
              RotationService.groupIndexForDevice(
                deviceIndex: j,
                dayIndexValue: day,
                deviceCount: 3,
              ),
          ];

      expect(pattern(0), <int>[0, 1, 2]); // جهاز1←م1، جهاز2←م2، جهاز3←م3
      expect(pattern(1), <int>[2, 0, 1]); // جهاز1←م3، جهاز2←م1، جهاز3←م2
      expect(pattern(2), <int>[1, 2, 0]); // جهاز1←م2، جهاز2←م3، جهاز3←م1
      expect(pattern(3), pattern(0)); // اليوم 4 = اليوم 1
    });

    test('يعمل مع أي عدد من الأجهزة (5 أجهزة)', () {
      for (int day = 0; day < 12; day++) {
        final Set<int> seen = <int>{};
        for (int j = 0; j < 5; j++) {
          seen.add(RotationService.groupIndexForDevice(
            deviceIndex: j,
            dayIndexValue: day,
            deviceCount: 5,
          ));
        }
        // كل مجموعة تظهر مرة واحدة فقط كل يوم.
        expect(seen.length, 5);
      }
      expect(
        RotationService.groupIndexForDevice(
            deviceIndex: 0, dayIndexValue: 5, deviceCount: 5),
        RotationService.groupIndexForDevice(
            deviceIndex: 0, dayIndexValue: 0, deviceCount: 5),
      );
    });

    test('أيام سالبة (قبل تاريخ بداية الدورة) تعمل بشكل صحيح', () {
      expect(
        RotationService.groupIndexForDevice(
            deviceIndex: 0, dayIndexValue: -1, deviceCount: 3),
        1,
      );
      expect(RotationService.mod(-4, 3), 2);
    });

    test('رقم دورة اليوم', () {
      expect(RotationService.cycleNumber(0, 3), 1);
      expect(RotationService.cycleNumber(1, 3), 2);
      expect(RotationService.cycleNumber(3, 3), 1);
    });
  });

  group('التدوير العكسي داخل المجموعة', () {
    const List<String> base = <String>['A', 'B', 'C', 'D'];

    test('آخر عنصر يصبح الأول', () {
      expect(RotationService.rotateBackward(base, 0), <String>['A', 'B', 'C', 'D']);
      expect(RotationService.rotateBackward(base, 1), <String>['D', 'A', 'B', 'C']);
      expect(RotationService.rotateBackward(base, 2), <String>['C', 'D', 'A', 'B']);
      expect(RotationService.rotateBackward(base, 3), <String>['B', 'C', 'D', 'A']);
      expect(RotationService.rotateBackward(base, 4), <String>['A', 'B', 'C', 'D']);
    });

    test('لا يفقد ولا يكرر أي عنصر', () {
      for (int r = 0; r < 9; r++) {
        final List<String> out = RotationService.rotateBackward(base, r);
        expect(out.length, base.length);
        expect(out.toSet(), base.toSet());
      }
    });

    test('مجموعة من عنصر واحد أو فارغة', () {
      expect(RotationService.rotateBackward(<String>['A'], 3), <String>['A']);
      expect(RotationService.rotateBackward(<String>[], 2), <String>[]);
    });
  });

  group('التدويران مستقلان', () {
    test('تدوير المجموعات لا يغيّر أعضاء المجموعة', () {
      final List<User> users = <User>[
        for (int i = 1; i <= 6; i++) User(id: 'u$i', name: 'م$i'),
      ];
      final List<Device> devices = <Device>[
        Device(id: 'd1', name: 'جهاز 1'),
        Device(id: 'd2', name: 'جهاز 2'),
      ];
      final List<Group> groups = <Group>[
        Group(id: 'g0', index: 0, memberIds: <String>['u1', 'u2', 'u3']),
        Group(id: 'g1', index: 1, memberIds: <String>['u4', 'u5', 'u6']),
      ];

      for (int day = 0; day < 6; day++) {
        final List<DayAssignment> a = RotationService.assignmentsForDay(
          devices: devices,
          groups: groups,
          users: users,
          dayIndexValue: day,
        );
        expect(a.length, 2);
        for (final DayAssignment x in a) {
          expect(x.orderedUsers.length, 3);
          final Set<String> ids =
              x.orderedUsers.map((User u) => u.id).toSet();
          // الأعضاء ثابتون مهما تغيّر الجهاز.
          expect(
            ids,
            x.groupIndex == 0
                ? <String>{'u1', 'u2', 'u3'}
                : <String>{'u4', 'u5', 'u6'},
          );
        }
      }
    });

    test('ترتيب الأشخاص يتغيّر يوميًا بالتدوير العكسي', () {
      final Group g =
          Group(id: 'g0', index: 0, memberIds: <String>['a', 'b', 'c', 'd']);
      expect(RotationService.orderedMemberIds(g, 0),
          <String>['a', 'b', 'c', 'd']);
      expect(RotationService.orderedMemberIds(g, 1),
          <String>['d', 'a', 'b', 'c']);
      expect(RotationService.orderedMemberIds(g, 2),
          <String>['c', 'd', 'a', 'b']);
    });
  });
}
