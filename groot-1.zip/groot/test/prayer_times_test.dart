import 'package:flutter_test/flutter_test.dart';
import 'package:groot/core/time_utils.dart';
import 'package:groot/models/prayer_settings.dart';
import 'package:groot/services/prayer_times_service.dart';

String at(int minuteOfDay) => TimeUtils.formatHm(minuteOfDay);

void main() {
  group('حساب مواقيت الصلاة بدون إنترنت', () {
    test('القاهرة 26 سبتمبر 2026 (توقيت صيفي +3) يطابق المصدر الرسمي', () {
      final PrayerTimesResult t = PrayerTimesService.forDate(
        date: DateTime(2026, 9, 26),
        latitude: 30.0444,
        longitude: 31.2357,
        timeZoneHours: 3,
      );
      // المصدر الرسمي: 05:19 / 06:45 / 12:46 / 16:13 / 18:47 / 20:04
      // نسمح بفارق دقيقتين كحد أقصى.
      expect((t.fajr - TimeUtils.hmToMinutes(5, 19)).abs() <= 2, isTrue,
          reason: 'الفجر ${at(t.fajr)}');
      expect((t.sunrise - TimeUtils.hmToMinutes(6, 45)).abs() <= 2, isTrue,
          reason: 'الشروق ${at(t.sunrise)}');
      expect((t.dhuhr - TimeUtils.hmToMinutes(12, 46)).abs() <= 2, isTrue,
          reason: 'الظهر ${at(t.dhuhr)}');
      expect((t.asr - TimeUtils.hmToMinutes(16, 13)).abs() <= 2, isTrue,
          reason: 'العصر ${at(t.asr)}');
      expect((t.maghrib - TimeUtils.hmToMinutes(18, 47)).abs() <= 2, isTrue,
          reason: 'المغرب ${at(t.maghrib)}');
      expect((t.isha - TimeUtils.hmToMinutes(20, 4)).abs() <= 2, isTrue,
          reason: 'العشاء ${at(t.isha)}');
    });

    test('الترتيب الطبيعي للمواقيت محفوظ على مدار السنة', () {
      for (int month = 1; month <= 12; month++) {
        final PrayerTimesResult t = PrayerTimesService.forDate(
          date: DateTime(2026, month, 15),
          latitude: 30.0444,
          longitude: 31.2357,
          timeZoneHours: month >= 5 && month <= 10 ? 3 : 2,
        );
        expect(t.fajr < t.sunrise, isTrue, reason: 'الشهر $month');
        expect(t.sunrise < t.dhuhr, isTrue, reason: 'الشهر $month');
        expect(t.dhuhr < t.asr, isTrue, reason: 'الشهر $month');
        expect(t.asr < t.maghrib, isTrue, reason: 'الشهر $month');
        expect(t.maghrib < t.isha, isTrue, reason: 'الشهر $month');
      }
    });

    test('المواقيت تتغيّر يوميًا (ليست ثابتة)', () {
      final PrayerTimesResult a = PrayerTimesService.forDate(
        date: DateTime(2026, 6, 21),
        latitude: 30.0444,
        longitude: 31.2357,
        timeZoneHours: 3,
      );
      final PrayerTimesResult b = PrayerTimesService.forDate(
        date: DateTime(2026, 12, 21),
        latitude: 30.0444,
        longitude: 31.2357,
        timeZoneHours: 2,
      );
      // الفارق بين الانقلابين كبير ومعروف.
      expect(a.maghrib > b.maghrib + 60, isTrue,
          reason: 'صيف ${at(a.maghrib)} / شتاء ${at(b.maghrib)}');
    });

    test('العصر الحنفي متأخر عن عصر الجمهور', () {
      final PrayerTimesResult std = PrayerTimesService.forDate(
        date: DateTime(2026, 9, 26),
        latitude: 30.0444,
        longitude: 31.2357,
        timeZoneHours: 3,
        asrFactor: PrayerTimesService.asrFactorStandard,
      );
      final PrayerTimesResult hanafi = PrayerTimesService.forDate(
        date: DateTime(2026, 9, 26),
        latitude: 30.0444,
        longitude: 31.2357,
        timeZoneHours: 3,
        asrFactor: PrayerTimesService.asrFactorHanafi,
      );
      expect(hanafi.asr > std.asr, isTrue);
    });

    test('مدن مختلفة تعطي مواقيت مختلفة', () {
      final PrayerTimesResult cairo = PrayerTimesService.forDate(
        date: DateTime(2026, 9, 26),
        latitude: 30.0444,
        longitude: 31.2357,
        timeZoneHours: 3,
      );
      final PrayerTimesResult alex = PrayerTimesService.forDate(
        date: DateTime(2026, 9, 26),
        latitude: 31.2001,
        longitude: 29.9187,
        timeZoneHours: 3,
      );
      expect(alex.maghrib != cairo.maghrib, isTrue);
    });

    test('كل المدن المعرفة تعطي مواقيت سليمة', () {
      for (final CityPreset c in CityPreset.egypt) {
        final PrayerTimesResult t = PrayerTimesService.forDate(
          date: DateTime(2026, 9, 26),
          latitude: c.latitude,
          longitude: c.longitude,
          timeZoneHours: 3,
        );
        expect(t.fajr >= 0 && t.fajr < 1440, isTrue, reason: c.name);
        expect(t.asr < t.maghrib, isTrue, reason: c.name);
      }
    });
  });


  group('التعديل اليدوي للمواقيت', () {
    PrayerSlot slot() => PrayerSlot(
          key: 'asr',
          name: 'صلاة العصر',
          enabled: true,
          durationMinutes: 25,
        );

    test('بلا تعديل يبقى الوقت المحسوب كما هو', () {
      final PrayerSlot p = slot();
      expect(p.resolve(TimeUtils.hmToMinutes(16, 13)),
          TimeUtils.hmToMinutes(16, 13));
      expect(p.isAdjusted, isFalse);
      expect(p.modeLabel, 'تلقائي');
    });

    test('التعديل بالدقائق يزيح الوقت ويظل يتتبع الحساب', () {
      final PrayerSlot p = slot()..offsetMinutes = 7;
      expect(p.resolve(TimeUtils.hmToMinutes(16, 13)),
          TimeUtils.hmToMinutes(16, 20));
      // يوم آخر بوقت محسوب مختلف: الإزاحة نفسها تُطبَّق.
      expect(p.resolve(TimeUtils.hmToMinutes(15, 30)),
          TimeUtils.hmToMinutes(15, 37));
      expect(p.isAdjusted, isTrue);
      expect(p.modeLabel, 'تلقائي +7');
    });

    test('التعديل بالسالب يعمل', () {
      final PrayerSlot p = slot()..offsetMinutes = -10;
      expect(p.resolve(TimeUtils.hmToMinutes(16, 13)),
          TimeUtils.hmToMinutes(16, 3));
      expect(p.modeLabel, 'تلقائي -10');
    });

    test('الوقت الثابت اليدوي يلغي الحساب', () {
      final PrayerSlot p = slot()
        ..offsetMinutes = 7
        ..manualMinuteOfDay = TimeUtils.hmToMinutes(16, 45);
      expect(p.resolve(TimeUtils.hmToMinutes(16, 13)),
          TimeUtils.hmToMinutes(16, 45));
      expect(p.resolve(TimeUtils.hmToMinutes(15, 30)),
          TimeUtils.hmToMinutes(16, 45));
      expect(p.isManual, isTrue);
      expect(p.modeLabel, 'يدوي');
    });

    test('الإزاحة لا تخرج عن حدود اليوم', () {
      final PrayerSlot p = slot()..offsetMinutes = -30;
      final int r = p.resolve(10); // 00:10 ناقص 30 دقيقة
      expect(r >= 0 && r < 1440, isTrue);
      expect(r, TimeUtils.hmToMinutes(23, 40));
    });

    test('الحفظ والاسترجاع يحفظان التعديل', () {
      final PrayerSettings ps = PrayerSettings();
      ps.slots[2].offsetMinutes = 7;
      ps.slots[3].manualMinuteOfDay = TimeUtils.hmToMinutes(18, 55);
      final PrayerSettings back = PrayerSettings.fromJson(ps.toJson());
      expect(back.slots[2].offsetMinutes, 7);
      expect(back.slots[3].manualMinuteOfDay, TimeUtils.hmToMinutes(18, 55));
      expect(back.slots[0].offsetMinutes, 0);
      expect(back.slots[0].manualMinuteOfDay, isNull);
    });

    test('resolvedMinute في الإعدادات يستخدم التعديل', () {
      final PrayerSettings ps = PrayerSettings();
      ps.slots[2].offsetMinutes = 5;
      final PrayerTimesResult t = PrayerTimesService.forDate(
        date: DateTime(2026, 9, 26),
        latitude: 30.0444,
        longitude: 31.2357,
        timeZoneHours: 3,
      );
      expect(ps.resolvedMinute(ps.slots[2], t), t.asr + 5);
    });
  });

  group('إعدادات الصلاة', () {
    test('الافتراضي: العصر والمغرب والعشاء محتسبة', () {
      final PrayerSettings ps = PrayerSettings();
      expect(ps.autoEnabled, isTrue);
      expect(ps.cityName, 'القاهرة');
      final Map<String, PrayerSlot> byKey = <String, PrayerSlot>{
        for (final PrayerSlot s in ps.slots) s.key: s,
      };
      expect(byKey['asr']!.enabled, isTrue);
      expect(byKey['asr']!.durationMinutes, 25);
      expect(byKey['maghrib']!.durationMinutes, 45);
      expect(byKey['isha']!.durationMinutes, 30);
      expect(byKey['fajr']!.enabled, isFalse);
      expect(byKey['dhuhr']!.enabled, isFalse);
    });

    test('الحفظ والاسترجاع لا يفقدان شيئًا', () {
      final PrayerSettings ps = PrayerSettings(cityName: 'أسيوط');
      ps.slots.first.durationMinutes = 15;
      final PrayerSettings back = PrayerSettings.fromJson(ps.toJson());
      expect(back.cityName, 'أسيوط');
      expect(back.slots.first.durationMinutes, 15);
      expect(back.slots.length, ps.slots.length);
    });
  });
}
