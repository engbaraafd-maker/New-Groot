import 'package:flutter/widgets.dart';

import '../services/app_repository.dart';

/// وصول بسيط لحالة التطبيق بدون أي حزم خارجية لإدارة الحالة.
class AppScope extends InheritedNotifier<AppRepository> {
  const AppScope({
    super.key,
    required AppRepository repository,
    required super.child,
  }) : super(notifier: repository);

  static AppRepository of(BuildContext context) {
    final AppScope? scope =
        context.dependOnInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope غير موجود في شجرة الويدجتس');
    return scope!.notifier!;
  }

  /// قراءة بدون اشتراك في التحديثات.
  static AppRepository read(BuildContext context) {
    final AppScope? scope =
        context.getInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope غير موجود في شجرة الويدجتس');
    return scope!.notifier!;
  }
}
