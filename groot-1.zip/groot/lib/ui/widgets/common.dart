import 'package:flutter/material.dart';

import '../../core/time_utils.dart';
import '../theme.dart';
import 'ornament.dart';

/// شريط علوي موحّد: كحلي بزخرفة نجوم ذهبية وخط ذهبي سفلي.
class GrootAppBar extends StatelessWidget implements PreferredSizeWidget {
  const GrootAppBar({super.key, required this.title, this.actions});

  final String title;
  final List<Widget>? actions;

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight + 1);

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    return AppBar(
      elevation: 0,
      centerTitle: false,
      backgroundColor: GrootPalette.navyDeep,
      foregroundColor: scheme.onPrimaryContainer,
      iconTheme: const IconThemeData(color: GrootPalette.goldLight),
      title: Text(
        title,
        style: GrootTheme.display(22, GrootPalette.goldLight),
      ),
      actions: actions,
      flexibleSpace: const ClipRect(
        child: Stack(
          children: <Widget>[
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: <Color>[
                      GrootPalette.navyDeepest,
                      GrootPalette.navy,
                    ],
                  ),
                ),
              ),
            ),
            Positioned.fill(
              child: GeometricOrnament(
                color: GrootPalette.gold,
                opacity: 0.09,
                cell: 46,
              ),
            ),
          ],
        ),
      ),
      bottom: const PreferredSize(
        preferredSize: Size.fromHeight(1),
        child: SizedBox(
          height: 1,
          width: double.infinity,
          child: ColoredBox(color: GrootPalette.goldDeep),
        ),
      ),
    );
  }
}

/// بطاقة قسم بعنوان واضح وخط ذهبي رفيع تحته.
class SectionCard extends StatelessWidget {
  const SectionCard({
    super.key,
    required this.title,
    required this.child,
    this.icon,
    this.trailing,
  });

  final String title;
  final Widget child;
  final IconData? icon;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
      decoration: BoxDecoration(
        color: GrootTheme.cardColor(scheme),
        borderRadius: const BorderRadius.all(Radius.circular(16)),
        border: Border.all(color: GrootTheme.hairline(scheme)),
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                if (icon != null) ...<Widget>[
                  Icon(icon, color: scheme.tertiary, size: 22),
                  const SizedBox(width: 10),
                ],
                Expanded(
                  child: Text(
                    title,
                    style: GrootTheme.display(19, scheme.onSurface),
                  ),
                ),
                if (trailing != null) trailing!,
              ],
            ),
            const SizedBox(height: 6),
            Align(
              alignment: AlignmentDirectional.centerStart,
              child: GoldRule(color: scheme.tertiary, width: 72),
            ),
            const SizedBox(height: 10),
            child,
          ],
        ),
      ),
    );
  }
}

/// زر كبير للشاشة الرئيسية — كحلي بحواف ذهبية.
class BigMenuButton extends StatelessWidget {
  const BigMenuButton({
    super.key,
    required this.label,
    required this.icon,
    required this.onTap,
    this.subtitle,
  });

  final String label;
  final String? subtitle;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    final Color gold = scheme.onPrimaryContainer;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
      child: Material(
        color: scheme.primaryContainer,
        borderRadius: const BorderRadius.all(Radius.circular(16)),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: onTap,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: const BorderRadius.all(Radius.circular(16)),
              border: Border.all(color: GrootPalette.goldDeep, width: 1),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
            child: Row(
              children: <Widget>[
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: gold, width: 1.2),
                  ),
                  child: Icon(icon, size: 23, color: gold),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        label,
                        style: GrootTheme.display(20, gold),
                      ),
                      if (subtitle != null)
                        Padding(
                          padding: const EdgeInsets.only(top: 3),
                          child: Text(
                            subtitle!,
                            style: const TextStyle(
                              fontSize: 14,
                              color: GrootPalette.tan,
                              height: 1.35,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
                Icon(Icons.chevron_left,
                    color: GrootPalette.copperLight, size: 26),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// رسالة عند عدم وجود بيانات.
class EmptyHint extends StatelessWidget {
  const EmptyHint({super.key, required this.message, this.icon});

  final String message;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.all(28),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Icon(icon ?? Icons.inbox_outlined, size: 56, color: scheme.outline),
          const SizedBox(height: 12),
          Text(
            message,
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 17, color: scheme.onSurfaceVariant),
          ),
        ],
      ),
    );
  }
}

/// شريط تنبيه عربي واضح.
class WarningBanner extends StatelessWidget {
  const WarningBanner({
    super.key,
    required this.messages,
    this.isError = false,
  });

  final List<String> messages;
  final bool isError;

  @override
  Widget build(BuildContext context) {
    if (messages.isEmpty) return const SizedBox.shrink();
    final ColorScheme scheme = Theme.of(context).colorScheme;
    final Color bg = isError ? scheme.errorContainer : scheme.tertiaryContainer;
    final Color fg =
        isError ? scheme.onErrorContainer : scheme.onTertiaryContainer;
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: const BorderRadius.all(Radius.circular(16)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Icon(
                isError ? Icons.error_outline : Icons.info_outline,
                color: fg,
              ),
              const SizedBox(width: 8),
              Text(
                isError ? 'يوجد خطأ' : 'تنبيهات',
                style: TextStyle(
                    color: fg, fontWeight: FontWeight.bold, fontSize: 17),
              ),
            ],
          ),
          const SizedBox(height: 6),
          for (final String m in messages)
            Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: Text('• $m', style: TextStyle(color: fg, fontSize: 15.5)),
            ),
        ],
      ),
    );
  }
}

/// خيار واحد من مجموعة خيارات (بديل بسيط ومستقر عن RadioListTile).
class ChoiceTile extends StatelessWidget {
  const ChoiceTile({
    super.key,
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    return InkWell(
      onTap: onTap,
      borderRadius: const BorderRadius.all(Radius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Icon(
              selected ? Icons.radio_button_checked : Icons.radio_button_off,
              color: selected ? scheme.primary : scheme.outline,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                label,
                style: TextStyle(
                  fontSize: 15.5,
                  fontWeight: selected ? FontWeight.w700 : FontWeight.normal,
                  color: selected ? scheme.primary : scheme.onSurface,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// حقل اختيار وقت بالساعة والدقيقة.
class TimeField extends StatelessWidget {
  const TimeField({
    super.key,
    required this.label,
    required this.minuteOfDay,
    required this.onChanged,
  });

  final String label;
  final int minuteOfDay;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: const BorderRadius.all(Radius.circular(14)),
      onTap: () async {
        final TimeOfDay? picked = await showTimePicker(
          context: context,
          initialTime: TimeOfDay(
            hour: minuteOfDay ~/ 60,
            minute: minuteOfDay % 60,
          ),
          builder: (BuildContext context, Widget? child) {
            return MediaQuery(
              data: MediaQuery.of(context)
                  .copyWith(alwaysUse24HourFormat: true),
              child: child ?? const SizedBox.shrink(),
            );
          },
        );
        if (picked != null) {
          onChanged(picked.hour * 60 + picked.minute);
        }
      },
      child: InputDecorator(
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(14)),
          ),
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        ),
        child: Row(
          children: <Widget>[
            const Icon(Icons.schedule, size: 22),
            const SizedBox(width: 10),
            Text(
              TimeUtils.formatHm(minuteOfDay),
              style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w600),
            ),
          ],
        ),
      ),
    );
  }
}

/// حقل رقمي بسيط (دقائق).
class MinutesField extends StatelessWidget {
  const MinutesField({
    super.key,
    required this.label,
    required this.controller,
  });

  final String label;
  final TextEditingController controller;

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      keyboardType: TextInputType.number,
      decoration: InputDecoration(
        labelText: label,
        suffixText: 'دقيقة',
        border: const OutlineInputBorder(
          borderRadius: BorderRadius.all(Radius.circular(14)),
        ),
      ),
    );
  }
}

/// حوار تأكيد.
Future<bool> confirmDialog(
  BuildContext context, {
  required String title,
  required String message,
  String confirmLabel = 'تأكيد',
}) async {
  final bool? result = await showDialog<bool>(
    context: context,
    builder: (BuildContext ctx) => AlertDialog(
      title: Text(title),
      content: Text(message),
      actions: <Widget>[
        TextButton(
          onPressed: () => Navigator.of(ctx).pop(false),
          child: const Text('إلغاء'),
        ),
        FilledButton(
          onPressed: () => Navigator.of(ctx).pop(true),
          child: Text(confirmLabel),
        ),
      ],
    ),
  );
  return result ?? false;
}

/// عرض رسالة سريعة.
void showMessage(BuildContext context, String message, {bool error = false}) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(message, style: const TextStyle(fontSize: 16)),
      backgroundColor: error ? Theme.of(context).colorScheme.error : null,
      duration: const Duration(seconds: 3),
    ),
  );
}
