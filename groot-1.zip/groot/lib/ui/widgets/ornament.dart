import 'dart:math' as math;

import 'package:flutter/material.dart';

/// زخرفة هندسية إسلامية: شبكة نجوم ثمانية مرسومة بالكود، بلا أي صور.
///
/// تُستخدم خلفيةً خفيفة تحت العناوين لإضفاء طابع الأصالة دون إثقال الشاشة.
class GeometricOrnament extends StatelessWidget {
  const GeometricOrnament({
    super.key,
    required this.color,
    this.opacity = 0.14,
    this.cell = 54,
    this.strokeWidth = 1.1,
  });

  final Color color;
  final double opacity;
  final double cell;
  final double strokeWidth;

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Opacity(
        opacity: opacity,
        child: CustomPaint(
          painter: _StarLatticePainter(
            color: color,
            cell: cell,
            strokeWidth: strokeWidth,
          ),
          size: Size.infinite,
        ),
      ),
    );
  }
}

class _StarLatticePainter extends CustomPainter {
  _StarLatticePainter({
    required this.color,
    required this.cell,
    required this.strokeWidth,
  });

  final Color color;
  final double cell;
  final double strokeWidth;

  @override
  void paint(Canvas canvas, Size size) {
    final Paint paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..color = color
      ..isAntiAlias = true;

    final double r = cell * 0.40;
    for (double y = -cell; y < size.height + cell; y += cell) {
      for (double x = -cell; x < size.width + cell; x += cell) {
        _eightPointStar(canvas, Offset(x + cell / 2, y + cell / 2), r, paint);
      }
    }
  }

  /// نجمة ثمانية = مربعان متداخلان بزاوية 45 درجة.
  void _eightPointStar(Canvas canvas, Offset center, double r, Paint paint) {
    for (int k = 0; k < 2; k++) {
      final Path path = Path();
      final double rotation = k * math.pi / 4;
      for (int i = 0; i < 4; i++) {
        final double angle = rotation + i * math.pi / 2;
        final Offset point = Offset(
          center.dx + r * math.cos(angle),
          center.dy + r * math.sin(angle),
        );
        if (i == 0) {
          path.moveTo(point.dx, point.dy);
        } else {
          path.lineTo(point.dx, point.dy);
        }
      }
      path.close();
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _StarLatticePainter oldDelegate) {
    return oldDelegate.color != color ||
        oldDelegate.cell != cell ||
        oldDelegate.strokeWidth != strokeWidth;
  }
}

/// خط فاصل ذهبي رفيع بمعيّن صغير في منتصفه.
class GoldRule extends StatelessWidget {
  const GoldRule({super.key, required this.color, this.width = 90});

  final Color color;
  final double width;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      height: 10,
      child: CustomPaint(painter: _RulePainter(color)),
    );
  }
}

class _RulePainter extends CustomPainter {
  _RulePainter(this.color);

  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final Paint paint = Paint()
      ..color = color
      ..strokeWidth = 1.2
      ..style = PaintingStyle.stroke
      ..isAntiAlias = true;

    final double cy = size.height / 2;
    final double gap = 7;
    canvas.drawLine(Offset(0, cy), Offset(size.width / 2 - gap, cy), paint);
    canvas.drawLine(
        Offset(size.width / 2 + gap, cy), Offset(size.width, cy), paint);

    final Path diamond = Path()
      ..moveTo(size.width / 2, cy - 4)
      ..lineTo(size.width / 2 + 4, cy)
      ..lineTo(size.width / 2, cy + 4)
      ..lineTo(size.width / 2 - 4, cy)
      ..close();
    canvas.drawPath(diamond, paint..style = PaintingStyle.fill);
  }

  @override
  bool shouldRepaint(covariant _RulePainter oldDelegate) =>
      oldDelegate.color != color;
}
