import 'package:flutter/material.dart';

import '../models/group.dart';
import '../models/user.dart';
import '../services/app_repository.dart';
import 'app_scope.dart';
import 'widgets/common.dart';

class GroupsScreen extends StatelessWidget {
  const GroupsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final AppRepository repo = AppScope.of(context);
    final List<User> unassigned = repo.unassignedUsers;

    return Scaffold(
      appBar: const GrootAppBar(title: 'المجموعات'),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 24),
        children: <Widget>[
          SectionCard(
            title: 'إنشاء / إعادة توزيع',
            icon: Icons.auto_awesome_motion_outlined,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  'المستخدمون: ${repo.users.length}   •   '
                  'الأجهزة النشطة: ${repo.activeDevices.length}',
                  style: const TextStyle(fontSize: 16),
                ),
                const SizedBox(height: 6),
                const Text(
                  'المجموعات ثابتة الأعضاء. التدوير اليومي يغيّر الجهاز فقط '
                  'ولا يغيّر أعضاء المجموعة. إعادة التوزيع لا تحدث إلا بضغطك '
                  'على الزر بالأسفل.',
                  style: TextStyle(fontSize: 15),
                ),
                const SizedBox(height: 12),
                FilledButton.icon(
                  onPressed: repo.activeDevices.isEmpty || repo.users.isEmpty
                      ? null
                      : () => _rebuild(context, repo),
                  icon: const Icon(Icons.refresh),
                  label: const Text('إعادة توزيع المستخدمين على المجموعات'),
                ),
              ],
            ),
          ),
          if (unassigned.isNotEmpty)
            WarningBanner(
              messages: <String>[
                'يوجد ${unassigned.length} مستخدم بدون مجموعة: '
                    '${unassigned.map((User u) => u.name).join('، ')}. '
                    'اضغط «إعادة توزيع» لإدراجهم.',
              ],
            ),
          if (repo.groups.isEmpty)
            const EmptyHint(
              message: 'لم تُنشأ مجموعات بعد.\n'
                  'أضف المستخدمين والأجهزة ثم اضغط «إعادة التوزيع».',
              icon: Icons.groups_2_outlined,
            ),
          for (final Group g in repo.groups) _GroupCard(group: g, repo: repo),
        ],
      ),
    );
  }

  Future<void> _rebuild(BuildContext context, AppRepository repo) async {
    final bool ok = await confirmDialog(
      context,
      title: 'إعادة التوزيع',
      message:
          'سيتم توزيع ${repo.users.length} مستخدمًا على '
          '${repo.activeDevices.length} مجموعة بالتساوي قدر الإمكان، '
          'وسيتغيّر تشكيل المجموعات الحالي. هل تريد المتابعة؟',
      confirmLabel: 'إعادة التوزيع',
    );
    if (!ok) return;
    await repo.rebuildGroups();
    if (context.mounted) {
      showMessage(context, 'تم إنشاء ${repo.groups.length} مجموعة.');
    }
  }
}

class _GroupCard extends StatelessWidget {
  const _GroupCard({required this.group, required this.repo});

  final Group group;
  final AppRepository repo;

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      title: '${group.name} (${group.size})',
      icon: Icons.group_outlined,
      trailing: IconButton(
        tooltip: 'تعديل الاسم',
        icon: const Icon(Icons.edit_outlined),
        onPressed: () => _rename(context),
      ),
      child: group.memberIds.isEmpty
          ? const Text('لا يوجد أعضاء في هذه المجموعة.',
              style: TextStyle(fontSize: 15))
          : Column(
              children: <Widget>[
                for (int i = 0; i < group.memberIds.length; i++)
                  ListTile(
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                    leading: CircleAvatar(
                      radius: 15,
                      child: Text('${i + 1}',
                          style: const TextStyle(fontSize: 14)),
                    ),
                    title: Text(
                      repo.userById(group.memberIds[i])?.name ?? '—',
                      style: const TextStyle(fontSize: 17),
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        IconButton(
                          tooltip: 'لأعلى',
                          icon: const Icon(Icons.arrow_upward, size: 20),
                          onPressed: i == 0
                              ? null
                              : () => repo.reorderGroupMember(group.id, i, i - 1),
                        ),
                        IconButton(
                          tooltip: 'لأسفل',
                          icon: const Icon(Icons.arrow_downward, size: 20),
                          onPressed: i == group.memberIds.length - 1
                              ? null
                              : () => repo.reorderGroupMember(group.id, i, i + 2),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
    );
  }

  Future<void> _rename(BuildContext context) async {
    final TextEditingController ctrl = TextEditingController(text: group.name);
    final bool? ok = await showDialog<bool>(
      context: context,
      builder: (BuildContext ctx) => AlertDialog(
        title: const Text('اسم المجموعة'),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          decoration: const InputDecoration(border: OutlineInputBorder()),
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('حفظ'),
          ),
        ],
      ),
    );
    if (ok == true && ctrl.text.trim().isNotEmpty) {
      await repo.renameGroup(group.id, ctrl.text);
    }
  }
}
