import 'package:flutter/material.dart';

import '../core/time_utils.dart';
import '../models/schedule_entry.dart';
import '../models/schedule_report.dart';
import '../services/app_repository.dart';
import 'app_scope.dart';
import 'theme.dart';
import 'widgets/common.dart';

/// شاشة «جدول اليوم»: التقرير الزمني التفصيلي لكل جهاز.
class DayScheduleScreen extends StatefulWidget {
  const DayScheduleScreen({super.key, required this.date});

  final DateTime date;

  @override
  State<DayScheduleScreen> createState() => _DayScheduleScreenState();
}

class _DayScheduleScreenState extends State<DayScheduleScreen> {
  late DateTime _date = widget.date;

  @override
  Widget build(BuildContext context) {
    final AppRepository repo = AppScope.of(context);
    final ScheduleComputation result = repo.computeDay(_date);

    return Scaffold(
      appBar: const GrootAppBar(title: 'جدول اليوم'),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 30),
        children: <Widget>[
          SectionCard(
            title: TimeUtils.formatDateArabic(_date),
            icon: Icons.calendar_today_outlined,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  'دورة اليوم: ${repo.cycleNumberFor(_date)} من '
                  '${repo.activeDevices.length}   •   '
                  'الفترة: ${repo.settings.period.startLabel} ← '
                  '${repo.settings.period.endLabel}',
                  style: const TextStyle(fontSize: 15.5),
                ),
                const SizedBox(height: 10),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => setState(() =>
                            _date = _date.subtract(const Duration(days: 1))),
                        icon: const Icon(Icons.chevron_right),
                        label: const Text('السابق'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => setState(
                            () => _date = _date.add(const Duration(days: 1))),
                        icon: const Icon(Icons.chevron_left),
                        label: const Text('التالي'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          if (result.errors.isNotEmpty)
            WarningBanner(messages: result.errors, isError: true),
          if (!result.hasReports && result.errors.isEmpty)
            const EmptyHint(
              message: 'لا توجد بيانات كافية لحساب الجدول.',
              icon: Icons.hourglass_empty,
            ),
          for (final ScheduleReport r in result.reports) _ReportCard(report: r),
          if (result.hasReports)
            _OverallSummaryCard(
              reports: result.reports,
              deviceCount: repo.activeDevices.length,
              groupCount: repo.groups.length,
              userCount: repo.users.length,
            ),
        ],
      ),
    );
  }
}

/// الملخص العام لكل الأجهزة مجتمعة (البند 20).
class _OverallSummaryCard extends StatelessWidget {
  const _OverallSummaryCard({
    required this.reports,
    required this.deviceCount,
    required this.groupCount,
    required this.userCount,
  });

  final List<ScheduleReport> reports;
  final int deviceCount;
  final int groupCount;
  final int userCount;

  @override
  Widget build(BuildContext context) {
    int operating = 0;
    int prayer = 0;
    int rest = 0;
    int downtime = 0;
    int planned = 0;
    int deducted = 0;
    for (final ScheduleReport r in reports) {
      operating += r.summary.operatingMinutes;
      prayer += r.summary.prayerMinutes;
      rest += r.summary.restMinutes;
      downtime += r.summary.downtimeMinutes;
      planned += r.summary.plannedOperatingMinutes;
      deducted += r.summary.deductedLostMinutes;
    }

    final List<List<String>> rows = <List<String>>[
      <String>['عدد الأجهزة النشطة', '$deviceCount'],
      <String>['عدد المجموعات', '$groupCount'],
      <String>['عدد المستخدمين', '$userCount'],
      <String>['وقت التشغيل المخطط (كل الأجهزة)',
        TimeUtils.formatDuration(planned)],
      <String>['إجمالي وقت التشغيل الفعلي',
        TimeUtils.formatDuration(operating)],
      <String>['إجمالي الصلاة', TimeUtils.formatDuration(prayer)],
      <String>['إجمالي الراحة', TimeUtils.formatDuration(rest)],
      <String>['إجمالي الأعطال', TimeUtils.formatDuration(downtime)],
      <String>['إجمالي المخصوم من الحصص',
        TimeUtils.formatDuration(deducted)],
    ];

    return SectionCard(
      title: 'الملخص العام لكل الأجهزة',
      icon: Icons.summarize_outlined,
      child: Column(
        children: <Widget>[
          for (final List<String> r in rows)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 2.5),
              child: Row(
                children: <Widget>[
                  Expanded(
                      child: Text(r[0], style: const TextStyle(fontSize: 15))),
                  Text(r[1],
                      style: const TextStyle(
                          fontSize: 15, fontWeight: FontWeight.w600)),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

class _ReportCard extends StatelessWidget {
  const _ReportCard({required this.report});

  final ScheduleReport report;

  @override
  Widget build(BuildContext context) {
    final ScheduleSummary s = report.summary;
    return SectionCard(
      title: '${report.deviceName ?? 'جهاز'} — ${report.groupName ?? ''}',
      icon: Icons.smartphone,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            'من ${report.startLabel} إلى ${report.endLabel}',
            style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
          ),
          if (report.overtimeMinutes > 0)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(
                'امتد الجدول ${TimeUtils.formatDuration(report.overtimeMinutes)} '
                'بعد وقت النهاية بسبب التوقفات التعويضية.',
                style: const TextStyle(fontSize: 14.5),
              ),
            ),
          const SizedBox(height: 12),
          if (report.warnings.isNotEmpty) ...<Widget>[
            WarningBanner(messages: report.warnings),
            const SizedBox(height: 6),
          ],
          const Text('الخط الزمني',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          for (final TimelineSegment seg in report.timeline)
            _SegmentRow(segment: seg),
          const SizedBox(height: 14),
          const Text('تقرير كل مستخدم',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          for (final ScheduleEntry e in report.entries) _EntryTile(entry: e),
          const SizedBox(height: 14),
          const Text('الملخص العام',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          _SummaryTable(summary: s),
          const SizedBox(height: 6),
          Text(
            s.isConsistent
                ? '✓ الأرقام متوافقة رياضيًا.'
                : '✗ تحذير: الأرقام غير متوافقة، راجع الأحداث المدخلة.',
            style: TextStyle(
              fontSize: 14.5,
              color: s.isConsistent
                  ? Theme.of(context).colorScheme.primary
                  : Theme.of(context).colorScheme.error,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

class _SegmentRow extends StatelessWidget {
  const _SegmentRow({required this.segment});

  final TimelineSegment segment;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    final Color color = GrootTheme.segmentColor(scheme, segment.type.name);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            width: 6,
            height: 40,
            decoration: BoxDecoration(
              color: color,
              borderRadius: const BorderRadius.all(Radius.circular(3)),
            ),
          ),
          const SizedBox(width: 10),
          SizedBox(
            width: 116,
            child: Text(
              segment.rangeLabel,
              style: const TextStyle(fontSize: 15.5, fontWeight: FontWeight.w600),
            ),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  segment.type == SegmentType.operating
                      ? '${segment.label} — ${segment.userName ?? ''}'
                      : segment.label,
                  style: TextStyle(fontSize: 15.5, color: color),
                ),
                Text(
                  '${TimeUtils.formatDuration(segment.durationMinutes)}'
                  '${segment.betweenTurns ? ' • بين الدورين' : ''}',
                  style: TextStyle(
                      fontSize: 13.5, color: scheme.onSurfaceVariant),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _EntryTile extends StatelessWidget {
  const _EntryTile({required this.entry});

  final ScheduleEntry entry;

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
      child: ExpansionTile(
        tilePadding: EdgeInsets.zero,
        title: Text(
          '${entry.orderInGroup}. ${entry.userName}',
          style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
        ),
        subtitle: Text(
          '${entry.turnStartLabel} ← ${entry.turnEndLabel}  •  '
          'تشغيل ${TimeUtils.formatDuration(entry.operatingMinutes)}',
          style: const TextStyle(fontSize: 14.5),
        ),
        children: <Widget>[
          _kv('الجهاز', entry.deviceName ?? '—'),
          _kv('المجموعة', entry.groupName ?? '—'),
          _kv('ترتيبه داخل المجموعة', '${entry.orderInGroup}'),
          _kv('بداية الدور', entry.turnStartLabel),
          _kv('نهاية الدور', entry.turnEndLabel),
          _kv('الحصة المخططة',
              TimeUtils.formatDuration(entry.plannedShareMinutes)),
          _kv('إجمالي وقت التشغيل',
              TimeUtils.formatDuration(entry.operatingMinutes)),
          _kv('إجمالي التوقف (صلاة + راحة)',
              TimeUtils.formatDuration(entry.pauseMinutes)),
          _kv('منها صلاة', TimeUtils.formatDuration(entry.prayerMinutes)),
          _kv('منها راحة', TimeUtils.formatDuration(entry.restMinutes)),
          _kv('الأعطال أثناء دوره',
              TimeUtils.formatDuration(entry.downtimeMinutes)),
          _kv('المخصوم من حصته بسبب الأعطال',
              TimeUtils.formatDuration(entry.lostShareMinutes)),
          const SizedBox(height: 6),
          const Align(
            alignment: AlignmentDirectional.centerStart,
            child: Text('الأحداث أثناء دوره:',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
          ),
          for (final TimelineSegment seg in entry.segments)
            Padding(
              padding: const EdgeInsets.only(top: 2),
              child: Align(
                alignment: AlignmentDirectional.centerStart,
                child: Text(
                  '• ${seg.rangeLabel}  ${seg.label}'
                  ' (${TimeUtils.formatDuration(seg.durationMinutes)})',
                  style: const TextStyle(fontSize: 14.5),
                ),
              ),
            ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }

  Widget _kv(String k, String v) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        children: <Widget>[
          Expanded(child: Text(k, style: const TextStyle(fontSize: 15))),
          Text(v,
              style:
                  const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

class _SummaryTable extends StatelessWidget {
  const _SummaryTable({required this.summary});

  final ScheduleSummary summary;

  @override
  Widget build(BuildContext context) {
    final List<List<String>> rows = <List<String>>[
      <String>['إجمالي الفترة', TimeUtils.formatDuration(summary.periodMinutes)],
      <String>['امتداد الجدول الفعلي',
        TimeUtils.formatDuration(summary.spanMinutes)],
      <String>['وقت التشغيل المخطط',
        TimeUtils.formatDuration(summary.plannedOperatingMinutes)],
      <String>['إجمالي وقت التشغيل الفعلي',
        TimeUtils.formatDuration(summary.operatingMinutes)],
      <String>['إجمالي الصلاة', TimeUtils.formatDuration(summary.prayerMinutes)],
      <String>['إجمالي الراحة', TimeUtils.formatDuration(summary.restMinutes)],
      <String>['إجمالي الأعطال',
        TimeUtils.formatDuration(summary.downtimeMinutes)],
      <String>['إجمالي الوقت الضائع',
        TimeUtils.formatDuration(summary.lostMinutes)],
      <String>['المخصوم من الحصص',
        TimeUtils.formatDuration(summary.deductedLostMinutes)],
      if (summary.unallocatedLostMinutes > 0)
        <String>['ضياع لم يُخصم',
          TimeUtils.formatDuration(summary.unallocatedLostMinutes)],
      <String>['عدد المستخدمين على هذا الجهاز', '${summary.userCount}'],
    ];

    return Column(
      children: <Widget>[
        for (final List<String> r in rows)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 2.5),
            child: Row(
              children: <Widget>[
                Expanded(child: Text(r[0], style: const TextStyle(fontSize: 15))),
                Text(
                  r[1],
                  style: const TextStyle(
                      fontSize: 15, fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ),
      ],
    );
  }
}
