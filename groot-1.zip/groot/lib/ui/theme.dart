import 'package:flutter/material.dart';

/// لوحة ألوان Groot — أصالة ووقار.
///
/// كحلي عميق للأساس، زمردي للفعل، ذهبي ونحاسي للتفاصيل، وبيج دافئ للأسطح.
class GrootPalette {
  const GrootPalette._();

  // الكحلي العميق
  static const Color navyDeepest = Color(0xFF081824);
  static const Color navyDeep = Color(0xFF0E2434);
  static const Color navy = Color(0xFF143349);
  static const Color navySoft = Color(0xFF1D4361);

  // الزمردي
  static const Color emeraldDeep = Color(0xFF0A5C42);
  static const Color emerald = Color(0xFF0E7A57);
  static const Color emeraldLight = Color(0xFF2FA37B);

  // الذهبي
  static const Color goldDeep = Color(0xFFA8842A);
  static const Color gold = Color(0xFFC9A227);
  static const Color goldLight = Color(0xFFE3C567);

  // النحاسي
  static const Color copperDeep = Color(0xFF8C4E2A);
  static const Color copper = Color(0xFFB87333);
  static const Color copperLight = Color(0xFFD08F5A);

  // البيج الدافئ
  static const Color tanDeep = Color(0xFFB9A88F);
  static const Color tan = Color(0xFFD8C3A5);
  static const Color tanLight = Color(0xFFEADFCB);
  static const Color ivory = Color(0xFFF9F5EC);

  // أحمر موقّر للأعطال
  static const Color crimson = Color(0xFF9B2C2C);
  static const Color crimsonLight = Color(0xFFD97A6C);
}

/// ثيم التطبيق: هادئ، فخم، وواضح على الشاشات الصغيرة.
class GrootTheme {
  const GrootTheme._();

  /// خط النصوص. إن لم يكن مضمّنًا في الحزمة يرجع Flutter لخط النظام تلقائيًا.
  static const String bodyFont = 'Tajawal';

  /// خط العناوين ذو الطابع الأصيل.
  static const String displayFont = 'Amiri';

  /// نمط العناوين الكبيرة بالخط الأصيل.
  static TextStyle display(double size, Color color, {FontWeight weight = FontWeight.w700}) {
    return TextStyle(
      fontFamily: displayFont,
      fontSize: size,
      fontWeight: weight,
      color: color,
      height: 1.3,
    );
  }

  static const TextTheme _textTheme = TextTheme(
    titleLarge: TextStyle(
        fontFamily: displayFont,
        fontSize: 23,
        fontWeight: FontWeight.w700,
        letterSpacing: 0.2),
    titleMedium: TextStyle(fontSize: 19, fontWeight: FontWeight.w700),
    titleSmall: TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
    bodyLarge: TextStyle(fontSize: 18, height: 1.45),
    bodyMedium: TextStyle(fontSize: 16.5, height: 1.45),
    bodySmall: TextStyle(fontSize: 15, height: 1.4),
    labelLarge: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
  );

  static ThemeData light() {
    final ColorScheme base = ColorScheme.fromSeed(
      seedColor: GrootPalette.emerald,
      brightness: Brightness.light,
    );
    final ColorScheme scheme = base.copyWith(
      primary: GrootPalette.emeraldDeep,
      onPrimary: GrootPalette.ivory,
      primaryContainer: GrootPalette.navyDeep,
      onPrimaryContainer: GrootPalette.goldLight,
      secondary: GrootPalette.copper,
      onSecondary: GrootPalette.ivory,
      secondaryContainer: GrootPalette.tanLight,
      onSecondaryContainer: GrootPalette.navyDeep,
      tertiary: GrootPalette.goldDeep,
      onTertiary: GrootPalette.navyDeepest,
      tertiaryContainer: GrootPalette.tanLight,
      onTertiaryContainer: GrootPalette.navyDeep,
      error: GrootPalette.crimson,
      onError: GrootPalette.ivory,
      errorContainer: const Color(0xFFF6DFD9),
      onErrorContainer: const Color(0xFF5E1A16),
      surface: GrootPalette.ivory,
      onSurface: GrootPalette.navyDeep,
      onSurfaceVariant: const Color(0xFF5C6B75),
      outline: GrootPalette.tanDeep,
      outlineVariant: const Color(0xFFE0D5C2),
    );
    return _build(scheme);
  }

  static ThemeData dark() {
    final ColorScheme base = ColorScheme.fromSeed(
      seedColor: GrootPalette.emerald,
      brightness: Brightness.dark,
    );
    final ColorScheme scheme = base.copyWith(
      primary: GrootPalette.emeraldLight,
      onPrimary: GrootPalette.navyDeepest,
      primaryContainer: GrootPalette.navy,
      onPrimaryContainer: GrootPalette.goldLight,
      secondary: GrootPalette.copperLight,
      onSecondary: GrootPalette.navyDeepest,
      secondaryContainer: GrootPalette.navySoft,
      onSecondaryContainer: GrootPalette.tanLight,
      tertiary: GrootPalette.goldLight,
      onTertiary: GrootPalette.navyDeepest,
      tertiaryContainer: const Color(0xFF3A3218),
      onTertiaryContainer: GrootPalette.goldLight,
      error: GrootPalette.crimsonLight,
      onError: GrootPalette.navyDeepest,
      errorContainer: const Color(0xFF4A1E1A),
      onErrorContainer: const Color(0xFFF3CFC8),
      surface: GrootPalette.navyDeepest,
      onSurface: GrootPalette.tanLight,
      onSurfaceVariant: const Color(0xFF9FB0BB),
      outline: const Color(0xFF4C5E6B),
      outlineVariant: const Color(0xFF26384A),
    );
    return _build(scheme);
  }

  static ThemeData _build(ColorScheme scheme) {
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      textTheme: _textTheme,
      fontFamily: bodyFont,
      scaffoldBackgroundColor: scheme.surface,
    );
  }

  /// لون بطاقة مرتفعة قليلًا عن الخلفية.
  static Color cardColor(ColorScheme scheme) {
    return scheme.brightness == Brightness.light
        ? Colors.white
        : GrootPalette.navyDeep;
  }

  /// لون الحد الرفيع حول البطاقات.
  static Color hairline(ColorScheme scheme) {
    return scheme.brightness == Brightness.light
        ? const Color(0xFFE6DAC6)
        : const Color(0xFF203648);
  }

  /// ألوان مقاطع الخط الزمني.
  static Color segmentColor(ColorScheme scheme, String type) {
    final bool isLight = scheme.brightness == Brightness.light;
    switch (type) {
      case 'operating':
        return isLight ? GrootPalette.emeraldDeep : GrootPalette.emeraldLight;
      case 'prayer':
        return isLight ? GrootPalette.goldDeep : GrootPalette.goldLight;
      case 'rest':
        return isLight ? GrootPalette.copper : GrootPalette.copperLight;
      case 'downtime':
        return isLight ? GrootPalette.crimson : GrootPalette.crimsonLight;
      default:
        return scheme.outline;
    }
  }

  static ButtonStyle bigButtonStyle() => FilledButton.styleFrom(
        minimumSize: const Size.fromHeight(58),
        textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(14)),
        ),
      );
}
