import 'package:flutter/material.dart';

import '../models/group.dart';
import '../models/user.dart';
import '../services/app_repository.dart';
import 'app_scope.dart';
import 'widgets/common.dart';

class UsersScreen extends StatelessWidget {
  const UsersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final AppRepository repo = AppScope.of(context);
    final DateTime today = DateTime.now();

    return Scaffold(
      appBar: const GrootAppBar(title: 'المستخدمون'),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _editUser(context, repo, null),
        icon: const Icon(Icons.person_add_alt),
        label: const Text('إضافة مستخدم'),
      ),
      body: repo.users.isEmpty
          ? const EmptyHint(
              message: 'لا يوجد مستخدمون بعد.\nاضغط «إضافة مستخدم» للبدء.',
              icon: Icons.people_outline,
            )
          : Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                  child: Row(
                    children: <Widget>[
                      Expanded(
                        child: Text(
                          'العدد: ${repo.users.length} — اسحب لإعادة الترتيب',
                          style: const TextStyle(fontSize: 15),
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: ReorderableListView.builder(
                    padding: const EdgeInsets.only(bottom: 90),
                    itemCount: repo.users.length,
                    onReorder: repo.reorderUsers,
                    itemBuilder: (BuildContext context, int index) {
                      final User u = repo.users[index];
                      final Group? g = repo.groupOfUser(u.id);
                      final int order = repo.orderOfUserInGroup(u.id, today);
                      return Card(
                        key: ValueKey<String>(u.id),
                        margin: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 5),
                        shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(Radius.circular(16)),
                        ),
                        child: ListTile(
                          leading: CircleAvatar(
                            child: Text('${index + 1}'),
                          ),
                          title: Text(
                            u.name,
                            style: const TextStyle(
                                fontSize: 18, fontWeight: FontWeight.w600),
                          ),
                          subtitle: Text(
                            g == null
                                ? 'بدون مجموعة — أعد التوزيع من شاشة المجموعات'
                                : '${g.name} • ترتيبه اليوم: $order',
                            style: const TextStyle(fontSize: 14.5),
                          ),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              PopupMenuButton<String>(
                                tooltip: 'خيارات',
                                onSelected: (String value) {
                                  if (value == 'edit') {
                                    _editUser(context, repo, u);
                                  } else if (value == 'delete') {
                                    _deleteUser(context, repo, u);
                                  }
                                },
                                itemBuilder: (BuildContext _) =>
                                    <PopupMenuEntry<String>>[
                                  const PopupMenuItem<String>(
                                    value: 'edit',
                                    child: Text('تعديل'),
                                  ),
                                  const PopupMenuItem<String>(
                                    value: 'delete',
                                    child: Text('حذف'),
                                  ),
                                ],
                              ),
                              const Icon(Icons.drag_handle),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
    );
  }

  Future<void> _deleteUser(
      BuildContext context, AppRepository repo, User u) async {
    final bool ok = await confirmDialog(
      context,
      title: 'حذف مستخدم',
      message: 'سيتم حذف «${u.name}» من القائمة ومن مجموعته. هل تريد المتابعة؟',
      confirmLabel: 'حذف',
    );
    if (!ok) return;
    await repo.deleteUser(u.id);
    if (context.mounted) {
      showMessage(context, 'تم حذف «${u.name}».');
    }
  }

  Future<void> _editUser(
      BuildContext context, AppRepository repo, User? user) async {
    final TextEditingController nameCtrl =
        TextEditingController(text: user?.name ?? '');
    final TextEditingController noteCtrl =
        TextEditingController(text: user?.note ?? '');

    final bool? saved = await showDialog<bool>(
      context: context,
      builder: (BuildContext ctx) {
        String? error;
        return StatefulBuilder(
          builder: (BuildContext ctx, StateSetter setState) {
            return AlertDialog(
              title: Text(user == null ? 'إضافة مستخدم' : 'تعديل مستخدم'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  TextField(
                    controller: nameCtrl,
                    autofocus: true,
                    decoration: InputDecoration(
                      labelText: 'الاسم',
                      errorText: error,
                      border: const OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: noteCtrl,
                    decoration: const InputDecoration(
                      labelText: 'ملاحظة (اختياري)',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ],
              ),
              actions: <Widget>[
                TextButton(
                  onPressed: () => Navigator.of(ctx).pop(false),
                  child: const Text('إلغاء'),
                ),
                FilledButton(
                  onPressed: () {
                    if (nameCtrl.text.trim().isEmpty) {
                      setState(() => error = 'اسم المستخدم مطلوب.');
                      return;
                    }
                    Navigator.of(ctx).pop(true);
                  },
                  child: const Text('حفظ'),
                ),
              ],
            );
          },
        );
      },
    );

    if (saved != true) return;
    if (user == null) {
      await repo.addUser(nameCtrl.text, note: noteCtrl.text.trim());
    } else {
      await repo.updateUser(
        user.id,
        name: nameCtrl.text,
        note: noteCtrl.text.trim(),
      );
    }
  }
}
