import 'package:flutter/material.dart';

import '../core/time_utils.dart';
import '../models/user.dart';
import '../services/app_repository.dart';
import '../services/rotation_service.dart';
import 'app_scope.dart';
import 'day_schedule_screen.dart';
import 'widgets/common.dart';

/// شاشة «ترتيب اليوم»: أي مجموعة على أي جهاز، وترتيب الأشخاص داخلها.
class TodayOrderScreen extends StatefulWidget {
  const TodayOrderScreen({super.key, this.initialDate});

  final DateTime? initialDate;

  @override
  State<TodayOrderScreen> createState() => _TodayOrderScreenState();
}

class _TodayOrderScreenState extends State<TodayOrderScreen> {
  late DateTime _date = widget.initialDate ?? DateTime.now();

  @override
  Widget build(BuildContext context) {
    final AppRepository repo = AppScope.of(context);
    final int dayIndex = repo.dayIndexFor(_date);
    final int cycle = repo.cycleNumberFor(_date);
    final List<DayAssignment> assignments = repo.assignmentsFor(_date);

    return Scaffold(
      appBar: const GrootAppBar(title: 'ترتيب اليوم'),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 24),
        children: <Widget>[
          SectionCard(
            title: 'اليوم',
            icon: Icons.calendar_month_outlined,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  TimeUtils.formatDateArabic(_date),
                  style: const TextStyle(
                      fontSize: 19, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 6),
                Text(
                  'رقم اليوم منذ بداية الدورة: ${dayIndex + 1}   •   '
                  'دورة اليوم: $cycle من ${repo.activeDevices.length}',
                  style: const TextStyle(fontSize: 15.5),
                ),
                const SizedBox(height: 10),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => setState(() =>
                            _date = _date.subtract(const Duration(days: 1))),
                        icon: const Icon(Icons.chevron_right),
                        label: const Text('السابق'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => setState(() => _date = DateTime.now()),
                        icon: const Icon(Icons.today),
                        label: const Text('اليوم'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => setState(
                            () => _date = _date.add(const Duration(days: 1))),
                        icon: const Icon(Icons.chevron_left),
                        label: const Text('التالي'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          if (assignments.isEmpty)
            const EmptyHint(
              message: 'لا توجد أجهزة نشطة.\nأضف أجهزة من شاشة الأجهزة.',
              icon: Icons.smartphone_outlined,
            ),
          for (final DayAssignment a in assignments)
            SectionCard(
              title: a.device.name,
              icon: Icons.smartphone,
              trailing: Chip(
                label: Text(a.groupLabel, style: const TextStyle(fontSize: 14)),
              ),
              child: a.orderedUsers.isEmpty
                  ? const Text(
                      'لا يوجد مستخدمون في هذه المجموعة.',
                      style: TextStyle(fontSize: 15),
                    )
                  : Column(
                      children: <Widget>[
                        for (int i = 0; i < a.orderedUsers.length; i++)
                          _OrderRow(
                            index: i + 1,
                            user: a.orderedUsers[i],
                          ),
                      ],
                    ),
            ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
            child: FilledButton.icon(
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (BuildContext _) => DayScheduleScreen(date: _date),
                  ),
                );
              },
              icon: const Icon(Icons.view_timeline_outlined),
              label: const Text('عرض جدول هذا اليوم بالتفصيل'),
            ),
          ),
        ],
      ),
    );
  }
}

class _OrderRow extends StatelessWidget {
  const _OrderRow({required this.index, required this.user});

  final int index;
  final User user;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: <Widget>[
          CircleAvatar(
            radius: 16,
            child: Text('$index', style: const TextStyle(fontSize: 15)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              user.name,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }
}
