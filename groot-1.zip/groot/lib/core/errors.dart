/// خطأ تحقق من صحة البيانات قبل الحساب، برسائل عربية جاهزة للعرض.
class ScheduleValidationException implements Exception {
  ScheduleValidationException(this.errors);

  final List<String> errors;

  String get message => errors.join('\n');

  @override
  String toString() => 'ScheduleValidationException: $message';
}
