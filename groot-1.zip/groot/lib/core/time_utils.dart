/// أدوات التعامل مع الوقت.
///
/// القاعدة الذهبية في هذا المشروع: كل الحسابات الداخلية تتم بالدقائق
/// كأعداد صحيحة (int) منذ بداية اليوم الأول للجدول.
///
/// 00:00 = 0 , 01:00 = 60 , 13:00 = 780 , 24:00 = 1440
/// وعند عبور منتصف الليل: 05:00 بعد 13:00 تمثل 1740.
///
/// لا يوجد أي استخدام لـ double أو DateTime داخل الحسابات نفسها،
/// والتحويل إلى نص أو تاريخ يتم فقط عند العرض.
class TimeUtils {
  const TimeUtils._();

  static const int minutesPerHour = 60;
  static const int minutesPerDay = 1440;

  /// تحويل ساعة ودقيقة إلى دقائق منذ بداية اليوم.
  static int hmToMinutes(int hour, int minute) =>
      hour * minutesPerHour + minute;

  /// تحليل نص بصيغة HH:mm إلى دقائق منذ بداية اليوم.
  /// يعيد null إذا كان النص غير صالح.
  static int? tryParseHm(String raw) {
    final String text = raw.trim();
    if (text.isEmpty) return null;
    final List<String> parts = text.split(':');
    if (parts.length != 2) return null;
    final int? h = int.tryParse(parts[0].trim());
    final int? m = int.tryParse(parts[1].trim());
    if (h == null || m == null) return null;
    if (h < 0 || h > 24) return null;
    if (m < 0 || m > 59) return null;
    if (h == 24 && m != 0) return null;
    return hmToMinutes(h, m) % minutesPerDay;
  }

  /// رقم اليوم النسبي لدقيقة مطلقة (0 = اليوم الأول، 1 = اليوم التالي...).
  static int dayIndexOf(int absoluteMinutes) {
    return (absoluteMinutes / minutesPerDay).floor();
  }

  /// دقيقة اليوم (0..1439) لأي دقيقة مطلقة.
  static int minuteOfDay(int absoluteMinutes) {
    final int v = absoluteMinutes % minutesPerDay;
    return v < 0 ? v + minutesPerDay : v;
  }

  /// تنسيق دقيقة مطلقة إلى HH:mm.
  static String formatHm(int absoluteMinutes) {
    final int v = minuteOfDay(absoluteMinutes);
    final String h = (v ~/ minutesPerHour).toString().padLeft(2, '0');
    final String m = (v % minutesPerHour).toString().padLeft(2, '0');
    return '$h:$m';
  }

  /// تنسيق دقيقة مطلقة مع الإشارة إلى اليوم التالي إن لزم.
  static String formatHmWithDay(int absoluteMinutes) {
    final int day = dayIndexOf(absoluteMinutes);
    final String base = formatHm(absoluteMinutes);
    if (day <= 0) return base;
    if (day == 1) return '$base (اليوم التالي)';
    return '$base (بعد $day أيام)';
  }

  /// تنسيق مدة بالدقائق إلى نص عربي مختصر.
  static String formatDuration(int minutes) {
    if (minutes <= 0) return '0 د';
    final int h = minutes ~/ minutesPerHour;
    final int m = minutes % minutesPerHour;
    if (h == 0) return '$m د';
    if (m == 0) return '$h س';
    return '$h س $m د';
  }

  /// إزاحة دقيقة من دقائق اليوم إلى الخط الزمني المطلق للجدول.
  ///
  /// الجدول يبدأ عند [windowStart] (دقيقة مطلقة)، وأي وقت ساعة يقع قبله
  /// يعتبر في اليوم التالي. مثال: بداية 13:00 وحدث عند 02:00 → 1560.
  static int liftIntoWindow(int minuteOfDayValue, int windowStart) {
    int v = minuteOfDay(minuteOfDayValue);
    final int startDay = dayIndexOf(windowStart);
    v += startDay * minutesPerDay;
    while (v < windowStart) {
      v += minutesPerDay;
    }
    return v;
  }

  /// طول الفترة بين وقت بداية ووقت نهاية معطيين بدقائق اليوم،
  /// مع دعم عبور منتصف الليل. النتيجة دائمًا بين 1 و1440.
  static int periodLength(int startMinuteOfDay, int endMinuteOfDay) {
    final int s = minuteOfDay(startMinuteOfDay);
    final int e = minuteOfDay(endMinuteOfDay);
    final int diff = e - s;
    return diff > 0 ? diff : diff + minutesPerDay;
  }

  /// هل الفترة تعبر منتصف الليل؟
  static bool crossesMidnight(int startMinuteOfDay, int endMinuteOfDay) {
    return minuteOfDay(endMinuteOfDay) <= minuteOfDay(startMinuteOfDay);
  }

  /// مفتاح تاريخ بصيغة yyyy-MM-dd بدون أي اعتماد على حزم خارجية.
  static String dateKey(DateTime date) {
    final String y = date.year.toString().padLeft(4, '0');
    final String m = date.month.toString().padLeft(2, '0');
    final String d = date.day.toString().padLeft(2, '0');
    return '$y-$m-$d';
  }

  /// تحويل مفتاح تاريخ إلى DateTime (منتصف الليل محليًا).
  static DateTime? parseDateKey(String key) {
    final List<String> parts = key.split('-');
    if (parts.length != 3) return null;
    final int? y = int.tryParse(parts[0]);
    final int? m = int.tryParse(parts[1]);
    final int? d = int.tryParse(parts[2]);
    if (y == null || m == null || d == null) return null;
    return DateTime(y, m, d);
  }

  /// عدد الأيام الكاملة بين تاريخين (بدون تأثير التوقيت الصيفي).
  static int daysBetween(DateTime from, DateTime to) {
    final DateTime a = DateTime(from.year, from.month, from.day);
    final DateTime b = DateTime(to.year, to.month, to.day);
    return (b.difference(a).inHours / 24).round();
  }

  static const List<String> arabicWeekdays = <String>[
    'الإثنين',
    'الثلاثاء',
    'الأربعاء',
    'الخميس',
    'الجمعة',
    'السبت',
    'الأحد',
  ];

  static const List<String> arabicMonths = <String>[
    'يناير',
    'فبراير',
    'مارس',
    'أبريل',
    'مايو',
    'يونيو',
    'يوليو',
    'أغسطس',
    'سبتمبر',
    'أكتوبر',
    'نوفمبر',
    'ديسمبر',
  ];

  /// تنسيق تاريخ بالعربية: "الإثنين 21 سبتمبر 2026".
  static String formatDateArabic(DateTime date) {
    final String wd = arabicWeekdays[(date.weekday - 1) % 7];
    final String mo = arabicMonths[(date.month - 1) % 12];
    return '$wd ${date.day} $mo ${date.year}';
  }

  /// توزيع عدد صحيح على [count] حصص بالتساوي مع توزيع الباقي
  /// توزيعًا حتميًا. لا تُفقد دقيقة ولا تُخلق دقيقة من العدم:
  /// مجموع النتيجة يساوي [total] دائمًا.
  static List<int> splitEvenly(int total, int count, {bool extraToFirst = true}) {
    if (count <= 0) return <int>[];
    if (total < 0) total = 0;
    final int base = total ~/ count;
    final int remainder = total % count;
    final List<int> result = List<int>.filled(count, base);
    for (int i = 0; i < remainder; i++) {
      final int index = extraToFirst ? i : count - 1 - i;
      result[index] = result[index] + 1;
    }
    return result;
  }
}
