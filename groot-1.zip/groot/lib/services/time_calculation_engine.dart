import '../core/errors.dart';
import '../core/time_utils.dart';
import '../models/break_event.dart';
import '../models/calc_rules.dart';
import '../models/downtime_event.dart';
import '../models/schedule_entry.dart';
import '../models/schedule_report.dart';
import '../models/time_period.dart';
import '../models/user.dart';

/// مُدخل الحساب لجهاز واحد في يوم واحد.
class ScheduleInput {
  const ScheduleInput({
    required this.period,
    required this.users,
    this.breaks = const <BreakEvent>[],
    this.downtimes = const <DowntimeEvent>[],
    this.rules = const CalcRules(),
    this.deviceId,
    this.deviceName,
    this.groupId,
    this.groupName,
    this.dateKey,
  });

  final TimePeriod period;

  /// المستخدمون بترتيب أدوارهم في هذا اليوم (بعد التدوير).
  final List<User> users;

  final List<BreakEvent> breaks;
  final List<DowntimeEvent> downtimes;
  final CalcRules rules;

  final String? deviceId;
  final String? deviceName;
  final String? groupId;
  final String? groupName;
  final String? dateKey;
}

/// مقطع داخلي غير تشغيلي على الخط الزمني (توقف أو عطل) بالدقائق المطلقة.
class _Part {
  _Part({
    required this.start,
    required this.end,
    required this.type,
    required this.label,
    required this.sourceId,
  });

  int start;
  final int end;
  final SegmentType type;
  final String label;
  final String sourceId;

  int get duration => end - start;
}

/// محرك حساب الوقت.
///
/// مستقل تمامًا عن الواجهة، وبلا أي استيراد من flutter، ولذلك يمكن
/// اختباره بالكامل باختبارات وحدة.
///
/// القواعد المطبقة (كلها من المواصفة، ولا قاعدة مخترعة):
///
/// 1. كل الحسابات بالدقائق الصحيحة على خط زمني مطلق يبدأ من وقت البداية،
///    ويدعم عبور منتصف الليل (البند 21).
/// 2. التوقفات (صلاة/راحة) ليست وقت تشغيل، ولا تُخصم من حصة المستخدم،
///    لكنها تزحزح كل ما بعدها (البند 11 و12).
/// 3. إذا انتهت حصة مستخدم عند لحظة بداية توقف، فالتوقف يقع قبل بدء
///    المستخدم التالي ولا يُنسب لأحد (البند 13).
/// 4. العطل وقت ضائع: ينقص الوقت المتاح، ويُعاد توزيع المتبقي وفق
///    سياسة الأعطال، ولا يمدّد نهاية الجدول (البند 14 و15).
/// 5. التعارضات تُحلّ حتميًا: التوقفات المتداخلة تُقصّ، والعطل المتداخل
///    مع توقف يُقصّ لأن الوقت غير تشغيلي أصلًا، فلا تُخصم دقيقة مرتين
///    (البند 17).
class TimeCalculationEngine {
  const TimeCalculationEngine._();

  /// تحقق من صحة المدخلات. قائمة فارغة تعني أن البيانات سليمة.
  static List<String> validate(ScheduleInput input) {
    final List<String> errors = <String>[];

    if (input.users.isEmpty) {
      errors.add('لا يوجد مستخدمون في هذه المجموعة، لا يمكن حساب الجدول.');
    }
    for (final User u in input.users) {
      if (u.name.trim().isEmpty) {
        errors.add('يوجد مستخدم بدون اسم. أدخل اسمًا لكل مستخدم.');
        break;
      }
    }

    final int start = TimeUtils.minuteOfDay(input.period.startMinuteOfDay);
    final int end = TimeUtils.minuteOfDay(input.period.endMinuteOfDay);
    if (start == end) {
      errors.add('وقت البداية ووقت النهاية متطابقان. حدّد فترة تشغيل صحيحة.');
    }

    final int periodMinutes = input.period.lengthMinutes;
    if (input.users.isNotEmpty && periodMinutes < input.users.length) {
      errors.add(
        'الفترة $periodMinutes دقيقة لا تكفي لعدد المستخدمين '
        '(${input.users.length}). قلّل عدد المستخدمين أو وسّع الفترة.',
      );
    }

    for (final BreakEvent b in input.breaks) {
      if (!b.enabled) continue;
      if (b.name.trim().isEmpty) {
        errors.add('يوجد توقف بدون اسم.');
      }
      if (b.durationMinutes <= 0) {
        errors.add('مدة التوقف «${b.name}» يجب أن تكون أكبر من صفر.');
      }
      if (b.durationMinutes >= TimeUtils.minutesPerDay) {
        errors.add('مدة التوقف «${b.name}» غير منطقية (يوم كامل أو أكثر).');
      }
    }

    for (final DowntimeEvent d in input.downtimes) {
      final String label = (d.description == null || d.description!.trim().isEmpty)
          ? 'عطل ${d.startLabel}'
          : d.description!.trim();
      if (d.durationMinutes <= 0) {
        errors.add('مدة العطل «$label» يجب أن تكون أكبر من صفر.');
      }
      if (d.durationMinutes >= TimeUtils.minutesPerDay) {
        errors.add('مدة العطل «$label» غير منطقية (يوم كامل أو أكثر).');
      }
    }

    return errors;
  }

  /// حساب جدول يوم واحد لجهاز واحد.
  ///
  /// يرمي [ScheduleValidationException] إذا كانت المدخلات غير صالحة.
  /// الحساب حتمي بالكامل: نفس المدخلات تعطي نفس النتيجة دائمًا.
  static ScheduleReport compute(ScheduleInput input) {
    final List<String> errors = validate(input);
    if (errors.isNotEmpty) {
      throw ScheduleValidationException(errors);
    }

    final List<String> warnings = <String>[];
    final TimePeriod period = input.period;
    final int scheduleStart = period.absoluteStart;
    final int periodMinutes = period.lengthMinutes;
    final int nominalEnd = scheduleStart + periodMinutes;
    final List<User> users = input.users;
    final int n = users.length;
    final CalcRules rules = input.rules;

    // (1) بناء مقاطع التوقفات، مقصوصة فيما بينها حتى لا تتداخل.
    final List<_Part> breakParts =
        _buildBreakParts(input, scheduleStart, nominalEnd, warnings);

    // (2) بناء مقاطع الأعطال، ثم طرح التوقفات منها:
    //     الوقت داخل التوقف غير تشغيلي أصلًا، فلا يُخصم مرتين.
    final List<_Part> downtimeParts =
        _buildDowntimeParts(input, scheduleStart, nominalEnd, breakParts, warnings);

    final List<_Part> parts = <_Part>[...breakParts, ...downtimeParts]
      ..sort((_Part a, _Part b) => a.start.compareTo(b.start));

    // (3) تحديد إجمالي وقت التشغيل المخطط ثم الحصص.
    int plannedOperating = periodMinutes;
    if (rules.breakPolicy == BreakPolicy.deductFromShares) {
      int inside = 0;
      for (final _Part p in parts) {
        final int s = p.start < scheduleStart ? scheduleStart : p.start;
        final int e = p.end > nominalEnd ? nominalEnd : p.end;
        if (e > s) inside += e - s;
      }
      plannedOperating = periodMinutes - inside;
      if (plannedOperating < n) {
        throw ScheduleValidationException(<String>[
          'بعد خصم التوقفات ($inside دقيقة) لم يتبقَّ وقت تشغيل كافٍ '
              'لعدد المستخدمين ($n).',
        ]);
      }
    }

    final List<int> shares = TimeUtils.splitEvenly(
      plannedOperating,
      n,
      extraToFirst: rules.extraToFirst,
    );

    // (4) المحاكاة الزمنية.
    final List<int> required = List<int>.from(shares);
    final List<int> done = List<int>.filled(n, 0);
    final List<int> lostShare = List<int>.filled(n, 0);
    final List<int> prayerPer = List<int>.filled(n, 0);
    final List<int> restPer = List<int>.filled(n, 0);
    final List<int> downPer = List<int>.filled(n, 0);
    final List<int> turnStart = List<int>.filled(n, -1);
    final List<int> turnEnd = List<int>.filled(n, -1);
    final List<List<TimelineSegment>> perUser =
        List<List<TimelineSegment>>.generate(n, (int _) => <TimelineSegment>[]);
    final List<TimelineSegment> timeline = <TimelineSegment>[];

    int unallocated = 0;
    int cursor = scheduleStart;
    int i = 0;
    int pi = 0;
    int guard = 0;

    while (i < n) {
      guard++;
      if (guard > 200000) {
        warnings.add('تم إيقاف الحساب لتفادي حلقة غير منتهية. راجع الأحداث المدخلة.');
        break;
      }

      while (pi < parts.length && parts[pi].end <= cursor) {
        pi++;
      }

      final int need = required[i] - done[i];
      if (need <= 0) {
        if (turnStart[i] < 0) turnStart[i] = cursor;
        turnEnd[i] = cursor;
        i++;
        continue;
      }

      final _Part? p = pi < parts.length ? parts[pi] : null;

      if (p == null || p.start >= cursor + need) {
        // المستخدم يكمل حصته بلا مقاطعة.
        final TimelineSegment seg = TimelineSegment(
          startMinute: cursor,
          endMinute: cursor + need,
          type: SegmentType.operating,
          label: 'تشغيل',
          userId: users[i].id,
          userName: users[i].name,
        );
        timeline.add(seg);
        perUser[i].add(seg);
        if (turnStart[i] < 0) turnStart[i] = cursor;
        done[i] += need;
        cursor += need;
        turnEnd[i] = cursor;
        i++;
      } else if (p.start > cursor) {
        // تشغيل حتى بداية المقطع.
        final TimelineSegment seg = TimelineSegment(
          startMinute: cursor,
          endMinute: p.start,
          type: SegmentType.operating,
          label: 'تشغيل',
          userId: users[i].id,
          userName: users[i].name,
        );
        timeline.add(seg);
        perUser[i].add(seg);
        if (turnStart[i] < 0) turnStart[i] = cursor;
        done[i] += p.start - cursor;
        cursor = p.start;
      } else {
        // المؤشر داخل المقطع (أو عند بدايته تمامًا).
        final int segStart = cursor;
        final int segEnd = p.end;
        final bool started = done[i] > 0;

        final TimelineSegment seg = TimelineSegment(
          startMinute: segStart,
          endMinute: segEnd,
          type: p.type,
          label: p.label,
          userId: started ? users[i].id : null,
          userName: started ? users[i].name : null,
          sourceId: p.sourceId,
          betweenTurns: !started,
        );
        timeline.add(seg);
        if (started) {
          perUser[i].add(seg);
          switch (p.type) {
            case SegmentType.prayer:
              prayerPer[i] += seg.durationMinutes;
              break;
            case SegmentType.rest:
              restPer[i] += seg.durationMinutes;
              break;
            case SegmentType.downtime:
              downPer[i] += seg.durationMinutes;
              break;
            case SegmentType.operating:
              break;
          }
        }

        if (p.type == SegmentType.downtime) {
          unallocated += _applyDowntime(
            lost: seg.durationMinutes,
            currentIndex: i,
            userCount: n,
            policy: rules.downtimePolicy,
            required: required,
            done: done,
            lostShare: lostShare,
            extraToFirst: rules.extraToFirst,
          );
        }

        cursor = segEnd;
        pi++;
      }
    }

    final int scheduleEnd = cursor;

    // أحداث لم يصلها الجدول.
    for (int k = pi; k < parts.length; k++) {
      if (parts[k].start >= scheduleEnd) {
        warnings.add(
          '«${parts[k].label}» عند ${TimeUtils.formatHm(parts[k].start)} '
          'يقع بعد نهاية الجدول وتم تجاهله.',
        );
      }
    }

    if (unallocated > 0) {
      warnings.add(
        'تعذّر خصم $unallocated دقيقة من دقائق الأعطال لعدم وجود وقت تشغيل '
        'متبقٍ لخصمها منه.',
      );
    }

    // (5) تجميع النتائج.
    int totalPrayer = 0;
    int totalRest = 0;
    int totalDowntime = 0;
    for (final TimelineSegment s in timeline) {
      switch (s.type) {
        case SegmentType.prayer:
          totalPrayer += s.durationMinutes;
          break;
        case SegmentType.rest:
          totalRest += s.durationMinutes;
          break;
        case SegmentType.downtime:
          totalDowntime += s.durationMinutes;
          break;
        case SegmentType.operating:
          break;
      }
    }

    int totalOperating = 0;
    int totalDeducted = 0;
    final List<ScheduleEntry> entries = <ScheduleEntry>[];
    for (int k = 0; k < n; k++) {
      totalOperating += done[k];
      totalDeducted += lostShare[k];
      final int ts = turnStart[k] < 0 ? scheduleEnd : turnStart[k];
      final int te = turnEnd[k] < 0 ? ts : turnEnd[k];
      entries.add(
        ScheduleEntry(
          userId: users[k].id,
          userName: users[k].name,
          orderInGroup: k + 1,
          plannedShareMinutes: shares[k],
          operatingMinutes: done[k],
          pauseMinutes: prayerPer[k] + restPer[k],
          prayerMinutes: prayerPer[k],
          restMinutes: restPer[k],
          downtimeMinutes: downPer[k],
          lostShareMinutes: lostShare[k],
          turnStartMinute: ts,
          turnEndMinute: te,
          segments: perUser[k],
          deviceId: input.deviceId,
          deviceName: input.deviceName,
          groupId: input.groupId,
          groupName: input.groupName,
        ),
      );
    }

    final ScheduleSummary summary = ScheduleSummary(
      periodMinutes: periodMinutes,
      spanMinutes: scheduleEnd - scheduleStart,
      plannedOperatingMinutes: plannedOperating,
      operatingMinutes: totalOperating,
      prayerMinutes: totalPrayer,
      restMinutes: totalRest,
      downtimeMinutes: totalDowntime,
      deductedLostMinutes: totalDeducted,
      unallocatedLostMinutes: unallocated,
      userCount: n,
      deviceCount: 1,
      groupCount: 1,
    );

    return ScheduleReport(
      entries: entries,
      timeline: timeline,
      summary: summary,
      scheduleStartMinute: scheduleStart,
      scheduleEndMinute: scheduleEnd,
      nominalStartMinute: scheduleStart,
      nominalEndMinute: nominalEnd,
      warnings: warnings,
      deviceId: input.deviceId,
      deviceName: input.deviceName,
      groupId: input.groupId,
      groupName: input.groupName,
      dateKey: input.dateKey,
    );
  }

  // ---------------------------------------------------------------------
  // بناء المقاطع غير التشغيلية
  // ---------------------------------------------------------------------

  static List<_Part> _buildBreakParts(
    ScheduleInput input,
    int scheduleStart,
    int nominalEnd,
    List<String> warnings,
  ) {
    final List<_Part> raw = <_Part>[];
    for (final BreakEvent b in input.breaks) {
      if (!b.enabled) continue;
      if (b.durationMinutes <= 0) continue;
      final int start = TimeUtils.liftIntoWindow(b.startMinuteOfDay, scheduleStart);
      if (start >= nominalEnd) {
        warnings.add(
          '«${b.name}» عند ${b.startLabel} خارج فترة التشغيل وتم تجاهله.',
        );
        continue;
      }
      raw.add(
        _Part(
          start: start,
          end: start + b.durationMinutes,
          type: b.isPrayer ? SegmentType.prayer : SegmentType.rest,
          label: b.name,
          sourceId: b.id,
        ),
      );
    }

    raw.sort((_Part a, _Part b) => a.start != b.start
        ? a.start.compareTo(b.start)
        : a.end.compareTo(b.end));

    final List<_Part> result = <_Part>[];
    int prevEnd = -1;
    for (final _Part p in raw) {
      if (p.start < prevEnd) {
        warnings.add(
          '«${p.label}» يتداخل مع توقف سابق؛ تم قصّه ليبدأ عند '
          '${TimeUtils.formatHm(prevEnd)} حتى لا تُحسب الدقائق مرتين.',
        );
        p.start = prevEnd;
      }
      if (p.start >= p.end) {
        warnings.add('«${p.label}» مبتلَع بالكامل داخل توقف آخر وتم تجاهله.');
        continue;
      }
      result.add(p);
      prevEnd = p.end;
    }
    return result;
  }

  static List<_Part> _buildDowntimeParts(
    ScheduleInput input,
    int scheduleStart,
    int nominalEnd,
    List<_Part> breakParts,
    List<String> warnings,
  ) {
    final List<_Part> raw = <_Part>[];
    for (final DowntimeEvent d in input.downtimes) {
      if (d.durationMinutes <= 0) continue;
      if (input.deviceId != null &&
          d.deviceId != null &&
          d.deviceId != input.deviceId) {
        continue;
      }
      final String label = (d.description == null || d.description!.trim().isEmpty)
          ? 'عطل'
          : d.description!.trim();
      final int start = TimeUtils.liftIntoWindow(d.startMinuteOfDay, scheduleStart);
      if (start >= nominalEnd) {
        warnings.add(
          '«$label» عند ${d.startLabel} خارج فترة التشغيل وتم تجاهله.',
        );
        continue;
      }
      raw.add(
        _Part(
          start: start,
          end: start + d.durationMinutes,
          type: SegmentType.downtime,
          label: label,
          sourceId: d.id,
        ),
      );
    }

    raw.sort((_Part a, _Part b) => a.start != b.start
        ? a.start.compareTo(b.start)
        : a.end.compareTo(b.end));

    // قصّ الأعطال المتداخلة فيما بينها.
    final List<_Part> merged = <_Part>[];
    int prevEnd = -1;
    for (final _Part p in raw) {
      if (p.start < prevEnd) {
        warnings.add(
          '«${p.label}» يتداخل مع عطل سابق؛ تم قصّه ليبدأ عند '
          '${TimeUtils.formatHm(prevEnd)} حتى لا تُخصم الدقائق مرتين.',
        );
        p.start = prevEnd;
      }
      if (p.start >= p.end) {
        warnings.add('«${p.label}» مبتلَع بالكامل داخل عطل آخر وتم تجاهله.');
        continue;
      }
      merged.add(p);
      prevEnd = p.end;
    }

    // طرح التوقفات من الأعطال: الوقت داخل التوقف غير تشغيلي أصلًا.
    final List<_Part> result = <_Part>[];
    for (final _Part d in merged) {
      int remainingStart = d.start;
      int produced = 0;
      for (final _Part b in breakParts) {
        if (b.end <= remainingStart) continue;
        if (b.start >= d.end) break;
        if (b.start > remainingStart) {
          result.add(
            _Part(
              start: remainingStart,
              end: b.start,
              type: SegmentType.downtime,
              label: d.label,
              sourceId: d.sourceId,
            ),
          );
          produced += b.start - remainingStart;
        }
        if (b.end > remainingStart) remainingStart = b.end;
        if (remainingStart >= d.end) break;
      }
      if (remainingStart < d.end) {
        result.add(
          _Part(
            start: remainingStart,
            end: d.end,
            type: SegmentType.downtime,
            label: d.label,
            sourceId: d.sourceId,
          ),
        );
        produced += d.end - remainingStart;
      }
      if (produced < d.duration) {
        final int overlap = d.duration - produced;
        if (produced == 0) {
          warnings.add(
            '«${d.label}» وقع بالكامل داخل توقف؛ لم يُخصم من وقت التشغيل '
            'لأن الوقت كان متوقفًا أصلًا.',
          );
        } else {
          warnings.add(
            '«${d.label}» يتداخل مع توقف بمقدار $overlap دقيقة؛ لم تُخصم '
            'هذه الدقائق مرتين.',
          );
        }
      }
    }

    result.sort((_Part a, _Part b) => a.start.compareTo(b.start));
    return result;
  }

  // ---------------------------------------------------------------------
  // إعادة توزيع الوقت بعد العطل
  // ---------------------------------------------------------------------

  /// يخصم [lost] دقيقة من الحصص وفق السياسة المختارة.
  /// يعيد عدد الدقائق التي تعذّر خصمها (0 في الحالة الطبيعية).
  static int _applyDowntime({
    required int lost,
    required int currentIndex,
    required int userCount,
    required DowntimePolicy policy,
    required List<int> required,
    required List<int> done,
    required List<int> lostShare,
    required bool extraToFirst,
  }) {
    List<int> active = <int>[];
    switch (policy) {
      case DowntimePolicy.shared:
        for (int j = currentIndex; j < userCount; j++) {
          active.add(j);
        }
        break;
      case DowntimePolicy.currentUserAbsorbs:
        active.add(currentIndex);
        break;
      case DowntimePolicy.futureUsersOnly:
        for (int j = currentIndex + 1; j < userCount; j++) {
          active.add(j);
        }
        if (active.isEmpty) active.add(currentIndex);
        break;
    }

    int remaining = lost;
    int guard = 0;
    while (remaining > 0 && active.isNotEmpty) {
      guard++;
      if (guard > 10000) break;
      final List<int> wants =
          TimeUtils.splitEvenly(remaining, active.length, extraToFirst: extraToFirst);
      final List<int> next = <int>[];
      int assigned = 0;
      for (int k = 0; k < active.length; k++) {
        final int j = active[k];
        final int capacity = required[j] - done[j];
        if (capacity <= 0) continue;
        final int take = wants[k] < capacity ? wants[k] : capacity;
        if (take > 0) {
          required[j] -= take;
          lostShare[j] += take;
          assigned += take;
        }
        if (capacity - take > 0) next.add(j);
      }
      remaining -= assigned;
      if (assigned == 0) break;
      active = next;
    }
    return remaining;
  }
}
