import '../core/time_utils.dart';
import '../models/device.dart';
import '../models/group.dart';
import '../models/user.dart';

/// نتيجة توزيع يوم واحد: جهاز ← مجموعة ← مستخدمون مرتبون.
class DayAssignment {
  const DayAssignment({
    required this.device,
    required this.deviceIndex,
    required this.group,
    required this.groupIndex,
    required this.orderedUsers,
  });

  final Device device;
  final int deviceIndex;
  final Group? group;
  final int groupIndex;

  /// المستخدمون بالترتيب النهائي لهذا اليوم (بعد التدوير العكسي).
  final List<User> orderedUsers;

  String get groupLabel => group?.name ?? 'بدون مجموعة';
}

/// خدمة التدوير — حتمية بالكامل.
///
/// (أ) تدوير المجموعات بين الأجهزة:
///     الجهاز رقم j في اليوم رقم d يأخذ المجموعة رقم ((j - d) mod عدد الأجهزة).
///     اليوم 1: جهاز1←مجموعة1، جهاز2←مجموعة2، جهاز3←مجموعة3
///     اليوم 2: جهاز1←مجموعة3، جهاز2←مجموعة1، جهاز3←مجموعة2
///     اليوم 3: جهاز1←مجموعة2، جهاز2←مجموعة3، جهاز3←مجموعة1
///     اليوم 4: يعود إلى نمط اليوم 1.
///     يعمل مع أي عدد من الأجهزة.
///
/// (ب) تدوير الأشخاص داخل المجموعة — تدوير عكسي: آخر عنصر يصبح الأول.
///     الدورة 1: A B C D
///     الدورة 2: D A B C
///     الدورة 3: C D A B
///     الدورة 4: B C D A
///     الدورة 5: A B C D
///
/// التدويران مستقلان تمامًا: الأول دورته بعدد الأجهزة، والثاني بحجم المجموعة.
class RotationService {
  const RotationService._();

  /// باقي قسمة موجب دائمًا.
  static int mod(int value, int modulus) {
    if (modulus <= 0) return 0;
    final int r = value % modulus;
    return r < 0 ? r + modulus : r;
  }

  /// رقم اليوم النسبي بالنسبة لتاريخ بداية الدورة.
  static int dayIndex(DateTime date, DateTime anchorDate) {
    return TimeUtils.daysBetween(anchorDate, date);
  }

  /// رقم دورة اليوم لعرضه في الواجهة (1 = بداية النمط).
  static int cycleNumber(int dayIndexValue, int deviceCount) {
    if (deviceCount <= 0) return 1;
    return mod(dayIndexValue, deviceCount) + 1;
  }

  /// فهرس المجموعة التي تعمل على الجهاز رقم [deviceIndex] في اليوم المحدد.
  static int groupIndexForDevice({
    required int deviceIndex,
    required int dayIndexValue,
    required int deviceCount,
  }) {
    if (deviceCount <= 0) return 0;
    return mod(deviceIndex - dayIndexValue, deviceCount);
  }

  /// تدوير عكسي لقائمة: آخر [steps] عناصر تنتقل إلى المقدمة.
  static List<T> rotateBackward<T>(List<T> items, int steps) {
    if (items.length <= 1) return List<T>.from(items);
    final int n = items.length;
    final int r = mod(steps, n);
    if (r == 0) return List<T>.from(items);
    return <T>[...items.sublist(n - r), ...items.sublist(0, n - r)];
  }

  /// ترتيب أعضاء المجموعة في اليوم المحدد.
  static List<String> orderedMemberIds(Group group, int dayIndexValue) {
    return rotateBackward<String>(group.memberIds, dayIndexValue);
  }

  /// توزيع يوم كامل: كل جهاز نشط مع مجموعته ومستخدميها مرتبين.
  static List<DayAssignment> assignmentsForDay({
    required List<Device> devices,
    required List<Group> groups,
    required List<User> users,
    required int dayIndexValue,
  }) {
    final List<Device> activeDevices =
        devices.where((Device d) => d.active).toList();
    final int deviceCount = activeDevices.length;
    final Map<String, User> byId = <String, User>{
      for (final User u in users) u.id: u,
    };

    final List<DayAssignment> result = <DayAssignment>[];
    for (int j = 0; j < deviceCount; j++) {
      final int gi = groupIndexForDevice(
        deviceIndex: j,
        dayIndexValue: dayIndexValue,
        deviceCount: deviceCount,
      );
      Group? group;
      for (final Group g in groups) {
        if (g.index == gi) {
          group = g;
          break;
        }
      }
      final List<User> ordered = <User>[];
      if (group != null) {
        for (final String id in orderedMemberIds(group, dayIndexValue)) {
          final User? u = byId[id];
          if (u != null) ordered.add(u);
        }
      }
      result.add(
        DayAssignment(
          device: activeDevices[j],
          deviceIndex: j,
          group: group,
          groupIndex: gi,
          orderedUsers: ordered,
        ),
      );
    }
    return result;
  }
}
