import 'package:flutter/foundation.dart';

import '../core/errors.dart';
import '../core/time_utils.dart';
import '../models/app_settings.dart';
import '../models/break_event.dart';
import '../models/device.dart';
import '../models/downtime_event.dart';
import '../models/group.dart';
import '../models/prayer_settings.dart';
import '../models/schedule_report.dart';
import '../models/user.dart';
import 'grouping_service.dart';
import 'rotation_service.dart';
import 'prayer_times_service.dart';
import 'storage_service.dart';
import 'time_calculation_engine.dart';

/// حالة التطبيق ومصدر الحقيقة الوحيد للبيانات.
///
/// لا يوجد أي منطق حساب هنا: الحساب كله داخل [TimeCalculationEngine].
class AppRepository extends ChangeNotifier {
  AppRepository(this._storage) {
    _load();
  }

  final StorageService _storage;

  List<User> users = <User>[];
  List<Device> devices = <Device>[];
  List<Group> groups = <Group>[];
  List<DowntimeEvent> downtimes = <DowntimeEvent>[];
  AppSettings settings = AppSettings();

  bool ready = false;

  int _idCounter = 0;

  String newId(String prefix) {
    _idCounter++;
    return '${prefix}_${DateTime.now().millisecondsSinceEpoch}_$_idCounter';
  }

  void _load() {
    users = _storage.loadUsers();
    devices = _storage.loadDevices();
    groups = _storage.loadGroups();
    downtimes = _storage.loadDowntimes();
    settings = _storage.loadSettings();
    if (settings.anchorDateKey.isEmpty) {
      settings.anchorDateKey = TimeUtils.dateKey(DateTime.now());
      _storage.saveSettings(settings);
    }
    ready = true;
    notifyListeners();
  }

  // ------------------------------------------------------------------
  // المستخدمون
  // ------------------------------------------------------------------

  Future<void> addUser(String name, {String? note}) async {
    users.add(User(id: newId('user'), name: name.trim(), note: note));
    await _storage.saveUsers(users);
    notifyListeners();
  }

  Future<void> updateUser(String id, {String? name, String? note}) async {
    for (final User u in users) {
      if (u.id == id) {
        if (name != null) u.name = name.trim();
        if (note != null) u.note = note;
      }
    }
    await _storage.saveUsers(users);
    notifyListeners();
  }

  Future<void> deleteUser(String id) async {
    users.removeWhere((User u) => u.id == id);
    GroupingService.pruneDeletedUsers(groups, users);
    await _storage.saveUsers(users);
    await _storage.saveGroups(groups);
    notifyListeners();
  }

  Future<void> reorderUsers(int oldIndex, int newIndex) async {
    if (newIndex > oldIndex) newIndex -= 1;
    final User u = users.removeAt(oldIndex);
    users.insert(newIndex, u);
    await _storage.saveUsers(users);
    notifyListeners();
  }

  // ------------------------------------------------------------------
  // الأجهزة
  // ------------------------------------------------------------------

  Future<void> addDevice(String name) async {
    devices.add(Device(id: newId('dev'), name: name.trim()));
    await _storage.saveDevices(devices);
    notifyListeners();
  }

  Future<void> updateDevice(String id, {String? name, bool? active}) async {
    for (final Device d in devices) {
      if (d.id == id) {
        if (name != null) d.name = name.trim();
        if (active != null) d.active = active;
      }
    }
    await _storage.saveDevices(devices);
    notifyListeners();
  }

  Future<void> deleteDevice(String id) async {
    devices.removeWhere((Device d) => d.id == id);
    await _storage.saveDevices(devices);
    notifyListeners();
  }

  Future<void> reorderDevices(int oldIndex, int newIndex) async {
    if (newIndex > oldIndex) newIndex -= 1;
    final Device d = devices.removeAt(oldIndex);
    devices.insert(newIndex, d);
    await _storage.saveDevices(devices);
    notifyListeners();
  }

  /// ضبط عدد الأجهزة بسرعة من شاشة الأجهزة أو الإعدادات.
  Future<void> setDeviceCount(int count) async {
    if (count < 0) return;
    while (devices.length < count) {
      devices.add(Device(id: newId('dev'), name: 'جهاز ${devices.length + 1}'));
    }
    while (devices.length > count) {
      devices.removeLast();
    }
    await _storage.saveDevices(devices);
    notifyListeners();
  }

  List<Device> get activeDevices =>
      devices.where((Device d) => d.active).toList();

  // ------------------------------------------------------------------
  // المجموعات
  // ------------------------------------------------------------------

  /// إعادة توزيع المستخدمين على المجموعات — لا تحدث إلا بطلب صريح.
  Future<void> rebuildGroups() async {
    final int count = activeDevices.length;
    groups = GroupingService.buildGroups(
      users: users,
      groupCount: count,
      extraToFirst: settings.rules.extraToFirst,
      previous: groups,
    );
    GroupingService.applyGroupIds(users, groups);
    await _storage.saveGroups(groups);
    await _storage.saveUsers(users);
    notifyListeners();
  }

  Future<void> renameGroup(String id, String name) async {
    for (final Group g in groups) {
      if (g.id == id) g.name = name.trim();
    }
    await _storage.saveGroups(groups);
    notifyListeners();
  }

  /// نقل مستخدم من مجموعة إلى أخرى يدويًا.
  Future<void> moveUserToGroup(String userId, String groupId) async {
    for (final Group g in groups) {
      g.memberIds.remove(userId);
      if (g.id == groupId) g.memberIds.add(userId);
    }
    GroupingService.applyGroupIds(users, groups);
    await _storage.saveGroups(groups);
    await _storage.saveUsers(users);
    notifyListeners();
  }

  /// تغيير ترتيب عضو داخل مجموعته (يؤثر على التدوير العكسي).
  Future<void> reorderGroupMember(String groupId, int oldIndex, int newIndex) async {
    for (final Group g in groups) {
      if (g.id != groupId) continue;
      if (newIndex > oldIndex) newIndex -= 1;
      final String id = g.memberIds.removeAt(oldIndex);
      g.memberIds.insert(newIndex, id);
    }
    await _storage.saveGroups(groups);
    notifyListeners();
  }

  List<User> get unassignedUsers =>
      GroupingService.unassignedUsers(users, groups);

  User? userById(String id) {
    for (final User u in users) {
      if (u.id == id) return u;
    }
    return null;
  }

  Group? groupOfUser(String userId) {
    for (final Group g in groups) {
      if (g.memberIds.contains(userId)) return g;
    }
    return null;
  }

  /// ترتيب المستخدم داخل مجموعته في اليوم المحدد (1 = الأول)، أو 0 إن لم يوجد.
  int orderOfUserInGroup(String userId, DateTime date) {
    final Group? g = groupOfUser(userId);
    if (g == null) return 0;
    final List<String> ordered =
        RotationService.orderedMemberIds(g, dayIndexFor(date));
    final int idx = ordered.indexOf(userId);
    return idx < 0 ? 0 : idx + 1;
  }

  // ------------------------------------------------------------------
  // الإعدادات والتوقفات
  // ------------------------------------------------------------------

  Future<void> saveSettings() async {
    await _storage.saveSettings(settings);
    notifyListeners();
  }

  Future<void> addBreak(BreakEvent b) async {
    settings.breaks.add(b);
    await saveSettings();
  }

  Future<void> updateBreak(BreakEvent updated) async {
    for (int i = 0; i < settings.breaks.length; i++) {
      if (settings.breaks[i].id == updated.id) settings.breaks[i] = updated;
    }
    await saveSettings();
  }

  Future<void> deleteBreak(String id) async {
    settings.breaks.removeWhere((BreakEvent b) => b.id == id);
    await saveSettings();
  }

  // ------------------------------------------------------------------
  // مواقيت الصلاة
  // ------------------------------------------------------------------

  /// مواقيت الصلاة المحسوبة لهذا اليوم وهذا الموقع.
  PrayerTimesResult prayerTimesFor(DateTime date) =>
      settings.prayer.timesFor(date);

  /// كل توقفات اليوم: الصلوات المحسوبة تلقائيًا + التوقفات اليدوية.
  ///
  /// المواقيت تتغيّر يوميًا بنفسها لأنها تُحسب من تاريخ اليوم وإحداثيات
  /// المدينة، ولا تحتاج إنترنت.
  List<BreakEvent> breaksForDate(DateTime date) {
    final List<BreakEvent> result = <BreakEvent>[];
    final PrayerSettings ps = settings.prayer;
    if (ps.autoEnabled) {
      final PrayerTimesResult t = ps.timesFor(date);
      for (final PrayerSlot slot in ps.slots) {
        if (!slot.enabled || slot.durationMinutes <= 0) continue;
        result.add(
          BreakEvent.prayer(
            id: 'auto_${slot.key}',
            name: slot.name,
            startMinuteOfDay: ps.resolvedMinute(slot, t),
            durationMinutes: slot.durationMinutes,
          ),
        );
      }
    }
    for (final BreakEvent b in settings.breaks) {
      if (b.enabled) result.add(b);
    }
    return result;
  }

  // ------------------------------------------------------------------
  // الأعطال
  // ------------------------------------------------------------------

  List<DowntimeEvent> downtimesForDate(DateTime date) {
    final String key = TimeUtils.dateKey(date);
    final List<DowntimeEvent> list =
        downtimes.where((DowntimeEvent d) => d.dateKey == key).toList();
    list.sort((DowntimeEvent a, DowntimeEvent b) =>
        a.startMinuteOfDay.compareTo(b.startMinuteOfDay));
    return list;
  }

  Future<void> addDowntime(DowntimeEvent event) async {
    downtimes.add(event);
    await _storage.saveDowntimes(downtimes);
    notifyListeners();
  }

  Future<void> updateDowntime(DowntimeEvent updated) async {
    for (int i = 0; i < downtimes.length; i++) {
      if (downtimes[i].id == updated.id) downtimes[i] = updated;
    }
    await _storage.saveDowntimes(downtimes);
    notifyListeners();
  }

  Future<void> deleteDowntime(String id) async {
    downtimes.removeWhere((DowntimeEvent d) => d.id == id);
    await _storage.saveDowntimes(downtimes);
    notifyListeners();
  }

  // ------------------------------------------------------------------
  // التدوير والحساب
  // ------------------------------------------------------------------

  int dayIndexFor(DateTime date) =>
      RotationService.dayIndex(date, settings.anchorDate);

  int cycleNumberFor(DateTime date) => RotationService.cycleNumber(
        dayIndexFor(date),
        activeDevices.length,
      );

  List<DayAssignment> assignmentsFor(DateTime date) =>
      RotationService.assignmentsForDay(
        devices: devices,
        groups: groups,
        users: users,
        dayIndexValue: dayIndexFor(date),
      );

  /// حساب تقارير اليوم لكل جهاز نشط.
  ///
  /// يعيد قائمة تقارير، وقائمة أخطاء عربية لكل جهاز تعذّر حسابه.
  ScheduleComputation computeDay(DateTime date) {
    final List<ScheduleReport> reports = <ScheduleReport>[];
    final List<String> errors = <String>[];
    final List<DayAssignment> assignments = assignmentsFor(date);
    final List<DowntimeEvent> dayDowntimes = downtimesForDate(date);
    final List<BreakEvent> dayBreaks = breaksForDate(date);

    if (assignments.isEmpty) {
      errors.add('لا توجد أجهزة نشطة. أضف جهازًا واحدًا على الأقل.');
    }

    for (final DayAssignment a in assignments) {
      if (a.orderedUsers.isEmpty) {
        errors.add(
          '${a.device.name}: لا يوجد مستخدمون في ${a.groupLabel}. '
          'أنشئ المجموعات من شاشة المجموعات.',
        );
        continue;
      }
      try {
        final ScheduleReport report = TimeCalculationEngine.compute(
          ScheduleInput(
            period: settings.period,
            users: a.orderedUsers,
            breaks: dayBreaks,
            downtimes: dayDowntimes,
            rules: settings.rules,
            deviceId: a.device.id,
            deviceName: a.device.name,
            groupId: a.group?.id,
            groupName: a.groupLabel,
            dateKey: TimeUtils.dateKey(date),
          ),
        );
        reports.add(report);
      } on ScheduleValidationException catch (e) {
        errors.add('${a.device.name}: ${e.message}');
      }
    }

    return ScheduleComputation(reports: reports, errors: errors);
  }

  Future<void> resetAll() async {
    await _storage.clearAll();
    users = <User>[];
    devices = <Device>[];
    groups = <Group>[];
    downtimes = <DowntimeEvent>[];
    settings = AppSettings()
      ..anchorDateKey = TimeUtils.dateKey(DateTime.now());
    await _storage.saveSettings(settings);
    notifyListeners();
  }
}

/// نتيجة حساب يوم كامل لكل الأجهزة.
class ScheduleComputation {
  const ScheduleComputation({required this.reports, required this.errors});

  final List<ScheduleReport> reports;
  final List<String> errors;

  bool get hasReports => reports.isNotEmpty;
}
