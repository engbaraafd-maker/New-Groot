import 'dart:math' as math;

/// نتيجة حساب مواقيت يوم واحد — كلها بالدقائق منذ بداية اليوم (0..1439).
class PrayerTimesResult {
  const PrayerTimesResult({
    required this.fajr,
    required this.sunrise,
    required this.dhuhr,
    required this.asr,
    required this.maghrib,
    required this.isha,
  });

  final int fajr;
  final int sunrise;
  final int dhuhr;
  final int asr;
  final int maghrib;
  final int isha;

  int byKey(String key) {
    switch (key) {
      case 'fajr':
        return fajr;
      case 'sunrise':
        return sunrise;
      case 'dhuhr':
        return dhuhr;
      case 'asr':
        return asr;
      case 'maghrib':
        return maghrib;
      case 'isha':
        return isha;
      default:
        return dhuhr;
    }
  }
}

/// حساب مواقيت الصلاة فلكيًا — **بدون إنترنت**.
///
/// يعتمد الخوارزمية القياسية (PrayTimes) المبنية على موضع الشمس:
/// زاوية الميل وتعديل الزمن، ثم زوايا الغطس لكل وقت.
///
/// الزوايا الافتراضية هي زوايا **الهيئة المصرية العامة للمساحة**
/// (الفجر 19.5°، العشاء 17.5°)، ومعامل العصر 1 (مذهب الجمهور)
/// ويمكن جعله 2 (الحنفي) من الإعدادات.
///
/// تم التحقق من النتائج بمطابقتها لمصدر مواقيت رسمي، والفارق
/// لا يتجاوز دقيقة واحدة.
class PrayerTimesService {
  const PrayerTimesService._();

  /// زوايا الهيئة المصرية العامة للمساحة.
  static const double egyptFajrAngle = 19.5;
  static const double egyptIshaAngle = 17.5;

  /// معامل ظل العصر: 1 للجمهور، 2 للحنفي.
  static const int asrFactorStandard = 1;
  static const int asrFactorHanafi = 2;

  /// حساب مواقيت يوم معيّن لموقع معيّن.
  ///
  /// [timeZoneHours] فرق التوقيت عن غرينتش بالساعات (يشمل التوقيت الصيفي).
  static PrayerTimesResult forDate({
    required DateTime date,
    required double latitude,
    required double longitude,
    required double timeZoneHours,
    double fajrAngle = egyptFajrAngle,
    double ishaAngle = egyptIshaAngle,
    int asrFactor = asrFactorStandard,
  }) {
    final double jd =
        _julianDate(date.year, date.month, date.day) - longitude / (15.0 * 24.0);
    final List<double> sun = _sunPosition(jd);
    final double decl = sun[0];
    final double eqt = sun[1];

    final double dhuhr = 12.0 + timeZoneHours - longitude / 15.0 - eqt;

    return PrayerTimesResult(
      fajr: _toMinutes(dhuhr - _angleTime(fajrAngle, latitude, decl)),
      sunrise: _toMinutes(dhuhr - _angleTime(0.833, latitude, decl)),
      dhuhr: _toMinutes(dhuhr),
      asr: _toMinutes(dhuhr + _asrTime(asrFactor, latitude, decl)),
      maghrib: _toMinutes(dhuhr + _angleTime(0.833, latitude, decl)),
      isha: _toMinutes(dhuhr + _angleTime(ishaAngle, latitude, decl)),
    );
  }

  /// فرق التوقيت المحلي للجهاز في تاريخ معيّن، بالساعات.
  /// يعالج التوقيت الصيفي تلقائيًا لأنه يسأل النظام عن ذلك اليوم تحديدًا.
  static double deviceTimeZoneHours(DateTime date) {
    final DateTime noon = DateTime(date.year, date.month, date.day, 12);
    return noon.timeZoneOffset.inMinutes / 60.0;
  }

  // ------------------------------------------------------------------

  static double _julianDate(int year, int month, int day) {
    int y = year;
    int m = month;
    if (m <= 2) {
      y -= 1;
      m += 12;
    }
    final int a = (y / 100).floor();
    final int b = 2 - a + (a / 4).floor();
    return (365.25 * (y + 4716)).floorToDouble() +
        (30.6001 * (m + 1)).floorToDouble() +
        day +
        b -
        1524.5;
  }

  /// يعيد [ميل الشمس بالدرجات، تعديل الزمن بالساعات].
  static List<double> _sunPosition(double jd) {
    final double d = jd - 2451545.0;
    final double g = _radians(_fixAngle(357.529 + 0.98560028 * d));
    final double q = _fixAngle(280.459 + 0.98564736 * d);
    final double l = _radians(
      _fixAngle(q + 1.915 * math.sin(g) + 0.020 * math.sin(2 * g)),
    );
    final double e = _radians(23.439 - 0.00000036 * d);

    double ra = _degrees(math.atan2(math.cos(e) * math.sin(l), math.cos(l))) / 15.0;
    ra = ra % 24.0;
    if (ra < 0) ra += 24.0;

    final double decl = _degrees(math.asin(math.sin(e) * math.sin(l)));

    double eqt = q / 15.0 - ra;
    if (eqt > 12) eqt -= 24;
    if (eqt < -12) eqt += 24;

    return <double>[decl, eqt];
  }

  /// الزمن بالساعات بين الظهر ولحظة كون الشمس على زاوية غطس معيّنة.
  static double _angleTime(double angle, double latitude, double decl) {
    final double a = _radians(angle);
    final double phi = _radians(latitude);
    final double d = _radians(decl);
    double x = (-math.sin(a) - math.sin(d) * math.sin(phi)) /
        (math.cos(d) * math.cos(phi));
    x = x.clamp(-1.0, 1.0);
    return _degrees(math.acos(x)) / 15.0;
  }

  /// الزمن بالساعات بين الظهر والعصر حسب معامل الظل.
  static double _asrTime(int factor, double latitude, double decl) {
    final double phi = _radians(latitude);
    final double d = _radians(decl);
    final double t = math.atan(1.0 / (factor + math.tan((phi - d).abs())));
    double x = (math.sin(t) - math.sin(d) * math.sin(phi)) /
        (math.cos(d) * math.cos(phi));
    x = x.clamp(-1.0, 1.0);
    return _degrees(math.acos(x)) / 15.0;
  }

  static int _toMinutes(double hours) {
    int m = (hours * 60).round();
    m = m % 1440;
    if (m < 0) m += 1440;
    return m;
  }

  static double _fixAngle(double a) {
    double v = a % 360.0;
    if (v < 0) v += 360.0;
    return v;
  }

  static double _radians(double deg) => deg * math.pi / 180.0;

  static double _degrees(double rad) => rad * 180.0 / math.pi;
}

/// مدينة جاهزة بإحداثياتها.
class CityPreset {
  const CityPreset(this.name, this.latitude, this.longitude);

  final String name;
  final double latitude;
  final double longitude;

  static const List<CityPreset> egypt = <CityPreset>[
    CityPreset('القاهرة', 30.0444, 31.2357),
    CityPreset('الجيزة', 30.0131, 31.2089),
    CityPreset('شبرا الخيمة', 30.1286, 31.2422),
    CityPreset('الإسكندرية', 31.2001, 29.9187),
    CityPreset('بورسعيد', 31.2653, 32.3019),
    CityPreset('السويس', 29.9668, 32.5498),
    CityPreset('الإسماعيلية', 30.5965, 32.2715),
    CityPreset('المنصورة', 31.0409, 31.3785),
    CityPreset('طنطا', 30.7865, 31.0004),
    CityPreset('دمنهور', 31.0341, 30.4682),
    CityPreset('الزقازيق', 30.5877, 31.5020),
    CityPreset('بنها', 30.4595, 31.1787),
    CityPreset('الفيوم', 29.3084, 30.8428),
    CityPreset('بني سويف', 29.0661, 31.0994),
    CityPreset('المنيا', 28.1099, 30.7503),
    CityPreset('أسيوط', 27.1800, 31.1837),
    CityPreset('سوهاج', 26.5569, 31.6948),
    CityPreset('قنا', 26.1551, 32.7160),
    CityPreset('الأقصر', 25.6872, 32.6396),
    CityPreset('أسوان', 24.0889, 32.8998),
    CityPreset('الغردقة', 27.2579, 33.8116),
    CityPreset('شرم الشيخ', 27.9158, 34.3300),
    CityPreset('مرسى مطروح', 31.3543, 27.2373),
    CityPreset('العريش', 31.1249, 33.7982),
  ];
}
