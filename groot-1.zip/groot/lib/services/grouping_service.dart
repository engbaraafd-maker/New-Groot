import '../core/time_utils.dart';
import '../models/group.dart';
import '../models/user.dart';

/// خدمة إنشاء المجموعات.
///
/// عدد المجموعات = عدد الأجهزة النشطة، والتوزيع بالتساوي قدر الإمكان.
/// إذا كان العدد لا يقبل القسمة بالتساوي تُوزَّع الزيادة وفق سياسة
/// الدقائق/الأشخاص الزائدين (الأوائل أو الأواخر) ولا يُفقد أي مستخدم.
///
/// المجموعات لا تتغير تلقائيًا بعد إنشائها؛ لا يعاد التوزيع إلا بطلب صريح.
class GroupingService {
  const GroupingService._();

  /// إنشاء مجموعات جديدة من قائمة المستخدمين بترتيبهم الحالي.
  static List<Group> buildGroups({
    required List<User> users,
    required int groupCount,
    bool extraToFirst = true,
    List<Group> previous = const <Group>[],
  }) {
    if (groupCount <= 0) return <Group>[];
    final List<int> sizes = TimeUtils.splitEvenly(
      users.length,
      groupCount,
      extraToFirst: extraToFirst,
    );

    final List<Group> groups = <Group>[];
    int cursor = 0;
    for (int i = 0; i < groupCount; i++) {
      final int size = sizes[i];
      final List<String> members = <String>[];
      for (int k = 0; k < size && cursor < users.length; k++) {
        members.add(users[cursor].id);
        cursor++;
      }
      String? keptName;
      for (final Group g in previous) {
        if (g.index == i) {
          keptName = g.name;
          break;
        }
      }
      groups.add(
        Group(
          id: 'group_$i',
          index: i,
          name: keptName,
          memberIds: members,
        ),
      );
    }
    return groups;
  }

  /// كتابة معرّف المجموعة داخل كل مستخدم.
  static void applyGroupIds(List<User> users, List<Group> groups) {
    final Map<String, String> map = <String, String>{};
    for (final Group g in groups) {
      for (final String id in g.memberIds) {
        map[id] = g.id;
      }
    }
    for (final User u in users) {
      u.groupId = map[u.id];
    }
  }

  /// المستخدمون الذين لا ينتمون لأي مجموعة (مثلًا أُضيفوا بعد آخر توزيع).
  static List<User> unassignedUsers(List<User> users, List<Group> groups) {
    final Set<String> assigned = <String>{};
    for (final Group g in groups) {
      assigned.addAll(g.memberIds);
    }
    return users.where((User u) => !assigned.contains(u.id)).toList();
  }

  /// تنظيف المجموعات من معرّفات مستخدمين محذوفين.
  static void pruneDeletedUsers(List<Group> groups, List<User> users) {
    final Set<String> alive = users.map((User u) => u.id).toSet();
    for (final Group g in groups) {
      g.memberIds = g.memberIds.where(alive.contains).toList();
    }
  }
}
