import '../services/prayer_times_service.dart';

/// إعداد صلاة واحدة: هل تُحتسب كتوقف، وكم مدتها، وكيف يُحدَّد وقتها.
///
/// الوقت الافتراضي محسوب فلكيًا، ويمكن تعديله بطريقتين:
/// - [offsetMinutes]: إزاحة ثابتة بالدقائق (± ) تبقى تتبع الشمس يوميًا.
/// - [manualMinuteOfDay]: وقت ثابت يدوي يلغي الحساب تمامًا لهذه الصلاة.
class PrayerSlot {
  PrayerSlot({
    required this.key,
    required this.name,
    required this.enabled,
    required this.durationMinutes,
    this.offsetMinutes = 0,
    this.manualMinuteOfDay,
  });

  /// fajr / dhuhr / asr / maghrib / isha
  final String key;
  final String name;
  bool enabled;
  int durationMinutes;

  /// تعديل بالدقائق على الوقت المحسوب (موجب أو سالب).
  int offsetMinutes;

  /// وقت ثابت يدوي بالدقائق منذ بداية اليوم. null = اعتمد الحساب التلقائي.
  int? manualMinuteOfDay;

  bool get isManual => manualMinuteOfDay != null;

  bool get isAdjusted => manualMinuteOfDay != null || offsetMinutes != 0;

  String get modeLabel {
    if (manualMinuteOfDay != null) return 'يدوي';
    if (offsetMinutes > 0) return 'تلقائي +$offsetMinutes';
    if (offsetMinutes < 0) return 'تلقائي $offsetMinutes';
    return 'تلقائي';
  }

  /// الوقت النهائي المعتمد بعد التعديل اليدوي إن وُجد.
  int resolve(int computedMinuteOfDay) {
    final int base = manualMinuteOfDay ?? (computedMinuteOfDay + offsetMinutes);
    final int v = base % 1440;
    return v < 0 ? v + 1440 : v;
  }

  PrayerSlot copy() => PrayerSlot(
        key: key,
        name: name,
        enabled: enabled,
        durationMinutes: durationMinutes,
        offsetMinutes: offsetMinutes,
        manualMinuteOfDay: manualMinuteOfDay,
      );

  Map<String, dynamic> toJson() => <String, dynamic>{
        'key': key,
        'name': name,
        'enabled': enabled,
        'duration': durationMinutes,
        'offset': offsetMinutes,
        'manual': manualMinuteOfDay,
      };

  static PrayerSlot fromJson(Map<String, dynamic> json) => PrayerSlot(
        key: (json['key'] as String?) ?? 'asr',
        name: (json['name'] as String?) ?? '',
        enabled: (json['enabled'] as bool?) ?? true,
        durationMinutes: (json['duration'] as num?)?.toInt() ?? 0,
        offsetMinutes: (json['offset'] as num?)?.toInt() ?? 0,
        manualMinuteOfDay: (json['manual'] as num?)?.toInt(),
      );
}

/// إعدادات مواقيت الصلاة التلقائية.
///
/// المواقيت تُحسب داخل التطبيق فلكيًا من إحداثيات المدينة وتاريخ اليوم،
/// فتتغيّر يوميًا بنفسها ولا تحتاج إنترنت ولا إدخالًا يدويًا.
class PrayerSettings {
  PrayerSettings({
    this.autoEnabled = true,
    this.cityName = 'القاهرة',
    this.latitude = 30.0444,
    this.longitude = 31.2357,
    this.fajrAngle = PrayerTimesService.egyptFajrAngle,
    this.ishaAngle = PrayerTimesService.egyptIshaAngle,
    this.asrFactor = PrayerTimesService.asrFactorStandard,
    List<PrayerSlot>? slots,
  }) : slots = slots ?? defaultSlots();

  /// تشغيل المواقيت التلقائية. عند إيقافها تُستخدم التوقفات اليدوية فقط.
  bool autoEnabled;

  String cityName;
  double latitude;
  double longitude;

  double fajrAngle;
  double ishaAngle;

  /// 1 = الجمهور، 2 = الحنفي.
  int asrFactor;

  List<PrayerSlot> slots;

  static List<PrayerSlot> defaultSlots() => <PrayerSlot>[
        PrayerSlot(key: 'fajr', name: 'صلاة الفجر', enabled: false, durationMinutes: 20),
        PrayerSlot(key: 'dhuhr', name: 'صلاة الظهر', enabled: false, durationMinutes: 20),
        PrayerSlot(key: 'asr', name: 'صلاة العصر', enabled: true, durationMinutes: 25),
        PrayerSlot(key: 'maghrib', name: 'صلاة المغرب', enabled: true, durationMinutes: 45),
        PrayerSlot(key: 'isha', name: 'صلاة العشاء', enabled: true, durationMinutes: 30),
      ];

  /// الوقت النهائي لصلاة معيّنة في يوم معيّن، بعد أي تعديل يدوي.
  int resolvedMinute(PrayerSlot slot, PrayerTimesResult times) =>
      slot.resolve(times.byKey(slot.key));

  /// حساب مواقيت اليوم المحدد لهذا الموقع.
  PrayerTimesResult timesFor(DateTime date) {
    return PrayerTimesService.forDate(
      date: date,
      latitude: latitude,
      longitude: longitude,
      timeZoneHours: PrayerTimesService.deviceTimeZoneHours(date),
      fajrAngle: fajrAngle,
      ishaAngle: ishaAngle,
      asrFactor: asrFactor,
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'autoEnabled': autoEnabled,
        'cityName': cityName,
        'latitude': latitude,
        'longitude': longitude,
        'fajrAngle': fajrAngle,
        'ishaAngle': ishaAngle,
        'asrFactor': asrFactor,
        'slots': slots.map((PrayerSlot s) => s.toJson()).toList(),
      };

  static PrayerSettings fromJson(Map<String, dynamic> json) {
    final List<dynamic> raw = (json['slots'] as List<dynamic>?) ?? <dynamic>[];
    final List<PrayerSlot> slots = raw
        .map((dynamic e) =>
            PrayerSlot.fromJson(Map<String, dynamic>.from(e as Map<dynamic, dynamic>)))
        .toList();
    return PrayerSettings(
      autoEnabled: (json['autoEnabled'] as bool?) ?? true,
      cityName: (json['cityName'] as String?) ?? 'القاهرة',
      latitude: (json['latitude'] as num?)?.toDouble() ?? 30.0444,
      longitude: (json['longitude'] as num?)?.toDouble() ?? 31.2357,
      fajrAngle: (json['fajrAngle'] as num?)?.toDouble() ??
          PrayerTimesService.egyptFajrAngle,
      ishaAngle: (json['ishaAngle'] as num?)?.toDouble() ??
          PrayerTimesService.egyptIshaAngle,
      asrFactor: (json['asrFactor'] as num?)?.toInt() ??
          PrayerTimesService.asrFactorStandard,
      slots: slots.isEmpty ? defaultSlots() : slots,
    );
  }
}
