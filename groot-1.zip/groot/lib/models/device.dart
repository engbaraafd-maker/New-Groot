/// جهاز موبايل واحد تعمل عليه مجموعة في يوم معين.
class Device {
  Device({
    required this.id,
    required this.name,
    this.active = true,
  });

  final String id;
  String name;
  bool active;

  Device copyWith({String? name, bool? active}) {
    return Device(
      id: id,
      name: name ?? this.name,
      active: active ?? this.active,
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'name': name,
        'active': active,
      };

  static Device fromJson(Map<String, dynamic> json) {
    return Device(
      id: json['id'] as String,
      name: (json['name'] as String?) ?? '',
      active: (json['active'] as bool?) ?? true,
    );
  }

  @override
  String toString() => 'Device($id, $name)';
}
