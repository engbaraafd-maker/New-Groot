import '../core/time_utils.dart';
import 'schedule_entry.dart';

/// الملخص العام للجدول. كل الأرقام بالدقائق ومتوافقة رياضيًا:
///
///   spanMinutes = operatingMinutes + prayerMinutes + restMinutes + downtimeMinutes
///   operatingMinutes = plannedOperatingMinutes - deductedLostMinutes
class ScheduleSummary {
  const ScheduleSummary({
    required this.periodMinutes,
    required this.spanMinutes,
    required this.plannedOperatingMinutes,
    required this.operatingMinutes,
    required this.prayerMinutes,
    required this.restMinutes,
    required this.downtimeMinutes,
    required this.deductedLostMinutes,
    required this.unallocatedLostMinutes,
    required this.userCount,
    required this.deviceCount,
    required this.groupCount,
  });

  /// الفترة الاسمية (من وقت البداية إلى وقت النهاية).
  final int periodMinutes;

  /// الامتداد الفعلي للجدول من أول لحظة إلى آخر لحظة.
  final int spanMinutes;

  /// إجمالي وقت التشغيل المخطط قبل الأعطال.
  final int plannedOperatingMinutes;

  /// إجمالي وقت التشغيل الفعلي.
  final int operatingMinutes;

  final int prayerMinutes;
  final int restMinutes;
  final int downtimeMinutes;

  /// إجمالي الدقائق التي خُصمت فعليًا من حصص المستخدمين بسبب الأعطال.
  final int deductedLostMinutes;

  /// دقائق عطل لم يكن لها ما يُخصم منه (تُعرض حتى تبقى الأرقام متوافقة).
  final int unallocatedLostMinutes;

  final int userCount;
  final int deviceCount;
  final int groupCount;

  int get pauseMinutes => prayerMinutes + restMinutes;

  /// إجمالي الوقت الضائع = الأعطال.
  int get lostMinutes => downtimeMinutes;

  /// فحص التوافق الرياضي للأرقام.
  bool get isConsistent =>
      spanMinutes == operatingMinutes + prayerMinutes + restMinutes + downtimeMinutes &&
      operatingMinutes == plannedOperatingMinutes - deductedLostMinutes;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'periodMinutes': periodMinutes,
        'spanMinutes': spanMinutes,
        'plannedOperatingMinutes': plannedOperatingMinutes,
        'operatingMinutes': operatingMinutes,
        'prayerMinutes': prayerMinutes,
        'restMinutes': restMinutes,
        'downtimeMinutes': downtimeMinutes,
        'deductedLostMinutes': deductedLostMinutes,
        'unallocatedLostMinutes': unallocatedLostMinutes,
        'userCount': userCount,
        'deviceCount': deviceCount,
        'groupCount': groupCount,
      };
}

/// تقرير جدول يوم واحد لجهاز واحد.
class ScheduleReport {
  ScheduleReport({
    required this.entries,
    required this.timeline,
    required this.summary,
    required this.scheduleStartMinute,
    required this.scheduleEndMinute,
    required this.nominalStartMinute,
    required this.nominalEndMinute,
    required this.warnings,
    this.deviceId,
    this.deviceName,
    this.groupId,
    this.groupName,
    this.dateKey,
  });

  final List<ScheduleEntry> entries;

  /// الخط الزمني الكامل بالترتيب، بلا فجوات وبلا تداخل.
  final List<TimelineSegment> timeline;

  final ScheduleSummary summary;

  final int scheduleStartMinute;
  final int scheduleEndMinute;
  final int nominalStartMinute;
  final int nominalEndMinute;

  /// تنبيهات عربية واضحة (تعارض أحداث، حدث خارج الفترة، ...).
  final List<String> warnings;

  String? deviceId;
  String? deviceName;
  String? groupId;
  String? groupName;
  String? dateKey;

  String get startLabel => TimeUtils.formatHm(scheduleStartMinute);
  String get endLabel => TimeUtils.formatHmWithDay(scheduleEndMinute);

  /// هل امتد الجدول بعد وقت النهاية الاسمي بسبب التوقفات؟
  int get overtimeMinutes => scheduleEndMinute - nominalEndMinute;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'deviceId': deviceId,
        'deviceName': deviceName,
        'groupId': groupId,
        'groupName': groupName,
        'dateKey': dateKey,
        'scheduleStart': scheduleStartMinute,
        'scheduleEnd': scheduleEndMinute,
        'nominalStart': nominalStartMinute,
        'nominalEnd': nominalEndMinute,
        'summary': summary.toJson(),
        'entries': entries.map((ScheduleEntry e) => e.toJson()).toList(),
        'timeline': timeline.map((TimelineSegment s) => s.toJson()).toList(),
        'warnings': warnings,
      };
}
