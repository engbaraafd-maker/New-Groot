import '../core/time_utils.dart';

/// نوع التوقف التعويضي.
enum BreakKind {
  /// صلاة.
  prayer,

  /// راحة.
  rest,
}

/// توقف تعويضي (صلاة أو راحة).
///
/// القاعدة: التوقف ليس وقت تشغيل، ولا يُخصم من حصة المستخدم،
/// لكنه يزحزح كل ما بعده على الخط الزمني.
///
/// التوقف مثبّت على ساعة الحائط: صلاة العصر عند 15:00 تحدث عند 15:00
/// مهما تغيّر الجدول.
class BreakEvent {
  BreakEvent({
    required this.id,
    required this.name,
    required this.kind,
    required this.startMinuteOfDay,
    required this.durationMinutes,
    this.enabled = true,
  });

  /// مُنشئ مختصر لتوقف من نوع صلاة.
  factory BreakEvent.prayer({
    required String id,
    required String name,
    required int startMinuteOfDay,
    required int durationMinutes,
    bool enabled = true,
  }) =>
      BreakEvent(
        id: id,
        name: name,
        kind: BreakKind.prayer,
        startMinuteOfDay: startMinuteOfDay,
        durationMinutes: durationMinutes,
        enabled: enabled,
      );

  /// مُنشئ مختصر لتوقف من نوع راحة.
  factory BreakEvent.rest({
    required String id,
    required String name,
    required int startMinuteOfDay,
    required int durationMinutes,
    bool enabled = true,
  }) =>
      BreakEvent(
        id: id,
        name: name,
        kind: BreakKind.rest,
        startMinuteOfDay: startMinuteOfDay,
        durationMinutes: durationMinutes,
        enabled: enabled,
      );

  final String id;
  String name;
  BreakKind kind;
  int startMinuteOfDay;
  int durationMinutes;
  bool enabled;

  bool get isPrayer => kind == BreakKind.prayer;

  String get startLabel => TimeUtils.formatHm(startMinuteOfDay);

  String get kindLabel => isPrayer ? 'صلاة' : 'راحة';

  BreakEvent copyWith({
    String? name,
    BreakKind? kind,
    int? startMinuteOfDay,
    int? durationMinutes,
    bool? enabled,
  }) {
    return BreakEvent(
      id: id,
      name: name ?? this.name,
      kind: kind ?? this.kind,
      startMinuteOfDay: startMinuteOfDay ?? this.startMinuteOfDay,
      durationMinutes: durationMinutes ?? this.durationMinutes,
      enabled: enabled ?? this.enabled,
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'name': name,
        'kind': kind.name,
        'start': startMinuteOfDay,
        'duration': durationMinutes,
        'enabled': enabled,
      };

  static BreakEvent fromJson(Map<String, dynamic> json) {
    final String kindName = (json['kind'] as String?) ?? 'prayer';
    return BreakEvent(
      id: json['id'] as String,
      name: (json['name'] as String?) ?? '',
      kind: kindName == 'rest' ? BreakKind.rest : BreakKind.prayer,
      startMinuteOfDay: (json['start'] as num).toInt(),
      durationMinutes: (json['duration'] as num).toInt(),
      enabled: (json['enabled'] as bool?) ?? true,
    );
  }

  @override
  String toString() => 'BreakEvent($name, $startLabel, $durationMinutes د)';
}

/// اسم مستعار للتوضيح فقط — صلاة.
class PrayerBreak {
  const PrayerBreak._();

  static BreakEvent create({
    required String id,
    required String name,
    required int startMinuteOfDay,
    required int durationMinutes,
  }) =>
      BreakEvent.prayer(
        id: id,
        name: name,
        startMinuteOfDay: startMinuteOfDay,
        durationMinutes: durationMinutes,
      );
}

/// اسم مستعار للتوضيح فقط — راحة.
class RestBreak {
  const RestBreak._();

  static BreakEvent create({
    required String id,
    required String name,
    required int startMinuteOfDay,
    required int durationMinutes,
  }) =>
      BreakEvent.rest(
        id: id,
        name: name,
        startMinuteOfDay: startMinuteOfDay,
        durationMinutes: durationMinutes,
      );
}
