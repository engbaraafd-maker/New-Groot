import '../core/time_utils.dart';
import 'break_event.dart';
import 'calc_rules.dart';
import 'prayer_settings.dart';
import 'time_period.dart';

/// وضع الثيم.
enum AppThemeMode { system, light, dark }

/// إعدادات التطبيق — كل ما يمكن للمستخدم تغييره بدون تعديل الكود.
class AppSettings {
  AppSettings({
    TimePeriod? period,
    this.anchorDateKey = '',
    this.rules = const CalcRules(),
    List<BreakEvent>? breaks,
    PrayerSettings? prayer,
    this.themeMode = AppThemeMode.system,
  })  : period = period ??
            const TimePeriod(
              startMinuteOfDay: 820, // 13:40
              endMinuteOfDay: 295, // 04:55
            ),
        breaks = breaks ?? defaultBreaks(),
        prayer = prayer ?? PrayerSettings();

  TimePeriod period;

  /// تاريخ بداية الدورة (اليوم 1) بصيغة yyyy-MM-dd.
  String anchorDateKey;

  CalcRules rules;

  /// التوقفات اليدوية (الراحة وما شابهها) — أوقاتها ثابتة كل يوم.
  List<BreakEvent> breaks;

  /// مواقيت الصلاة التلقائية المحسوبة فلكيًا لكل يوم.
  PrayerSettings prayer;

  AppThemeMode themeMode;

  DateTime get anchorDate =>
      TimeUtils.parseDateKey(anchorDateKey) ?? DateTime(2026, 1, 1);

  /// افتراضيًا: الراحة فقط. الصلوات تأتي من الحساب التلقائي.
  static List<BreakEvent> defaultBreaks() => <BreakEvent>[
        BreakEvent.rest(
          id: 'brk_rest',
          name: 'الراحة',
          startMinuteOfDay: 23 * 60,
          durationMinutes: 30,
        ),
      ];

  Map<String, dynamic> toJson() => <String, dynamic>{
        'period': period.toJson(),
        'anchorDateKey': anchorDateKey,
        'rules': rules.toJson(),
        'breaks': breaks.map((BreakEvent b) => b.toJson()).toList(),
        'prayer': prayer.toJson(),
        'themeMode': themeMode.name,
      };

  static AppSettings fromJson(Map<String, dynamic> json) {
    final List<dynamic> rawBreaks =
        (json['breaks'] as List<dynamic>?) ?? <dynamic>[];
    AppThemeMode theme = AppThemeMode.system;
    for (final AppThemeMode m in AppThemeMode.values) {
      if (m.name == json['themeMode']) theme = m;
    }
    return AppSettings(
      period: json['period'] == null
          ? null
          : TimePeriod.fromJson(
              Map<String, dynamic>.from(json['period'] as Map<dynamic, dynamic>)),
      anchorDateKey: (json['anchorDateKey'] as String?) ?? '',
      rules: json['rules'] == null
          ? const CalcRules()
          : CalcRules.fromJson(
              Map<String, dynamic>.from(json['rules'] as Map<dynamic, dynamic>)),
      breaks: rawBreaks
          .map((dynamic e) =>
              BreakEvent.fromJson(Map<String, dynamic>.from(e as Map<dynamic, dynamic>)))
          .toList(),
      prayer: json['prayer'] == null
          ? PrayerSettings()
          : PrayerSettings.fromJson(
              Map<String, dynamic>.from(json['prayer'] as Map<dynamic, dynamic>)),
      themeMode: theme,
    );
  }
}
