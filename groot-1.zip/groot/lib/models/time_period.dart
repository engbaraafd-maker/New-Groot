import '../core/time_utils.dart';

/// فترة تشغيل معرفة بوقت بداية ووقت نهاية بدقائق اليوم (0..1439).
///
/// تدعم عبور منتصف الليل: 13:00 → 05:00 تعني 16 ساعة (960 دقيقة).
class TimePeriod {
  const TimePeriod({
    required this.startMinuteOfDay,
    required this.endMinuteOfDay,
  });

  final int startMinuteOfDay;
  final int endMinuteOfDay;

  /// طول الفترة بالدقائق (1..1440).
  int get lengthMinutes =>
      TimeUtils.periodLength(startMinuteOfDay, endMinuteOfDay);

  bool get crossesMidnight =>
      TimeUtils.crossesMidnight(startMinuteOfDay, endMinuteOfDay);

  /// بداية الجدول على الخط الزمني المطلق (اليوم الأول).
  int get absoluteStart => TimeUtils.minuteOfDay(startMinuteOfDay);

  /// نهاية الفترة الاسمية على الخط الزمني المطلق.
  int get absoluteNominalEnd => absoluteStart + lengthMinutes;

  String get startLabel => TimeUtils.formatHm(startMinuteOfDay);
  String get endLabel => TimeUtils.formatHm(endMinuteOfDay);

  Map<String, dynamic> toJson() => <String, dynamic>{
        'start': startMinuteOfDay,
        'end': endMinuteOfDay,
      };

  static TimePeriod fromJson(Map<String, dynamic> json) {
    return TimePeriod(
      startMinuteOfDay: (json['start'] as num).toInt(),
      endMinuteOfDay: (json['end'] as num).toInt(),
    );
  }

  @override
  String toString() => 'TimePeriod($startLabel → $endLabel)';
}
