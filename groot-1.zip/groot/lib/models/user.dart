/// مستخدم واحد في النظام.
///
/// [groupId] يُحفظ صراحةً حتى لا تتغير عضوية المجموعات تلقائيًا؛
/// لا يتغير إلا عند طلب إعادة التوزيع من المستخدم.
class User {
  User({
    required this.id,
    required this.name,
    this.groupId,
    this.note,
  });

  final String id;
  String name;
  String? groupId;
  String? note;

  User copyWith({String? name, String? groupId, bool clearGroup = false, String? note}) {
    return User(
      id: id,
      name: name ?? this.name,
      groupId: clearGroup ? null : (groupId ?? this.groupId),
      note: note ?? this.note,
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'name': name,
        'groupId': groupId,
        'note': note,
      };

  static User fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'] as String,
      name: (json['name'] as String?) ?? '',
      groupId: json['groupId'] as String?,
      note: json['note'] as String?,
    );
  }

  @override
  String toString() => 'User($id, $name)';
}
