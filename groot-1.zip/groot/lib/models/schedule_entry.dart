import '../core/time_utils.dart';

/// نوع المقطع على الخط الزمني.
enum SegmentType {
  /// تشغيل فعلي.
  operating,

  /// توقف صلاة.
  prayer,

  /// توقف راحة.
  rest,

  /// عطل (وقت ضائع).
  downtime,
}

extension SegmentTypeLabel on SegmentType {
  String get label {
    switch (this) {
      case SegmentType.operating:
        return 'تشغيل';
      case SegmentType.prayer:
        return 'صلاة';
      case SegmentType.rest:
        return 'راحة';
      case SegmentType.downtime:
        return 'عطل';
    }
  }

  bool get isBreak => this == SegmentType.prayer || this == SegmentType.rest;
}

/// مقطع واحد على الخط الزمني، بالدقائق المطلقة.
class TimelineSegment {
  const TimelineSegment({
    required this.startMinute,
    required this.endMinute,
    required this.type,
    required this.label,
    this.userId,
    this.userName,
    this.sourceId,
    this.betweenTurns = false,
  });

  final int startMinute;
  final int endMinute;
  final SegmentType type;
  final String label;

  /// المستخدم صاحب المقطع، أو null إذا كان المقطع بين دورين.
  final String? userId;
  final String? userName;

  /// معرّف الحدث الأصلي (توقف أو عطل).
  final String? sourceId;

  /// true إذا وقع التوقف عند لحظة انتقال بين مستخدمين
  /// (البند 13: يُحسب قبل بدء المستخدم التالي، ولا يُنسب لأحد).
  final bool betweenTurns;

  int get durationMinutes => endMinute - startMinute;

  String get startLabel => TimeUtils.formatHm(startMinute);
  String get endLabel => TimeUtils.formatHm(endMinute);
  String get rangeLabel => '$startLabel ← $endLabel';

  Map<String, dynamic> toJson() => <String, dynamic>{
        'start': startMinute,
        'end': endMinute,
        'type': type.name,
        'label': label,
        'userId': userId,
        'userName': userName,
        'sourceId': sourceId,
        'betweenTurns': betweenTurns,
      };

  @override
  String toString() => '$rangeLabel  $label';
}

/// نتيجة الجدولة لمستخدم واحد.
class ScheduleEntry {
  ScheduleEntry({
    required this.userId,
    required this.userName,
    required this.orderInGroup,
    required this.plannedShareMinutes,
    required this.operatingMinutes,
    required this.pauseMinutes,
    required this.prayerMinutes,
    required this.restMinutes,
    required this.downtimeMinutes,
    required this.lostShareMinutes,
    required this.turnStartMinute,
    required this.turnEndMinute,
    required this.segments,
    this.deviceId,
    this.deviceName,
    this.groupId,
    this.groupName,
  });

  final String userId;
  final String userName;

  /// ترتيب المستخدم داخل المجموعة في هذا اليوم (1 = الأول).
  final int orderInGroup;

  /// الحصة المخططة قبل أي أعطال.
  final int plannedShareMinutes;

  /// وقت التشغيل الفعلي.
  final int operatingMinutes;

  /// إجمالي التوقفات التعويضية أثناء دوره (صلاة + راحة).
  final int pauseMinutes;
  final int prayerMinutes;
  final int restMinutes;

  /// دقائق الأعطال التي وقعت أثناء دوره.
  final int downtimeMinutes;

  /// الدقائق التي خسرها من حصته بسبب الأعطال (قد تكون من عطل وقع
  /// أثناء دور غيره إذا كانت السياسة توزيعًا مشتركًا).
  final int lostShareMinutes;

  final int turnStartMinute;
  final int turnEndMinute;

  final List<TimelineSegment> segments;

  String? deviceId;
  String? deviceName;
  String? groupId;
  String? groupName;

  int get turnSpanMinutes => turnEndMinute - turnStartMinute;

  String get turnStartLabel => TimeUtils.formatHm(turnStartMinute);
  String get turnEndLabel => TimeUtils.formatHm(turnEndMinute);

  Map<String, dynamic> toJson() => <String, dynamic>{
        'userId': userId,
        'userName': userName,
        'orderInGroup': orderInGroup,
        'plannedShareMinutes': plannedShareMinutes,
        'operatingMinutes': operatingMinutes,
        'pauseMinutes': pauseMinutes,
        'prayerMinutes': prayerMinutes,
        'restMinutes': restMinutes,
        'downtimeMinutes': downtimeMinutes,
        'lostShareMinutes': lostShareMinutes,
        'turnStart': turnStartMinute,
        'turnEnd': turnEndMinute,
        'deviceId': deviceId,
        'deviceName': deviceName,
        'groupId': groupId,
        'groupName': groupName,
        'segments': segments.map((TimelineSegment s) => s.toJson()).toList(),
      };
}
