import '../core/time_utils.dart';

/// عطل — وقت ضائع تمامًا.
///
/// العطل يختلف جذريًا عن الصلاة والراحة:
/// - لا يُعوَّض.
/// - ينقص الوقت المتاح للتشغيل بمقداره.
/// - يُعاد توزيع المتبقي وفق سياسة الأعطال المختارة في الإعدادات.
/// - لا يمدّد نهاية الجدول.
class DowntimeEvent {
  DowntimeEvent({
    required this.id,
    required this.dateKey,
    required this.startMinuteOfDay,
    required this.durationMinutes,
    this.description,
    this.deviceId,
  });

  final String id;

  /// اليوم الذي حدث فيه العطل بصيغة yyyy-MM-dd.
  String dateKey;

  int startMinuteOfDay;
  int durationMinutes;
  String? description;

  /// الجهاز الذي وقع عليه العطل. null = يطبَّق على كل الأجهزة.
  String? deviceId;

  String get startLabel => TimeUtils.formatHm(startMinuteOfDay);

  DowntimeEvent copyWith({
    String? dateKey,
    int? startMinuteOfDay,
    int? durationMinutes,
    String? description,
    String? deviceId,
    bool clearDevice = false,
  }) {
    return DowntimeEvent(
      id: id,
      dateKey: dateKey ?? this.dateKey,
      startMinuteOfDay: startMinuteOfDay ?? this.startMinuteOfDay,
      durationMinutes: durationMinutes ?? this.durationMinutes,
      description: description ?? this.description,
      deviceId: clearDevice ? null : (deviceId ?? this.deviceId),
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'dateKey': dateKey,
        'start': startMinuteOfDay,
        'duration': durationMinutes,
        'description': description,
        'deviceId': deviceId,
      };

  static DowntimeEvent fromJson(Map<String, dynamic> json) {
    return DowntimeEvent(
      id: json['id'] as String,
      dateKey: (json['dateKey'] as String?) ?? '',
      startMinuteOfDay: (json['start'] as num).toInt(),
      durationMinutes: (json['duration'] as num).toInt(),
      description: json['description'] as String?,
      deviceId: json['deviceId'] as String?,
    );
  }

  @override
  String toString() => 'DowntimeEvent($startLabel, $durationMinutes د)';
}
