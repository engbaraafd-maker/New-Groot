/// مجموعة ثابتة من المستخدمين.
///
/// المجموعة ثابتة الأعضاء: التدوير اليومي يغيّر الجهاز الذي تعمل عليه
/// المجموعة فقط، ولا يغيّر أعضاءها إطلاقًا.
/// [memberIds] مرتبة، وهذا الترتيب هو الأساس للتدوير العكسي داخل المجموعة.
class Group {
  Group({
    required this.id,
    required this.index,
    required this.memberIds,
    String? name,
  }) : name = name ?? 'المجموعة ${index + 1}';

  final String id;

  /// ترتيب المجموعة (0 = المجموعة 1).
  final int index;

  String name;

  /// معرفات الأعضاء بالترتيب الأساسي (الدورة 1).
  List<String> memberIds;

  int get size => memberIds.length;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'index': index,
        'name': name,
        'memberIds': memberIds,
      };

  static Group fromJson(Map<String, dynamic> json) {
    final List<dynamic> raw = (json['memberIds'] as List<dynamic>?) ?? <dynamic>[];
    return Group(
      id: json['id'] as String,
      index: (json['index'] as num).toInt(),
      name: json['name'] as String?,
      memberIds: raw.map((dynamic e) => e as String).toList(),
    );
  }

  @override
  String toString() => 'Group($name, ${memberIds.length} أعضاء)';
}
