/// سياسة توزيع الدقائق المتبقية عند عدم القسمة بالتساوي.
///
/// مثال: 961 دقيقة على 4 مستخدمين = 241 + 240 + 240 + 240.
/// [firstUsers] تعطي الدقيقة الزائدة للأوائل، و[lastUsers] للأواخر.
/// لا تُفقد دقيقة ولا تُخلق دقيقة في الحالتين.
enum RemainderPolicy { firstUsers, lastUsers }

/// سياسة التعامل مع الأعطال (الوقت الضائع).
enum DowntimePolicy {
  /// توزيع مشترك: يتحمّل صاحب الدور (في الجزء المتبقي من حصته)
  /// ومن لم يبدأ دوره الضياعَ بالتساوي. (الافتراضي)
  shared,

  /// صاحب الدور وحده يتحمّل العطل: دوره ينتهي في موعده المخطط
  /// وينقص وقت تشغيله الفعلي بمقدار العطل.
  currentUserAbsorbs,

  /// من لم يبدأ دوره فقط يتحمّلون العطل، وصاحب الدور يكمل حصته كاملة.
  futureUsersOnly,
}

/// سياسة التعامل مع التوقفات التعويضية (الصلاة والراحة).
enum BreakPolicy {
  /// التوقفات تزحزح الخط الزمني: كل مستخدم يأخذ حصة تشغيل فعلية كاملة،
  /// وينتهي الجدول بعد وقت النهاية الاسمي بمقدار إجمالي التوقفات.
  extendSchedule,

  /// الفترة ثابتة: يُخصم إجمالي التوقفات من الفترة أولًا، ثم يُقسَّم صافي
  /// وقت التشغيل على المستخدمين، فينتهي الجدول عند وقت النهاية بالضبط.
  /// (الافتراضي — القاعدة المعتمدة)
  deductFromShares,
}

/// قواعد الحساب — كلها إعدادات صريحة، ولا شيء منها مضمر في الكود.
class CalcRules {
  const CalcRules({
    this.remainderPolicy = RemainderPolicy.firstUsers,
    this.downtimePolicy = DowntimePolicy.shared,
    this.breakPolicy = BreakPolicy.deductFromShares,
  });

  final RemainderPolicy remainderPolicy;
  final DowntimePolicy downtimePolicy;
  final BreakPolicy breakPolicy;

  bool get extraToFirst => remainderPolicy == RemainderPolicy.firstUsers;

  CalcRules copyWith({
    RemainderPolicy? remainderPolicy,
    DowntimePolicy? downtimePolicy,
    BreakPolicy? breakPolicy,
  }) {
    return CalcRules(
      remainderPolicy: remainderPolicy ?? this.remainderPolicy,
      downtimePolicy: downtimePolicy ?? this.downtimePolicy,
      breakPolicy: breakPolicy ?? this.breakPolicy,
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'remainderPolicy': remainderPolicy.name,
        'downtimePolicy': downtimePolicy.name,
        'breakPolicy': breakPolicy.name,
      };

  static CalcRules fromJson(Map<String, dynamic> json) {
    return CalcRules(
      remainderPolicy: _enumFrom(
        RemainderPolicy.values,
        json['remainderPolicy'] as String?,
        RemainderPolicy.firstUsers,
      ),
      downtimePolicy: _enumFrom(
        DowntimePolicy.values,
        json['downtimePolicy'] as String?,
        DowntimePolicy.shared,
      ),
      breakPolicy: _enumFrom(
        BreakPolicy.values,
        json['breakPolicy'] as String?,
        BreakPolicy.deductFromShares,
      ),
    );
  }

  static T _enumFrom<T extends Enum>(List<T> values, String? name, T fallback) {
    for (final T v in values) {
      if (v.name == name) return v;
    }
    return fallback;
  }
}

/// نصوص عربية لعرض السياسات في الواجهة.
class CalcRulesLabels {
  const CalcRulesLabels._();

  static String remainder(RemainderPolicy p) {
    switch (p) {
      case RemainderPolicy.firstUsers:
        return 'الدقائق الزائدة للأوائل';
      case RemainderPolicy.lastUsers:
        return 'الدقائق الزائدة للأواخر';
    }
  }

  static String downtime(DowntimePolicy p) {
    switch (p) {
      case DowntimePolicy.shared:
        return 'توزيع مشترك بين صاحب الدور ومن لم يبدأوا';
      case DowntimePolicy.currentUserAbsorbs:
        return 'صاحب الدور وحده يتحمّل العطل';
      case DowntimePolicy.futureUsersOnly:
        return 'من لم يبدأ دوره فقط يتحمّلون العطل';
    }
  }

  static String breakPolicy(BreakPolicy p) {
    switch (p) {
      case BreakPolicy.extendSchedule:
        return 'التوقفات تمدّد الجدول (حصة تشغيل كاملة لكل مستخدم)';
      case BreakPolicy.deductFromShares:
        return 'الفترة ثابتة والتوقفات تُخصم من الحصص';
    }
  }
}
