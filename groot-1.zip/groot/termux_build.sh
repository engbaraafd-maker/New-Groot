#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# بناء Groot على Termux خطوة بخطوة، مع تشخيص عربي واضح عند أي خطأ.
#
#   bash termux_build.sh            # تجهيز + اختبارات + بناء APK
#   bash termux_build.sh test       # الاختبارات فقط
#   bash termux_build.sh apk        # البناء فقط (بعد تجهيز سابق)
#   bash termux_build.sh doctor     # فحص البيئة فقط
# ---------------------------------------------------------------------------

cd "$(dirname "$0")"
PROJECT_DIR="$(pwd)"
MODE="${1:-all}"

say()  { printf '\n\033[1;32m==> %s\033[0m\n' "$1"; }
warn() { printf '\033[1;33m[تنبيه] %s\033[0m\n' "$1"; }
err()  { printf '\033[1;31m[خطأ] %s\033[0m\n' "$1"; }

fail() {
  err "$1"
  [ -n "$2" ] && printf '\033[1;36mالحل: %s\033[0m\n' "$2"
  exit 1
}

# ---------------------------------------------------------------------------
# 1) فحص البيئة
# ---------------------------------------------------------------------------
doctor() {
  say "فحص البيئة"

  command -v flutter >/dev/null 2>&1 \
    || fail "الأمر flutter غير موجود في PATH." \
            "أضف مسار Flutter إلى PATH، مثال: export PATH=\$PATH:\$HOME/flutter/bin"
  echo "flutter : $(command -v flutter)"
  flutter --version 2>/dev/null | head -2

  command -v java >/dev/null 2>&1 \
    || fail "الأمر java غير موجود." "pkg install openjdk-21"
  echo "java    : $(java -version 2>&1 | head -1)"

  command -v git >/dev/null 2>&1 || fail "git غير مثبت." "pkg install git"

  # مسار Android SDK
  if [ -z "$ANDROID_SDK_ROOT" ] && [ -z "$ANDROID_HOME" ]; then
    for candidate in "$HOME/android-sdk" "$HOME/Android/Sdk" \
                     "$PREFIX/share/android-sdk" "$HOME/.android-sdk"; do
      [ -d "$candidate" ] && export ANDROID_SDK_ROOT="$candidate" && break
    done
  fi
  [ -z "$ANDROID_SDK_ROOT" ] && [ -n "$ANDROID_HOME" ] && export ANDROID_SDK_ROOT="$ANDROID_HOME"
  [ -z "$ANDROID_HOME" ] && [ -n "$ANDROID_SDK_ROOT" ] && export ANDROID_HOME="$ANDROID_SDK_ROOT"

  if [ -z "$ANDROID_SDK_ROOT" ]; then
    warn "لم أتعرف على مسار Android SDK تلقائيًا."
    warn "صدّره يدويًا ثم أعد التشغيل، مثال:"
    warn "  export ANDROID_SDK_ROOT=\$HOME/android-sdk"
  else
    echo "sdk     : $ANDROID_SDK_ROOT"
    flutter config --android-sdk "$ANDROID_SDK_ROOT" >/dev/null 2>&1 || true
  fi

  # aapt2 المتوافق مع ARM (أهم نقطة في Termux)
  if command -v aapt2 >/dev/null 2>&1; then
    AAPT2_PATH="$(command -v aapt2)"
    echo "aapt2   : $AAPT2_PATH"
  else
    AAPT2_PATH=""
    warn "aapt2 الخاص بـ Termux غير مثبت."
    warn "حزمة build-tools من Google مبنية لـ x86_64 ولن تعمل على ARM."
    warn "إن فشل البناء برسالة aapt2 نفّذ:  pkg install aapt2"
  fi

  git config --global --get-all safe.directory 2>/dev/null | grep -qx '\*' \
    || git config --global --add safe.directory '*' 2>/dev/null || true
}

# ---------------------------------------------------------------------------
# 2) تجهيز مجلد android
# ---------------------------------------------------------------------------
prepare() {
  if [ -f android/gradlew ] && [ -f android/app/src/main/AndroidManifest.xml ]; then
    say "مجلد android جاهز بالفعل — تخطّي التجهيز"
  else
    say "تجهيز مجلد android"
    bash prepare_android.sh || fail "فشل تجهيز مجلد android." \
      "شغّل: flutter create --platforms=android --org com --project-name groot ."
  fi

  say "ضبط local.properties"
  FLUTTER_ROOT="$(dirname "$(dirname "$(readlink -f "$(command -v flutter)")")")"
  {
    echo "flutter.sdk=$FLUTTER_ROOT"
    [ -n "$ANDROID_SDK_ROOT" ] && echo "sdk.dir=$ANDROID_SDK_ROOT"
  } > android/local.properties
  cat android/local.properties

  say "ضبط gradle.properties لبيئة Termux"
  GP=android/gradle.properties
  touch "$GP"
  set_prop() {
    grep -q "^$1=" "$GP" && sed -i "s|^$1=.*|$1=$2|" "$GP" || echo "$1=$2" >> "$GP"
  }
  set_prop "org.gradle.jvmargs" "-Xmx1536M -XX:MaxMetaspaceSize=512m"
  set_prop "org.gradle.daemon" "false"
  set_prop "org.gradle.parallel" "false"
  set_prop "android.useAndroidX" "true"
  if [ -n "$AAPT2_PATH" ]; then
    set_prop "android.aapt2FromMavenOverride" "$AAPT2_PATH"
  fi
  cat "$GP"
}

# ---------------------------------------------------------------------------
# 3) الحزم والاختبارات
# ---------------------------------------------------------------------------
run_tests() {
  say "جلب الحزم"
  flutter pub get || fail "فشل flutter pub get." "تأكد من الاتصال بالإنترنت لهذه الخطوة فقط."

  say "تشغيل اختبارات محرك الوقت"
  if flutter test; then
    say "كل الاختبارات نجحت ✓ — محرك الوقت سليم"
  else
    fail "سقط اختبار أو أكثر." \
      "أرسل لي اسم الاختبار والرسالة كما ظهرت، ولا تبنِ APK قبل إصلاحها."
  fi
}

# ---------------------------------------------------------------------------
# 4) بناء APK
# ---------------------------------------------------------------------------
build_apk() {
  say "بناء APK (release) — قد يستغرق عدة دقائق في أول مرة"
  if flutter build apk --release; then
    APK="build/app/outputs/flutter-apk/app-release.apk"
    [ -f "$APK" ] || APK="$(find build -name '*-release.apk' | head -1)"
    say "تم البناء"
    ls -lh "$APK"
    if [ -d "$HOME/storage/downloads" ]; then
      cp "$APK" "$HOME/storage/downloads/groot.apk" && \
        echo "نُسخت نسخة إلى: مجلد التنزيلات باسم groot.apk"
    else
      echo "لنسخه إلى مجلد التنزيلات: نفّذ termux-setup-storage ثم أعد التشغيل."
    fi
    echo "المسار الكامل: $PROJECT_DIR/$APK"
  else
    err "فشل بناء APK."
    cat <<'EOF'

الأعطال الشائعة على Termux وحلولها:

1) رسالة فيها aapt2 أو "cannot execute binary file"
     pkg install aapt2
   ثم أعد تشغيل السكربت (سيضيف android.aapt2FromMavenOverride تلقائيًا).

2) رسالة فيها zipalign أو apksigner
     pkg install android-tools

3) نفاد الذاكرة / Java heap space
   قلّل الذاكرة في android/gradle.properties:
     org.gradle.jvmargs=-Xmx1024M

4) "Could not determine java version" أو تعارض JDK
     export JAVA_HOME=$PREFIX/opt/openjdk

5) توقف التحميل عند Gradle distribution
   البناء الأول يحمّل Gradle كاملًا — اتركه ولا تقاطعه،
   أو شغّل مرة أخرى ليكمل من حيث توقف.

أرسل لي آخر 30 سطرًا من الخطأ وسأحدد السبب بدقة.
EOF
    exit 1
  fi
}

# ---------------------------------------------------------------------------
case "$MODE" in
  doctor) doctor ;;
  test)   doctor; prepare; run_tests ;;
  apk)    doctor; prepare; build_apk ;;
  all)    doctor; prepare; run_tests; build_apk ;;
  *)      echo "الاستخدام: bash termux_build.sh [all|doctor|test|apk]"; exit 1 ;;
esac
