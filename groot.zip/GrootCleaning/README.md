# GrootCleaning

**App & Account Automation** — Android 8.1+ (`minSdk 27`) automation dashboard for deterministic, user-selected cleanup flows.

## Engineering position

GrootCleaning does not use Root, Magisk, exploits, hidden permissions, or private APIs. It uses Android's public Settings intents plus a real `AccessibilityService` to detect and activate visible Settings controls. Android exposes accessibility nodes and actions to an enabled accessibility service, while account removal through `AccountManager.removeAccount()` is restricted for ordinary apps; therefore account removal in this app is intentionally attempted through the visible Settings UI and falls back to `REQUIRES_USER_ACTION` when the system UI cannot safely expose the action. citeturn755895search2turn276520search5

## Project stack

- Kotlin
- AndroidX AppCompat / Fragment / RecyclerView
- Room 2.8.5
- `minSdk 27` (Android 8.1 Oreo), `compileSdk 36`, `targetSdk 36`
- AGP 9.4.0 / Gradle 9.6 / JDK 17
- XML Views instead of a heavy Compose dependency tree

The AGP/Gradle/JDK combination is aligned with the September 2026 Android Gradle Plugin 9.4 compatibility guidance. citeturn383128search0

## Build

1. Open the folder in Android Studio.
2. Install Android SDK Platform 36 and a 36.x Build Tools package.
3. Use JDK 17.
4. Sync Gradle and build **app > assembleDebug**.
5. Install `app/build/outputs/apk/debug/app-debug.apk` on an Android 8.1+ device.

The repository also contains `gradle.properties` and a standard Android project layout. The execution environment used to generate this package did **not** contain an Android SDK or Gradle distribution and had no outbound package-network access, so APK compilation could not be executed here; source/resource static validation was performed instead.

## First-run setup

1. Launch GrootCleaning.
2. Read and accept the in-app Accessibility disclosure.
3. Tap **Open Accessibility Settings** and enable **GrootCleaning Automation**.
4. Optional: enable **Usage Access** so the Verification Engine can compare `StorageStatsManager` values before/after cleanup. Android documents `PACKAGE_USAGE_STATS` as special access granted through Settings. citeturn645590search0turn645590search4
5. In **Accounts**, grant the ordinary account permission when Android requests it. On Android 8+, this still does not provide universal account visibility; only accounts made visible to the app are listed. citeturn106121search0turn106121search3
6. Select apps and operations, and select visible accounts you intend to remove.
6. Use **Automation Test** first. It is detection-only and never clicks a destructive control.
7. Start with **Simulation Mode** before using destructive operations.

## Automation states

`PENDING`, `RUNNING`, `SUCCESS`, `FAILED`, `SKIPPED`, `REQUIRES_USER_ACTION`.
Verification can be `SUCCESS`, `FAILED`, or `VERIFICATION_UNCERTAIN`. A real cleanup task whose verification remains uncertain is surfaced to the user as `REQUIRES_USER_ACTION`; it is not counted as a successful cleanup.

## UI matching

All Settings labels are isolated in `automation/detection/TextCatalog.kt`, while OEM/package differences live under `automation/adapters/`. The engine uses state detection and context checks rather than fixed screen coordinates.

## Current technical limitations

### Clearing other apps
There is no ordinary public Android API that grants a normal app unrestricted authority to clear another app's private data. GrootCleaning therefore uses the user-visible Settings flow. On devices whose Settings implementation hides, renames, protects, or relocates the relevant control, the engine stops that task as `REQUIRES_USER_ACTION` instead of claiming success.

### Account removal
`AccountManager.removeAccount()` is permission-restricted and authenticator policies can also prevent deletion. GrootCleaning does not request or attempt to bypass those restrictions. It navigates to the visible account Settings page, attempts the deterministic user-selected flow, and verifies account absence only when the remaining account state is observable. citeturn276520search5

### Verification
The engine never treats a successful click as proof. Basic/Standard may use a verified UI-state change (the control changes/disappears); Strict requires stronger evidence and returns `VERIFICATION_UNCERTAIN` when reliable evidence is missing. When Usage Access is available, `StorageStatsManager` supplies per-package data/cache statistics for an additional verification signal. citeturn645590search4 citeturn645590search4

### Package visibility / Play distribution
The app declares `QUERY_ALL_PACKAGES` because its core UI is an installed-app inventory. Google Play treats broad package visibility as sensitive and only permits it for qualifying core use cases; Play also has specific Accessibility API disclosure/declaration rules for non-accessibility-tool apps. Review those rules before publishing. citeturn276520search6turn276520search0

## Future adapter work

- Expand Samsung/Xiaomi/Huawei/OPPO resource-ID maps from device captures.
- Add per-OEM Storage page state machines for One UI / MIUI / ColorOS variants.
- Add a structured Accessibility tree diagnostic export (local-only) for adapter maintenance.
- Add connected Android test matrices for API 27, 28, 30, 33, 35 and 36.
- Add stronger persisted resume checkpoints per step boundary.

### Auto-resume safety
The `Auto Resume` preference is persisted for UX/state management, but the accessibility service does not autonomously start a new cleanup run on its own. A run is resumed only through an explicit user action from the app. This keeps automation deterministic and user-controlled.
