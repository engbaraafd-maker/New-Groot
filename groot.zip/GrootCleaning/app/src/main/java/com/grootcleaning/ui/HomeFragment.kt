package com.grootcleaning.ui

import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.grootcleaning.R
import com.grootcleaning.data.DatabaseProvider
import com.grootcleaning.data.SelectionRepository
import com.grootcleaning.models.RunStatus
import com.grootcleaning.service.accessibility.GrootAccessibilityService
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class HomeFragment : Fragment() {
    private val executor = Executors.newSingleThreadExecutor()
    override fun onCreateView(inflater: android.view.LayoutInflater, container: android.view.ViewGroup?, savedInstanceState: Bundle?): View {
        val ctx = requireContext(); val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 10, 16, 20) }
        root.addView(Ui.tv(ctx, getString(R.string.app_description), 13f).apply { setTextColor(androidx.core.content.ContextCompat.getColor(ctx, R.color.gc_text_secondary)); setPadding(0,0,0,12) })
        val statusCard = Ui.card(ctx); root.addView(statusCard)
        val status = Ui.tv(ctx, getString(R.string.system_status), 12f, true); statusCard.addView(status)
        val statusValue = Ui.tv(ctx, if (GrootAccessibilityService.INSTANCE != null) getString(R.string.ready) else getString(R.string.accessibility_disabled), 22f, true); statusCard.addView(statusValue)
        val appsCount = Ui.tv(ctx, getString(R.string.applications_selected, 0)); statusCard.addView(appsCount)
        val accountsCount = Ui.tv(ctx, getString(R.string.accounts_selected, 0)); statusCard.addView(accountsCount)
        val lastRun = Ui.tv(ctx, getString(R.string.last_run)); statusCard.addView(lastRun)
        val lastResult = Ui.tv(ctx, getString(R.string.last_result)); statusCard.addView(lastResult)

        val start = Ui.button(ctx, getString(R.string.start_cleaning), true).apply { setOnClickListener { (activity as? MainActivity)?.startAutomation() } }
        root.addView(start, LinearLayout.LayoutParams(-1, 56).apply { setMargins(0, 8, 0, 18) })

        root.addView(Ui.tv(ctx, getString(R.string.quick_actions), 16f, true))
        val actions = Ui.card(ctx); root.addView(actions)
        val r1 = Ui.row(ctx); val apps = Ui.button(ctx, getString(R.string.apps)); val perms = Ui.button(ctx, getString(R.string.permissions)); r1.addView(apps, LinearLayout.LayoutParams(0, 48, 1f)); r1.addView(perms, LinearLayout.LayoutParams(0, 48, 1f).apply { marginStart=8 }); actions.addView(r1)
        val r2 = Ui.row(ctx); val accounts = Ui.button(ctx, getString(R.string.accounts)); val test = Ui.button(ctx, getString(R.string.test_automation)); r2.addView(accounts, LinearLayout.LayoutParams(0,48,1f)); r2.addView(test, LinearLayout.LayoutParams(0,48,1f).apply { marginStart=8 }); actions.addView(r2)
        apps.setOnClickListener { (activity as? MainActivity)?.show(AppsFragment()) }; accounts.setOnClickListener { (activity as? MainActivity)?.show(AccountsFragment()) }; perms.setOnClickListener { (activity as? MainActivity)?.show(SettingsFragment()) }; test.setOnClickListener { (activity as? MainActivity)?.openTest() }

        executor.execute {
            val repo = SelectionRepository(ctx); val db = DatabaseProvider.get(ctx); val ac = repo.apps.selected().size; val cc = repo.accounts.selected().size; val run = db.runDao().recent(1).firstOrNull()
            activity?.runOnUiThread {
                appsCount.text = getString(R.string.applications_selected, ac); accountsCount.text = getString(R.string.accounts_selected, cc)
                val isRunning = run?.status == RunStatus.RUNNING && GrootAccessibilityService.INSTANCE != null
                statusValue.text = when {
                    isRunning -> getString(R.string.running)
                    GrootAccessibilityService.INSTANCE == null -> getString(R.string.accessibility_disabled)
                    run?.status == RunStatus.COMPLETED_WITH_ERRORS -> getString(R.string.completed_with_errors)
                    else -> getString(R.string.ready)
                }
                if (run != null) {
                    lastRun.text = getString(R.string.last_run) + ": " + SimpleDateFormat("dd MMM — HH:mm", Locale.getDefault()).format(Date(run.startedAt))
                    val result = when (run.status) {
                        RunStatus.COMPLETED -> getString(R.string.success)
                        RunStatus.COMPLETED_WITH_ERRORS -> getString(R.string.partial)
                        RunStatus.FAILED -> getString(R.string.failed)
                        RunStatus.STOPPED -> getString(R.string.task_stopped)
                        else -> run.status.name
                    }
                    lastResult.text = getString(R.string.last_result) + ": " + result
                }
            }
        }
        return android.widget.ScrollView(ctx).apply { addView(root) }
    }
}
