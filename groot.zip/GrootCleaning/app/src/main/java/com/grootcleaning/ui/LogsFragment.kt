package com.grootcleaning.ui

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.grootcleaning.R
import com.grootcleaning.data.DatabaseProvider
import com.grootcleaning.data.RunEntity
import com.grootcleaning.models.TaskStatus
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class LogsFragment : Fragment() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var adapter: RunsAdapter
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val ctx=requireContext(); val root=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL;setPadding(16,8,16,10)}
        root.addView(Ui.tv(ctx,getString(R.string.activity_log),18f,true).apply{setPadding(0,0,0,12)})
        val list=RecyclerView(ctx).apply{layoutManager=LinearLayoutManager(ctx)};root.addView(list,LinearLayout.LayoutParams(-1,0,1f));adapter=RunsAdapter(ctx){showRun(it)};list.adapter=adapter
        load(); return root
    }
    private fun load(){executor.execute{val runs=DatabaseProvider.get(requireContext()).runDao().recent(100);requireActivity().runOnUiThread{adapter.submit(runs)}}}
    private fun showRun(run:RunEntity){executor.execute{val db=DatabaseProvider.get(requireContext());val tasks=db.taskLogDao().byRun(run.id);val text=buildString{append("${run.status.name}\n${getString(R.string.successful_count,run.successful)}\n${getString(R.string.failed_count,run.failed)}\n${getString(R.string.user_action_count,run.userAction)}\n${getString(R.string.skipped_count,run.skipped)}\n\n");tasks.forEach{t->append("• ${t.appName?:t.accountName?:"Unknown"} — ${t.status}\n");db.stepLogDao().byTask(t.id).forEach{s->append("    ${s.status == com.grootcleaning.models.StepStatus.SUCCESS?"✓":"•"} ${s.name} ${s.detail?:""}\n")}}};requireActivity().runOnUiThread{AlertDialog.Builder(requireContext()).setTitle(getString(R.string.activity_log)).setMessage(text).setPositiveButton(android.R.string.ok,null).show()}}}
}

class RunsAdapter(private val context:android.content.Context, private val onClick:(RunEntity)->Unit):RecyclerView.Adapter<RunsAdapter.VH>(){
    private val rows=mutableListOf<RunEntity>(); private val df=SimpleDateFormat("dd MMM — HH:mm",Locale.getDefault())
    fun submit(items:List<RunEntity>){rows.clear();rows.addAll(items);notifyDataSetChanged()}
    override fun onCreateViewHolder(p:ViewGroup,v:Int):VH{val card=Ui.card(p.context);val title=Ui.tv(p.context,"",15f,true);val meta=Ui.tv(p.context,"",12f);meta.setTextColor(androidx.core.content.ContextCompat.getColor(p.context,R.color.gc_text_secondary));card.addView(title);card.addView(meta);return VH(card,title,meta)}
    override fun getItemCount()=rows.size
    override fun onBindViewHolder(h:VH,pos:Int){val r=rows[pos];h.title.text=r.status.name;h.meta.text="${df.format(Date(r.startedAt))} • ${r.successful}✓ ${r.failed}✕ ${r.userAction}⚠";h.itemView.setOnClickListener{onClick(r)}}
    class VH(root:View,val title:TextView,val meta:TextView):RecyclerView.ViewHolder(root)
}
