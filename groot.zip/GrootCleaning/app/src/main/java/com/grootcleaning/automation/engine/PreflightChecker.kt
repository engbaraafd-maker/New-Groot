package com.grootcleaning.automation.engine

import android.content.Context
import android.os.Build
import com.grootcleaning.data.DatabaseProvider
import com.grootcleaning.service.accessibility.GrootAccessibilityService

data class PreflightResult(
    val accessibility: Boolean,
    val targets: Boolean,
    val automationEngine: Boolean,
    val settingsNavigation: Boolean,
    val deviceCompatibility: Boolean,
    val issues: List<String>
) {
    val ready: Boolean get() = issues.isEmpty()
}

class PreflightChecker(private val context: Context) {
    fun run(): PreflightResult {
        val db = DatabaseProvider.get(context)
        val targetCount = db.appSelectionDao().selected().size + db.accountSelectionDao().selected().size
        val issues = mutableListOf<String>()
        val accessibility = GrootAccessibilityService.INSTANCE != null
        val targets = targetCount > 0
        val compatibility = Build.VERSION.SDK_INT >= 27
        if (!accessibility) issues += "AccessibilityService is disabled"
        if (!targets) issues += "No selected apps or accounts"
        if (!compatibility) issues += "Android 8.1/API 27 or newer is required"
        return PreflightResult(
            accessibility = accessibility,
            targets = targets,
            automationEngine = true,
            settingsNavigation = true,
            deviceCompatibility = compatibility,
            issues = issues
        )
    }
}
