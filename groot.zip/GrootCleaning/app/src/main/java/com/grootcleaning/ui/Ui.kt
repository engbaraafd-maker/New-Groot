package com.grootcleaning.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.content.ContextCompat
import com.grootcleaning.R

object Ui {
    fun tv(context: Context, text: String, size: Float = 14f, bold: Boolean = false): TextView = TextView(context).apply {
        this.text = text
        textSize = size
        setTextColor(ContextCompat.getColor(context, R.color.gc_text_primary))
        if (bold) setTypeface(typeface, Typeface.BOLD)
        includeFontPadding = false
    }

    fun card(context: Context): LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundResource(R.drawable.bg_card)
        setPadding(16, 14, 16, 14)
        layoutParams = LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(0, 0, 0, 12) }
    }

    fun button(context: Context, text: String, primary: Boolean = false): Button = Button(context).apply {
        this.text = text
        textSize = 13f
        setTextColor(Color.WHITE)
        background = ContextCompat.getDrawable(context, if (primary) R.drawable.bg_primary_button else R.drawable.bg_secondary_button)
        isAllCaps = false
        minHeight = 48
        stateListAnimator = null
    }

    fun row(context: Context): LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, 10, 0, 10)
    }
}
