package com.grootcleaning.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import com.grootcleaning.R
import com.grootcleaning.data.DatabaseProvider
import com.grootcleaning.data.SelectionRepository
import com.grootcleaning.models.AutomationSettings
import com.grootcleaning.models.VerificationLevel
import com.grootcleaning.service.accessibility.GrootAccessibilityService
import java.util.concurrent.Executors

class SettingsFragment: Fragment(){
    private val executor=Executors.newSingleThreadExecutor()
    override fun onCreateView(inflater:LayoutInflater,container:ViewGroup?,savedInstanceState:Bundle?):View{
        val c=requireContext(); val root=LinearLayout(c).apply{orientation=LinearLayout.VERTICAL;setPadding(16,8,16,20)}
        val perm=Ui.card(c);root.addView(perm);perm.addView(Ui.tv(c,getString(R.string.permissions_title),17f,true))
        val a=Ui.row(c);a.addView(Ui.tv(c,getString(R.string.accessibility_status),14f),LinearLayout.LayoutParams(0,-2,1f));val av=Ui.tv(c,if(GrootAccessibilityService.INSTANCE!=null)getString(R.string.accessibility_enabled) else getString(R.string.accessibility_disabled_label),14f,true);a.addView(av);perm.addView(a)
        val openA=Ui.button(c,getString(R.string.open_accessibility_settings));perm.addView(openA);openA.setOnClickListener{showDisclosureOrOpen()}
        val accountRow=Ui.row(c);accountRow.addView(Ui.tv(c,getString(R.string.account_access),14f),LinearLayout.LayoutParams(0,-2,1f));val accountStatus=Ui.tv(c,if(Build.VERSION.SDK_INT < 23 || androidx.core.content.ContextCompat.checkSelfPermission(c, Manifest.permission.GET_ACCOUNTS)==PackageManager.PERMISSION_GRANTED)getString(R.string.accessibility_enabled) else getString(R.string.accessibility_disabled_label),14f,true);accountRow.addView(accountStatus);perm.addView(accountRow)
        val openAccounts=Ui.button(c,getString(R.string.open_account_access));perm.addView(openAccounts);openAccounts.setOnClickListener{(activity as? MainActivity)?.show(AccountsFragment())}
        val openU=Ui.button(c,getString(R.string.open_usage_access));perm.addView(openU);openU.setOnClickListener{(activity as? MainActivity)?.openUsageSettings()}
        val test=Ui.button(c,getString(R.string.test_automation));perm.addView(test);test.setOnClickListener{(activity as? MainActivity)?.openTest()}
        val adv=Ui.card(c);root.addView(adv);adv.addView(Ui.tv(c,getString(R.string.advanced_settings),17f,true))
        val timeout=EditText(c).apply{hint=getString(R.string.timeout_seconds);inputType=2};val retry=EditText(c).apply{hint=getString(R.string.retry_count);inputType=2};val delay=EditText(c).apply{hint=getString(R.string.delay_between_tasks);inputType=2};adv.addView(timeout);adv.addView(retry);adv.addView(delay)
        val cont=Switch(c).apply{text=getString(R.string.continue_after_failure);setTextColor(androidx.core.content.ContextCompat.getColor(c,R.color.gc_text_primary))};val auto=Switch(c).apply{text=getString(R.string.auto_resume);setTextColor(androidx.core.content.ContextCompat.getColor(c,R.color.gc_text_primary))};val sim=Switch(c).apply{text=getString(R.string.simulation_mode);setTextColor(androidx.core.content.ContextCompat.getColor(c,R.color.gc_text_primary))};val dbg=Switch(c).apply{text=getString(R.string.debug_logging);setTextColor(androidx.core.content.ContextCompat.getColor(c,R.color.gc_text_primary))};val sys=Switch(c).apply{text=getString(R.string.show_system_apps);setTextColor(androidx.core.content.ContextCompat.getColor(c,R.color.gc_text_primary))}
        adv.addView(cont);adv.addView(auto);adv.addView(sim);adv.addView(dbg);adv.addView(sys)
        val level=Spinner(c);level.adapter=ArrayAdapter(c,android.R.layout.simple_spinner_dropdown_item,listOf(getString(R.string.basic),getString(R.string.standard),getString(R.string.strict)));adv.addView(level)
        val save=Ui.button(c,getString(R.string.save_settings),true);adv.addView(save);save.setOnClickListener{val s=AutomationSettings((timeout.text.toString().toIntOrNull()?:12).coerceIn(5,60),(retry.text.toString().toIntOrNull()?:3).coerceIn(0,5),(delay.text.toString().toLongOrNull()?:300L).coerceIn(0,5000),cont.isChecked,auto.isChecked,sim.isChecked,dbg.isChecked,VerificationLevel.entries[level.selectedItemPosition],sys.isChecked);executor.execute{SelectionRepository(c).saveSettings(s)};Toast.makeText(c,getString(R.string.save_settings),Toast.LENGTH_SHORT).show()}
        val langs=Ui.row(c); val en=Ui.button(c,"English"); val ar=Ui.button(c,"العربية");langs.addView(en,LinearLayout.LayoutParams(0,48,1f));langs.addView(ar,LinearLayout.LayoutParams(0,48,1f).apply{marginStart=8});adv.addView(langs);en.setOnClickListener{(activity as? MainActivity)?.setLanguage("en")};ar.setOnClickListener{(activity as? MainActivity)?.setLanguage("ar")}
        executor.execute{val s=SelectionRepository(c).loadSettings();requireActivity().runOnUiThread{timeout.setText(s.timeoutSeconds.toString());retry.setText(s.retryCount.toString());delay.setText(s.delayBetweenTasksMs.toString());cont.isChecked=s.continueAfterFailure;auto.isChecked=s.autoResume;sim.isChecked=s.simulationMode;dbg.isChecked=s.debugLogging;sys.isChecked=s.includeSystemApps;level.setSelection(s.verificationLevel.ordinal)}}
        return ScrollView(c).apply{addView(root)}
    }
    private fun showDisclosureOrOpen(){if(com.grootcleaning.utils.AppPreferences.disclosureAccepted(requireContext()))(activity as? MainActivity)?.openAccessibilitySettings() else (activity as? MainActivity)?.let{it.runOnUiThread{android.widget.Toast.makeText(it,getString(R.string.prominent_disclosure_body),Toast.LENGTH_LONG).show()}}}
}
