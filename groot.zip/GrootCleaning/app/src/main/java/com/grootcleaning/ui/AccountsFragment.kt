package com.grootcleaning.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.grootcleaning.R
import com.grootcleaning.data.AccountCatalog
import com.grootcleaning.data.AccountSelectionEntity
import com.grootcleaning.data.DatabaseProvider
import com.grootcleaning.data.VisibleAccount
import java.util.concurrent.Executors

class AccountsFragment : Fragment() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var adapter: AccountAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val ctx = requireContext()
        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 8, 16, 10) }
        root.addView(Ui.tv(ctx, getString(R.string.account_warning), 13f).apply { setTextColor(androidx.core.content.ContextCompat.getColor(ctx, R.color.gc_warning)); setPadding(0, 0, 0, 12) })

        val grant = Ui.button(ctx, getString(R.string.grant_account_access))
        root.addView(grant, LinearLayout.LayoutParams(-1, 48).apply { bottomMargin = 10 })
        grant.setOnClickListener {
            if (Build.VERSION.SDK_INT >= 23) requestPermissions(arrayOf(Manifest.permission.GET_ACCOUNTS), REQUEST_ACCOUNTS)
        }

        val list = RecyclerView(ctx).apply { layoutManager = LinearLayoutManager(ctx) }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        adapter = AccountAdapter(ctx) { row ->
            executor.execute { DatabaseProvider.get(ctx).accountSelectionDao().upsert(AccountSelectionEntity(row.id, row.name, row.type, row.selected, System.currentTimeMillis())) }
        }
        list.adapter = adapter
        loadAccounts(ctx)
        return root
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_ACCOUNTS) loadAccounts(requireContext())
    }

    private fun loadAccounts(ctx: android.content.Context) {
        executor.execute {
            val saved = DatabaseProvider.get(ctx).accountSelectionDao().all().associateBy { it.id }
            val rows = AccountCatalog(ctx).load().map { a -> AccountRow(a.id, a.name, a.type, saved[a.id]?.selected ?: false) }
            requireActivity().runOnUiThread { adapter.submit(rows) }
        }
    }

    companion object {
        private const val REQUEST_ACCOUNTS = 4101
    }
}

data class AccountRow(val id: String, val name: String, val type: String, var selected: Boolean)

class AccountAdapter(private val context: android.content.Context, private val onChanged: (AccountRow) -> Unit) : RecyclerView.Adapter<AccountAdapter.VH>() {
    private val rows = mutableListOf<AccountRow>()
    fun submit(items: List<AccountRow>) { rows.clear(); rows.addAll(items); notifyDataSetChanged() }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val c = parent.context; val card = Ui.card(c); val row = Ui.row(c)
        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        val n = Ui.tv(c, "", 15f, true); val t = Ui.tv(c, "", 11f).apply { setTextColor(androidx.core.content.ContextCompat.getColor(c, R.color.gc_text_secondary)) }
        col.addView(n); col.addView(t); row.addView(col, LinearLayout.LayoutParams(0,-2,1f)); val cb = CheckBox(c); row.addView(cb); card.addView(row); return VH(card,n,t,cb)
    }
    override fun getItemCount() = rows.size
    override fun onBindViewHolder(h: VH, position: Int) { val r=rows[position]; h.name.text=r.name; h.type.text=r.type; h.check.setOnCheckedChangeListener(null); h.check.isChecked=r.selected; h.check.setOnCheckedChangeListener{_,v->r.selected=v;onChanged(r)} }
    class VH(root:View,val name:TextView,val type:TextView,val check:CheckBox):RecyclerView.ViewHolder(root)
}
