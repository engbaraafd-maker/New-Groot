package com.grootcleaning.ui

import android.content.*
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import java.util.concurrent.Executors
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.fragment.app.Fragment
import com.grootcleaning.R
import com.grootcleaning.service.accessibility.GrootAccessibilityService
import com.grootcleaning.utils.AppPreferences

class MainActivity : AppCompatActivity() {
    private val background = Executors.newSingleThreadExecutor()
    private lateinit var container: android.widget.FrameLayout
    private lateinit var bottom: android.widget.LinearLayout
    private lateinit var title: android.widget.TextView
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) { (supportFragmentManager.findFragmentById(container.id) as? ExecutionFragment)?.refreshFromBroadcast(intent.getStringExtra(GrootAccessibilityService.EXTRA_MESSAGE)) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        container = findViewById(R.id.main_container)
        bottom = findViewById(R.id.bottom_nav)
        title = findViewById(R.id.toolbar_title)
        setupNav()
        show(HomeFragment())
        maybeShowAccessibilityDisclosure()
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(GrootAccessibilityService.ACTION_STATE)
        if (android.os.Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, RECEIVER_NOT_EXPORTED) else registerReceiver(receiver, filter)
    }
    override fun onStop() { try { unregisterReceiver(receiver) } catch (_: Exception) {}; super.onStop() }

    fun show(fragment: Fragment, hideNav: Boolean = false) {
        supportFragmentManager.beginTransaction().replace(R.id.main_container, fragment).commit()
        bottom.visibility = if (hideNav) android.view.View.GONE else android.view.View.VISIBLE
    }

    private fun setupNav() {
        val ids = listOf(R.id.nav_home, R.id.nav_apps, R.id.nav_accounts, R.id.nav_logs, R.id.nav_settings)
        ids.forEach { id -> findViewById<android.widget.TextView>(id).setOnClickListener {
            when (id) { R.id.nav_home -> show(HomeFragment()); R.id.nav_apps -> show(AppsFragment()); R.id.nav_accounts -> show(AccountsFragment()); R.id.nav_logs -> show(LogsFragment()); R.id.nav_settings -> show(SettingsFragment()) }
        } }
    }

    fun openAccessibilitySettings() {
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    fun openUsageSettings() {
        startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
    }

    fun startAutomation() {
        val service = GrootAccessibilityService.INSTANCE
        if (service == null) {
            showPreflight(listOf(getString(R.string.accessibility_disabled)))
            return
        }
        background.execute {
            val result = com.grootcleaning.automation.engine.PreflightChecker(this).run()
            runOnUiThread {
                if (result.ready) {
                    sendBroadcast(Intent(GrootAccessibilityService.ACTION_START).setPackage(packageName))
                    show(ExecutionFragment(), hideNav = true)
                } else {
                    showPreflight(result.issues)
                }
            }
        }
    }

    private fun showPreflight(issues: List<String>) {
        val body = buildString {
            append(getString(R.string.system_check)).append("\n\n")
            append("✓ ").append(getString(R.string.accessibility_status)).append("\n")
            append(if (issues.isEmpty()) "✓ " else "✕ ").append(getString(R.string.preflight)).append(if (issues.isEmpty()) "" else ": ").append(issues.joinToString("; "))
        }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(getString(R.string.action_required))
            .setMessage(body)
            .setNegativeButton(android.R.string.cancel, null)
            .setPositiveButton(getString(R.string.open_settings)) { _, _ -> if (GrootAccessibilityService.INSTANCE == null) openAccessibilitySettings() else show(AppsFragment()) }
            .show()
    }

    fun stopAutomation() { sendBroadcast(Intent(GrootAccessibilityService.ACTION_STOP).setPackage(packageName)) }
    fun resumeAutomation() { sendBroadcast(Intent(GrootAccessibilityService.ACTION_RESUME).setPackage(packageName)); show(ExecutionFragment()) }
    fun retryFailed() { sendBroadcast(Intent(GrootAccessibilityService.ACTION_RETRY_FAILED).setPackage(packageName)); show(ExecutionFragment()) }
    fun skipCurrent() { sendBroadcast(Intent(GrootAccessibilityService.ACTION_SKIP).setPackage(packageName)) }
    fun openTest() { show(AutomationTestFragment(), hideNav = true) }

    fun setLanguage(tag: String) {
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag))
    }

    private fun maybeShowAccessibilityDisclosure() {
        if (AppPreferences.disclosureAccepted(this)) return
        val cb = android.widget.CheckBox(this).apply { text = getString(R.string.i_understand); setTextColor(getColorCompat(R.color.gc_text_primary)) }
        val box = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        box.addView(Ui.tv(this, getString(R.string.prominent_disclosure_body), 14f))
        box.addView(cb)
        android.app.AlertDialog.Builder(this)
            .setTitle(getString(R.string.prominent_disclosure_title))
            .setView(box)
            .setNegativeButton(android.R.string.cancel, null)
            .setPositiveButton(getString(R.string.continue_to_settings)) { _, _ ->
                if (cb.isChecked) { AppPreferences.setDisclosureAccepted(this, true); openAccessibilitySettings() }
                else android.widget.Toast.makeText(this, getString(R.string.i_understand), android.widget.Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun getColorCompat(id: Int) = androidx.core.content.ContextCompat.getColor(this, id)
}
