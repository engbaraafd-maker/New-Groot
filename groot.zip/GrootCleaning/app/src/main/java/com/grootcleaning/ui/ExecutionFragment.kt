package com.grootcleaning.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import com.grootcleaning.R
import com.grootcleaning.data.DatabaseProvider
import com.grootcleaning.models.TaskStatus
import com.grootcleaning.service.accessibility.GrootAccessibilityService
import com.grootcleaning.utils.AppPreferences
import java.util.concurrent.Executors

class ExecutionFragment : Fragment(){
    private val executor=Executors.newSingleThreadExecutor(); private lateinit var current:TextView; private lateinit var detail:TextView; private lateinit var progress:ProgressBar
    override fun onCreateView(inflater:LayoutInflater,container:ViewGroup?,savedInstanceState:Bundle?):View{
        val c=requireContext();val root=LinearLayout(c).apply{orientation=LinearLayout.VERTICAL;setPadding(16,12,16,20)}
        root.addView(Ui.tv(c,getString(R.string.cleaning_progress),20f,true));current=Ui.tv(c,"",18f,true);current.setPadding(0,14,0,8);root.addView(current);progress=ProgressBar(c,null,android.R.attr.progressBarStyleHorizontal);root.addView(progress,LinearLayout.LayoutParams(-1,10));detail=Ui.tv(c,"",14f);detail.setPadding(0,18,0,12);root.addView(detail)
        val buttons=Ui.row(c);val stop=Ui.button(c,getString(R.string.stop),true);val resume=Ui.button(c,getString(R.string.resume));val retry=Ui.button(c,getString(R.string.retry_failed));val skip=Ui.button(c,getString(R.string.skip));val manual=Ui.button(c,getString(R.string.open_manually));buttons.addView(stop,LinearLayout.LayoutParams(0,48,1f));buttons.addView(resume,LinearLayout.LayoutParams(0,48,1f).apply{marginStart=6});root.addView(buttons)
        val row2=Ui.row(c);row2.addView(retry,LinearLayout.LayoutParams(0,48,1f));row2.addView(skip,LinearLayout.LayoutParams(0,48,1f).apply{marginStart=6});row2.addView(manual,LinearLayout.LayoutParams(0,48,1f).apply{marginStart=6});root.addView(row2)
        stop.setOnClickListener{(activity as? MainActivity)?.stopAutomation()};resume.setOnClickListener{(activity as? MainActivity)?.resumeAutomation()};retry.setOnClickListener{(activity as? MainActivity)?.retryFailed()};skip.setOnClickListener{(activity as? MainActivity)?.skipCurrent()};manual.setOnClickListener{openCurrentManually()}
        refreshFromBroadcast("INIT");return ScrollView(c).apply{addView(root)}
    }
    fun refreshFromBroadcast(message:String?){executor.execute{val ctx=requireContext();val runId=AppPreferences.lastRunId(ctx);val db=DatabaseProvider.get(ctx);val run=if(runId!=0L)db.runDao().byId(runId)else null;val tasks=if(runId!=0L)db.taskLogDao().byRun(runId)else emptyList();val last=tasks.lastOrNull();val text=buildString{append((message?:run?.status?.name?:getString(R.string.ready))+"\n");if(last!=null){append("${last.appName?:last.accountName?:"—"}\n");append("${last.currentStep}\n");append(last.status.name);if(last.errorMessage!=null)append("\n${last.errorMessage}")}};requireActivity().runOnUiThread{current.text=last?.appName?:last?.accountName?:getString(R.string.ready);detail.text=text;progress.max=(run?.totalTasks?:1).coerceAtLeast(1);progress.progress=((tasks.size.toFloat()/(run?.totalTasks?:1).coerceAtLeast(1))*100).toInt()}}}
    private fun openCurrentManually(){executor.execute{val id=AppPreferences.lastRunId(requireContext());val task=if(id!=0L)DatabaseProvider.get(requireContext()).taskLogDao().byRun(id).lastOrNull()else null;requireActivity().runOnUiThread{
        when {
            task?.packageName != null -> startActivity(android.content.Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,android.net.Uri.parse("package:${task.packageName}")))
            task?.accountName != null -> startActivity(android.content.Intent(android.provider.Settings.ACTION_SYNC_SETTINGS))
            else -> Toast.makeText(requireContext(),getString(R.string.no_selected_targets),Toast.LENGTH_SHORT).show()
        }
    }}}
}
