#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# تجهيز مجلد android لمشروع Groot.
#
# السبب: ملفات Gradle (ومنها gradlew و gradle-wrapper.jar) يجب أن تُولَّد
# بنسخة Flutter الموجودة عندك بالضبط، حتى لا يحدث تعارض في إصدارات
# AGP / Kotlin / Gradle. هذا السكربت يولّدها ثم يطبّق إعدادات المشروع:
#
#   minSdkVersion = 26  (Android 8.0)
#   ABI: arm64-v8a و armeabi-v7a
#   اسم التطبيق: Groot
#
# التشغيل من داخل مجلد المشروع:
#   bash prepare_android.sh
# ---------------------------------------------------------------------------
set -e

cd "$(dirname "$0")"

if ! command -v flutter >/dev/null 2>&1; then
  echo "خطأ: الأمر flutter غير موجود في PATH."
  exit 1
fi

echo "==> حفظ نسخة احتياطية من lib و test"
rm -rf .groot_backup
mkdir -p .groot_backup
cp -r lib .groot_backup/lib
cp -r test .groot_backup/test
cp pubspec.yaml .groot_backup/pubspec.yaml

echo "==> توليد مجلد android بنسخة Flutter المثبتة عندك"
rm -rf android
flutter create --platforms=android --org com --project-name groot .

echo "==> استرجاع الكود الأصلي"
rm -rf lib test
cp -r .groot_backup/lib lib
cp -r .groot_backup/test test
cp .groot_backup/pubspec.yaml pubspec.yaml
rm -rf .groot_backup
# ملف الاختبار الافتراضي الذي قد يضيفه flutter create ولا نحتاجه
rm -f test/widget_test.dart

GRADLE_FILE=""
if [ -f android/app/build.gradle.kts ]; then
  GRADLE_FILE="android/app/build.gradle.kts"
elif [ -f android/app/build.gradle ]; then
  GRADLE_FILE="android/app/build.gradle"
else
  echo "تحذير: لم يتم العثور على ملف build.gradle الخاص بالتطبيق."
fi

if [ -n "$GRADLE_FILE" ]; then
  echo "==> ضبط minSdk = 26 في $GRADLE_FILE"
  # يغطي الصيغ: minSdk = flutter.minSdkVersion / minSdk 21 / minSdkVersion 21
  sed -i -E 's/minSdk(Version)?[[:space:]]*=?[[:space:]]*[A-Za-z0-9_.]+/minSdk = 26/' "$GRADLE_FILE"

  if ! grep -q "abiFilters" "$GRADLE_FILE"; then
    echo "==> إضافة دعم arm64-v8a و armeabi-v7a"
    if [ "${GRADLE_FILE##*.}" = "kts" ]; then
      sed -i '0,/minSdk = 26/s//minSdk = 26\n        ndk {\n            abiFilters += listOf("arm64-v8a", "armeabi-v7a")\n        }/' "$GRADLE_FILE"
    else
      sed -i '0,/minSdk = 26/s//minSdk = 26\n        ndk {\n            abiFilters.addAll(["arm64-v8a", "armeabi-v7a"])\n        }/' "$GRADLE_FILE"
    fi
  fi
fi

MANIFEST="android/app/src/main/AndroidManifest.xml"
if [ -f "$MANIFEST" ]; then
  echo "==> ضبط اسم التطبيق إلى Groot"
  sed -i -E 's/android:label="[^"]*"/android:label="Groot"/' "$MANIFEST"
fi

echo "==> تنزيل خطوط الهوية (أميري للعناوين، طجوال للنصوص)"
mkdir -p assets/fonts
FONT_BASE="https://raw.githubusercontent.com/google/fonts/main/ofl"
FONT_OK=1
for SPEC in "amiri/Amiri-Regular.ttf" "amiri/Amiri-Bold.ttf" \
            "tajawal/Tajawal-Regular.ttf" "tajawal/Tajawal-Medium.ttf" "tajawal/Tajawal-Bold.ttf"; do
  NAME=$(basename "$SPEC")
  if [ ! -s "assets/fonts/$NAME" ]; then
    curl -fsSL --retry 2 --max-time 60 "$FONT_BASE/$SPEC" -o "assets/fonts/$NAME" || FONT_OK=0
  fi
done
for NAME in Amiri-Regular.ttf Amiri-Bold.ttf Tajawal-Regular.ttf Tajawal-Medium.ttf Tajawal-Bold.ttf; do
  [ -s "assets/fonts/$NAME" ] || FONT_OK=0
done

if [ "$FONT_OK" = "1" ]; then
  if grep -q "family: Amiri" pubspec.yaml; then
    echo "    الخطوط معرّفة بالفعل في pubspec.yaml"
  else
    echo "    تعريف الخطوط في pubspec.yaml"
    cat >> pubspec.yaml <<'YAML'

  fonts:
    - family: Amiri
      fonts:
        - asset: assets/fonts/Amiri-Regular.ttf
        - asset: assets/fonts/Amiri-Bold.ttf
          weight: 700
    - family: Tajawal
      fonts:
        - asset: assets/fonts/Tajawal-Regular.ttf
        - asset: assets/fonts/Tajawal-Medium.ttf
          weight: 500
        - asset: assets/fonts/Tajawal-Bold.ttf
          weight: 700
YAML
  fi
else
  echo "    تعذّر تنزيل الخطوط — سيستخدم التطبيق خط النظام (لا يؤثر على البناء)"
  rm -rf assets/fonts
fi

echo "==> شاشة البدء بلون الهوية"
RES=android/app/src/main/res
mkdir -p "$RES/values" "$RES/drawable" "$RES/drawable-v21"
cat > "$RES/values/colors.xml" <<'XML'
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="groot_navy">#FF081824</color>
</resources>
XML
for D in "$RES/drawable" "$RES/drawable-v21"; do
  cat > "$D/launch_background.xml" <<'XML'
<?xml version="1.0" encoding="utf-8"?>
<layer-list xmlns:android="http://schemas.android.com/apk/res/android">
    <item android:drawable="@color/groot_navy" />
    <item>
        <bitmap
            android:gravity="center"
            android:src="@mipmap/ic_launcher" />
    </item>
</layer-list>
XML
done

if [ -d android_icons ]; then
  echo "==> تركيب أيقونة التطبيق"
  for d in android_icons/mipmap-*; do
    NAME=$(basename "$d")
    mkdir -p "android/app/src/main/res/$NAME"
    cp "$d/ic_launcher.png" "android/app/src/main/res/$NAME/ic_launcher.png"
  done
fi

echo "==> تثبيت توقيع دائم للـ APK"
if [ -f signing/groot.jks ]; then
  cp signing/groot.jks android/app/groot.jks
  python3 tools/patch_signing.py || echo "    تحذير: لم يُضبط التوقيع الدائم"
else
  echo "    لا يوجد مفتاح في signing/ — سيُستخدم مفتاح مؤقت"
fi

echo "==> جلب الحزم"
flutter pub get

echo
echo "تم التجهيز. الخطوات التالية:"
echo "  flutter test                  # لتشغيل اختبارات محرك الوقت"
echo "  flutter build apk --release   # لبناء ملف APK"
echo
echo "ملاحظة: التطبيق لا يطلب صلاحية الإنترنت، ويعمل بالكامل بدون اتصال."
