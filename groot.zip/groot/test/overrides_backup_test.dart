import 'package:flutter_test/flutter_test.dart';
import 'package:groot/core/time_utils.dart';
import 'package:groot/models/day_override.dart';
import 'package:groot/models/user.dart';
import 'package:groot/services/app_repository.dart';
import 'package:groot/services/backup_service.dart';
import 'package:groot/services/rotation_service.dart';
import 'package:groot/services/storage_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<AppRepository> buildRepo() async {
  SharedPreferences.setMockInitialValues(<String, Object>{});
  final StorageService storage = await StorageService.open();
  return AppRepository(storage);
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('استثناءات اليوم — النموذج', () {
    test('تعليم الغياب وإلغاؤه', () {
      final DayOverride o = DayOverride(dateKey: '2026-09-26');
      expect(o.isEmpty, isTrue);
      o.toggleAbsent('u1');
      expect(o.absentUserIds, <String>{'u1'});
      expect(o.isEmpty, isFalse);
      o.toggleAbsent('u1');
      expect(o.absentUserIds, isEmpty);
      expect(o.isEmpty, isTrue);
    });

    test('التبديل يعمل في الاتجاهين', () {
      final DayOverride o = DayOverride(dateKey: '2026-09-26')
        ..addSwap('a', 'b');
      expect(o.swapMap['a'], 'b');
      expect(o.swapMap['b'], 'a');
    });

    test('تبديل جديد يلغي تبديلًا سابقًا لنفس الشخص', () {
      final DayOverride o = DayOverride(dateKey: 'd')
        ..addSwap('a', 'b')
        ..addSwap('a', 'c');
      expect(o.swaps.length, 1);
      expect(o.swapMap['a'], 'c');
      expect(o.swapMap.containsKey('b'), isFalse);
    });

    test('الغياب يلغي تبديل الغائب', () {
      final DayOverride o = DayOverride(dateKey: 'd')..addSwap('a', 'b');
      o.toggleAbsent('a');
      expect(o.swaps, isEmpty);
      expect(o.absentUserIds, <String>{'a'});
    });

    test('الحفظ والاسترجاع لا يفقدان شيئًا', () {
      final DayOverride o = DayOverride(dateKey: '2026-09-26')
        ..toggleAbsent('u3')
        ..addSwap('u1', 'u2');
      final DayOverride back = DayOverride.fromJson(o.toJson());
      expect(back.dateKey, '2026-09-26');
      expect(back.absentUserIds, <String>{'u3'});
      expect(back.swapMap['u1'], 'u2');
    });
  });

  group('استثناءات اليوم — الأثر على الترتيب', () {
    test('الغائب يختفي من ترتيب اليوم ولا يتأثر يوم آخر', () async {
      final AppRepository repo = await buildRepo();
      for (final String n in <String>['أحمد', 'محمد', 'علي', 'خالد']) {
        await repo.addUser(n);
      }
      await repo.addDevice('جهاز 1');
      await repo.rebuildGroups();

      final DateTime today = DateTime(2026, 9, 26);
      final DateTime tomorrow = DateTime(2026, 9, 27);
      expect(repo.assignmentsFor(today).first.orderedUsers.length, 4);

      final String absentId = repo.users[1].id;
      await repo.toggleAbsent(today, absentId);

      final List<User> ordered = repo.assignmentsFor(today).first.orderedUsers;
      expect(ordered.length, 3);
      expect(ordered.any((User u) => u.id == absentId), isFalse);
      // اليوم التالي لم يتأثر.
      expect(repo.assignmentsFor(tomorrow).first.orderedUsers.length, 4);
      // المجموعة الثابتة لم تتغيّر.
      expect(repo.groups.first.memberIds.length, 4);
    });

    test('التبديل يتبادل الموقعين في ذلك اليوم فقط', () async {
      final AppRepository repo = await buildRepo();
      for (final String n in <String>['أ', 'ب', 'ج', 'د']) {
        await repo.addUser(n);
      }
      await repo.addDevice('جهاز 1');
      await repo.rebuildGroups();

      final DateTime day = DateTime(2026, 9, 26);
      final List<User> before = repo.assignmentsFor(day).first.orderedUsers;
      final String first = before[0].id;
      final String third = before[2].id;

      await repo.setSwap(day, first, third);
      final List<User> after = repo.assignmentsFor(day).first.orderedUsers;
      expect(after[0].id, third);
      expect(after[2].id, first);
      expect(after.length, 4);
      expect(after.map((User u) => u.id).toSet(),
          before.map((User u) => u.id).toSet());
    });

    test('مسح الاستثناءات يعيد الترتيب الأصلي', () async {
      final AppRepository repo = await buildRepo();
      for (final String n in <String>['أ', 'ب', 'ج']) {
        await repo.addUser(n);
      }
      await repo.addDevice('جهاز 1');
      await repo.rebuildGroups();

      final DateTime day = DateTime(2026, 9, 26);
      await repo.toggleAbsent(day, repo.users.first.id);
      expect(repo.assignmentsFor(day).first.orderedUsers.length, 2);
      await repo.clearOverrides(day);
      expect(repo.assignmentsFor(day).first.orderedUsers.length, 3);
    });
  });

  group('النسخ الاحتياطي', () {
    test('تصدير ثم استعادة يعيدان البيانات كما هي', () async {
      final AppRepository repo = await buildRepo();
      for (final String n in <String>['أحمد', 'محمد', 'علي', 'خالد']) {
        await repo.addUser(n);
      }
      await repo.addDevice('جهاز 1');
      await repo.addDevice('جهاز 2');
      await repo.rebuildGroups();
      repo.settings.prayer.cityName = 'أسيوط';
      await repo.saveSettings();

      final String backup = BackupService.export(repo);
      expect(backup.contains('groot'), isTrue);

      // إتلاف الحالة الحالية
      await repo.resetAll();
      expect(repo.users, isEmpty);
      expect(repo.devices, isEmpty);

      final RestoreResult r = BackupService.parse(backup, repo);
      expect(r.ok, isTrue, reason: r.message);
      expect(repo.users.length, 4);
      expect(repo.devices.length, 2);
      expect(repo.groups.length, 2);
      expect(repo.settings.prayer.cityName, 'أسيوط');
      expect(repo.users.map((User u) => u.name).toList(),
          <String>['أحمد', 'محمد', 'علي', 'خالد']);
    });

    test('نص تالف يُرفض برسالة واضحة ولا يمسّ البيانات', () async {
      final AppRepository repo = await buildRepo();
      await repo.addUser('أحمد');
      final RestoreResult r = BackupService.parse('{ نص غير صالح', repo);
      expect(r.ok, isFalse);
      expect(r.message.isNotEmpty, isTrue);
      expect(repo.users.length, 1);
    });

    test('نسخة تطبيق آخر تُرفض', () async {
      final AppRepository repo = await buildRepo();
      final RestoreResult r =
          BackupService.parse('{"app":"other","users":[]}', repo);
      expect(r.ok, isFalse);
    });
  });

  group('تسجيل العطل لحظيًا', () {
    test('البدء ثم الإنهاء يسجّل عطلًا بمدة حقيقية', () async {
      final AppRepository repo = await buildRepo();
      await repo.addDevice('جهاز 1');
      final String id = repo.devices.first.id;
      final DateTime day = DateTime(2026, 9, 26);

      expect(repo.activeDowntimeFor(id), isNull);
      await repo.startDowntimeNow(id);
      expect(repo.activeDowntimeFor(id), isNotNull);

      await repo.endDowntimeNow(id, day);
      expect(repo.activeDowntimeFor(id), isNull);
      final List<dynamic> events = repo.downtimesForDate(day);
      expect(events.length, 1);
      expect(repo.downtimes.first.durationMinutes >= 1, isTrue);
      expect(repo.downtimes.first.deviceId, id);
      expect(repo.downtimes.first.dateKey, TimeUtils.dateKey(day));
    });

    test('التجاهل لا يسجّل شيئًا', () async {
      final AppRepository repo = await buildRepo();
      await repo.addDevice('جهاز 1');
      final String id = repo.devices.first.id;
      await repo.startDowntimeNow(id);
      await repo.cancelActiveDowntime(id);
      expect(repo.activeDowntimeFor(id), isNull);
      expect(repo.downtimes, isEmpty);
    });

    test('لا يبدأ عطلان على نفس الجهاز', () async {
      final AppRepository repo = await buildRepo();
      await repo.addDevice('جهاز 1');
      final String id = repo.devices.first.id;
      await repo.startDowntimeNow(id);
      await repo.startDowntimeNow(id);
      expect(repo.activeDowntimes.length, 1);
    });
  });

  group('التدوير غير متأثر بالاستثناءات', () {
    test('المجموعة تبقى على نفس الجهاز مهما غاب أحدهم', () async {
      final AppRepository repo = await buildRepo();
      for (int i = 1; i <= 6; i++) {
        await repo.addUser('م$i');
      }
      await repo.addDevice('جهاز 1');
      await repo.addDevice('جهاز 2');
      await repo.rebuildGroups();

      final DateTime day = DateTime(2026, 9, 26);
      final int before = repo.assignmentsFor(day).first.groupIndex;
      await repo.toggleAbsent(day, repo.users.first.id);
      expect(repo.assignmentsFor(day).first.groupIndex, before);
      expect(
        RotationService.groupIndexForDevice(
            deviceIndex: 0, dayIndexValue: repo.dayIndexFor(day), deviceCount: 2),
        before,
      );
    });
  });
}
