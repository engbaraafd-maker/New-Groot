#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""تثبيت توقيع الـ APK بمفتاح دائم.

بدون هذا التعديل يوقّع Flutter نسخة الإصدار بمفتاح تصحيح مؤقت يتغيّر مع كل
بناء، فلا يمكن تثبيت أي تحديث فوق النسخة المثبّتة إلا بحذف التطبيق وبياناته.

يعدّل ملف android/app/build.gradle أو build.gradle.kts:
  1. يضيف signingConfigs يشير إلى groot.jks
  2. يجعل نسخة الإصدار تستخدمه بدل مفتاح التصحيح
"""
import re
import sys
import pathlib

APP = pathlib.Path('android/app')

GROOVY_BLOCK = '''    signingConfigs {
        release {
            storeFile file("groot.jks")
            storePassword "grootstore"
            keyAlias "groot"
            keyPassword "grootstore"
        }
    }

'''

KTS_BLOCK = '''    signingConfigs {
        create("release") {
            storeFile = file("groot.jks")
            storePassword = "grootstore"
            keyAlias = "groot"
            keyPassword = "grootstore"
        }
    }

'''


def main() -> int:
    groovy = APP / 'build.gradle'
    kts = APP / 'build.gradle.kts'

    if kts.exists():
        path, block, is_kts = kts, KTS_BLOCK, True
    elif groovy.exists():
        path, block, is_kts = groovy, GROOVY_BLOCK, False
    else:
        print('    لم يُعثر على ملف build.gradle الخاص بالتطبيق — تخطّي التوقيع')
        return 1

    src = path.read_text(encoding='utf-8')

    if 'groot.jks' in src:
        print('    التوقيع الدائم مضبوط بالفعل')
        return 0

    # (1) إدراج signingConfigs قبل buildTypes
    m = re.search(r'^([ \t]*)buildTypes\s*\{', src, re.M)
    if not m:
        print('    تعذّر العثور على buildTypes — تخطّي التوقيع')
        return 1
    src = src[:m.start()] + block + src[m.start():]

    # (2) توجيه نسخة الإصدار إلى المفتاح الدائم
    if is_kts:
        new_src, n = re.subn(
            r'signingConfig\s*=\s*signingConfigs\.getByName\("debug"\)',
            'signingConfig = signingConfigs.getByName("release")',
            src,
        )
    else:
        new_src, n = re.subn(
            r'signingConfig\s+signingConfigs\.debug',
            'signingConfig signingConfigs.release',
            src,
        )
        if n == 0:
            new_src, n = re.subn(
                r'signingConfig\s*=\s*signingConfigs\.debug',
                'signingConfig = signingConfigs.release',
                src,
            )

    if n == 0:
        # لا يوجد سطر توقيع في نسخة الإصدار: نضيفه داخل release { }
        pattern = r'(buildTypes\s*\{\s*(?:getByName\(")?release("\))?\s*\{)'
        line = ('            signingConfig = signingConfigs.getByName("release")\n'
                if is_kts else
                '            signingConfig signingConfigs.release\n')
        new_src, n = re.subn(pattern, lambda mm: mm.group(1) + '\n' + line, src, count=1)

    if n == 0:
        print('    تعذّر ضبط توقيع نسخة الإصدار — تخطّي')
        return 1

    path.write_text(new_src, encoding='utf-8')
    print(f'    تم ضبط التوقيع الدائم في {path}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
