import '../core/time_utils.dart';
import '../models/schedule_entry.dart';
import '../models/schedule_report.dart';
import 'app_repository.dart';

/// تحويل جدول اليوم إلى نص عربي جاهز للمشاركة.
///
/// النص مصمَّم ليُقرأ في واتساب أو رسالة قصيرة: أسطر قصيرة وبلا جداول.
class ScheduleText {
  const ScheduleText._();

  /// ملخص اليوم لكل الأجهزة.
  static String forDay({
    required DateTime date,
    required ScheduleComputation result,
    required int cycleNumber,
    required int deviceCount,
  }) {
    final StringBuffer b = StringBuffer();
    b.writeln('جدول اليوم — Groot');
    b.writeln(TimeUtils.formatDateArabic(date));
    if (deviceCount > 0) {
      b.writeln('دورة اليوم: $cycleNumber من $deviceCount');
    }
    b.writeln('');

    for (final ScheduleReport r in result.reports) {
      b.writeln('▪ ${r.deviceName ?? 'جهاز'} — ${r.groupName ?? ''}');
      for (final ScheduleEntry e in r.entries) {
        final String line =
            '${e.orderInGroup}. ${e.userName}  ${e.turnStartLabel} ← ${e.turnEndLabel}';
        b.writeln(line);
        final List<String> extra = <String>[];
        if (e.pauseMinutes > 0) {
          extra.add('توقف ${TimeUtils.formatDuration(e.pauseMinutes)}');
        }
        if (e.downtimeMinutes > 0) {
          extra.add('عطل ${TimeUtils.formatDuration(e.downtimeMinutes)}');
        }
        if (extra.isNotEmpty) {
          b.writeln('   (${extra.join(' • ')})');
        }
      }
      b.writeln('   تشغيل ${TimeUtils.formatDuration(r.summary.operatingMinutes)}'
          ' • نهاية ${TimeUtils.formatHm(r.scheduleEndMinute)}');
      b.writeln('');
    }

    if (result.errors.isNotEmpty) {
      b.writeln('تنبيهات:');
      for (final String e in result.errors) {
        b.writeln('- $e');
      }
    }
    return b.toString().trimRight();
  }

  /// الخط الزمني التفصيلي لجهاز واحد.
  static String timeline(ScheduleReport r, DateTime date) {
    final StringBuffer b = StringBuffer();
    b.writeln('الخط الزمني — ${r.deviceName ?? 'جهاز'}');
    b.writeln(TimeUtils.formatDateArabic(date));
    b.writeln('');
    for (final TimelineSegment s in r.timeline) {
      final String who = s.type == SegmentType.operating
          ? ' — ${s.userName ?? ''}'
          : (s.betweenTurns ? ' (بين الدورين)' : '');
      b.writeln('${s.rangeLabel}  ${s.label}$who'
          '  (${TimeUtils.formatDuration(s.durationMinutes)})');
    }
    b.writeln('');
    b.writeln('إجمالي التشغيل ${TimeUtils.formatDuration(r.summary.operatingMinutes)}'
        ' • الصلاة ${TimeUtils.formatDuration(r.summary.prayerMinutes)}'
        ' • الراحة ${TimeUtils.formatDuration(r.summary.restMinutes)}'
        ' • الأعطال ${TimeUtils.formatDuration(r.summary.downtimeMinutes)}');
    return b.toString().trimRight();
  }
}
