import 'dart:convert';

import '../models/app_settings.dart';
import '../models/day_override.dart';
import '../models/device.dart';
import '../models/downtime_event.dart';
import '../models/group.dart';
import '../models/user.dart';
import 'app_repository.dart';

/// نتيجة محاولة استعادة نسخة احتياطية.
class RestoreResult {
  const RestoreResult({required this.ok, required this.message});

  final bool ok;
  final String message;
}

/// نسخ احتياطي واستعادة — كل بيانات التطبيق في نص واحد.
///
/// البيانات محلية بالكامل، فلو ضاع الهاتف أو مُسحت بيانات التطبيق ضاع كل
/// شيء. هذا النص هو الحماية: انسخه واحفظه في أي مكان، واستعده متى شئت.
class BackupService {
  const BackupService._();

  static const int formatVersion = 1;

  /// توليد نص النسخة الاحتياطية.
  static String export(AppRepository repo) {
    final Map<String, dynamic> data = <String, dynamic>{
      'app': 'groot',
      'version': formatVersion,
      'exportedAt': DateTime.now().toIso8601String(),
      'users': repo.users.map((User u) => u.toJson()).toList(),
      'devices': repo.devices.map((Device d) => d.toJson()).toList(),
      'groups': repo.groups.map((Group g) => g.toJson()).toList(),
      'downtimes': repo.downtimes.map((DowntimeEvent d) => d.toJson()).toList(),
      'overrides': repo.overrides.map((DayOverride o) => o.toJson()).toList(),
      'settings': repo.settings.toJson(),
    };
    return const JsonEncoder.withIndent('  ').convert(data);
  }

  /// قراءة نص نسخة احتياطية والتحقق منه قبل تطبيقه.
  static RestoreResult parse(String raw, AppRepository repo) {
    final String text = raw.trim();
    if (text.isEmpty) {
      return const RestoreResult(ok: false, message: 'النص فارغ.');
    }

    dynamic decoded;
    try {
      decoded = jsonDecode(text);
    } catch (_) {
      return const RestoreResult(
        ok: false,
        message: 'النص غير صالح — تأكد من نسخه كاملًا.',
      );
    }

    if (decoded is! Map) {
      return const RestoreResult(ok: false, message: 'صيغة النسخة غير معروفة.');
    }

    final Map<String, dynamic> map = Map<String, dynamic>.from(decoded);
    if (map['app'] != 'groot') {
      return const RestoreResult(
        ok: false,
        message: 'هذه النسخة ليست من تطبيق Groot.',
      );
    }

    try {
      final List<User> users = _list(map['users']).map(User.fromJson).toList();
      final List<Device> devices =
          _list(map['devices']).map(Device.fromJson).toList();
      final List<Group> groups =
          _list(map['groups']).map(Group.fromJson).toList();
      final List<DowntimeEvent> downtimes =
          _list(map['downtimes']).map(DowntimeEvent.fromJson).toList();
      final List<DayOverride> overrides =
          _list(map['overrides']).map(DayOverride.fromJson).toList();
      final AppSettings settings = map['settings'] == null
          ? AppSettings()
          : AppSettings.fromJson(
              Map<String, dynamic>.from(map['settings'] as Map<dynamic, dynamic>));

      repo.replaceAll(
        users: users,
        devices: devices,
        groups: groups,
        downtimes: downtimes,
        overrides: overrides,
        settings: settings,
      );

      return RestoreResult(
        ok: true,
        message: 'تمت الاستعادة: ${users.length} مستخدمًا، '
            '${devices.length} جهازًا، ${groups.length} مجموعة.',
      );
    } catch (_) {
      return const RestoreResult(
        ok: false,
        message: 'تعذّرت القراءة — النسخة ناقصة أو تالفة.',
      );
    }
  }

  static List<Map<String, dynamic>> _list(dynamic value) {
    if (value is! List) return <Map<String, dynamic>>[];
    return value
        .whereType<Map<dynamic, dynamic>>()
        .map((Map<dynamic, dynamic> e) => Map<String, dynamic>.from(e))
        .toList();
  }
}
