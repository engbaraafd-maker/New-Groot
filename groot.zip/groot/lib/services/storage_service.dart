import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/app_settings.dart';
import '../models/day_override.dart';
import '../models/device.dart';
import '../models/downtime_event.dart';
import '../models/group.dart';
import '../models/user.dart';

/// التخزين المحلي — يعمل بالكامل بدون إنترنت.
///
/// كل البيانات تُحفظ كنصوص JSON داخل SharedPreferences، ولا تضيع
/// عند إغلاق التطبيق.
class StorageService {
  StorageService(this._prefs);

  static const String _kUsers = 'groot_users_v1';
  static const String _kDevices = 'groot_devices_v1';
  static const String _kGroups = 'groot_groups_v1';
  static const String _kSettings = 'groot_settings_v1';
  static const String _kDowntimes = 'groot_downtimes_v1';
  static const String _kOverrides = 'groot_overrides_v1';
  static const String _kActive = 'groot_active_downtimes_v1';

  final SharedPreferences _prefs;

  static Future<StorageService> open() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    return StorageService(prefs);
  }

  List<Map<String, dynamic>> _readList(String key) {
    final String? raw = _prefs.getString(key);
    if (raw == null || raw.isEmpty) return <Map<String, dynamic>>[];
    try {
      final dynamic decoded = jsonDecode(raw);
      if (decoded is! List) return <Map<String, dynamic>>[];
      return decoded
          .whereType<Map<dynamic, dynamic>>()
          .map((Map<dynamic, dynamic> e) => Map<String, dynamic>.from(e))
          .toList();
    } catch (_) {
      return <Map<String, dynamic>>[];
    }
  }

  Future<void> _writeList(String key, List<Map<String, dynamic>> value) {
    return _prefs.setString(key, jsonEncode(value));
  }

  List<User> loadUsers() =>
      _readList(_kUsers).map(User.fromJson).toList();

  Future<void> saveUsers(List<User> users) =>
      _writeList(_kUsers, users.map((User u) => u.toJson()).toList());

  List<Device> loadDevices() =>
      _readList(_kDevices).map(Device.fromJson).toList();

  Future<void> saveDevices(List<Device> devices) =>
      _writeList(_kDevices, devices.map((Device d) => d.toJson()).toList());

  List<Group> loadGroups() =>
      _readList(_kGroups).map(Group.fromJson).toList();

  Future<void> saveGroups(List<Group> groups) =>
      _writeList(_kGroups, groups.map((Group g) => g.toJson()).toList());

  List<DowntimeEvent> loadDowntimes() =>
      _readList(_kDowntimes).map(DowntimeEvent.fromJson).toList();

  Future<void> saveDowntimes(List<DowntimeEvent> events) => _writeList(
        _kDowntimes,
        events.map((DowntimeEvent e) => e.toJson()).toList(),
      );

  List<DayOverride> loadOverrides() =>
      _readList(_kOverrides).map(DayOverride.fromJson).toList();

  Future<void> saveOverrides(List<DayOverride> items) => _writeList(
        _kOverrides,
        items.map((DayOverride o) => o.toJson()).toList(),
      );

  List<ActiveDowntime> loadActiveDowntimes() => _readList(_kActive)
      .map(ActiveDowntime.fromJson)
      .whereType<ActiveDowntime>()
      .toList();

  Future<void> saveActiveDowntimes(List<ActiveDowntime> items) => _writeList(
        _kActive,
        items.map((ActiveDowntime a) => a.toJson()).toList(),
      );

  AppSettings loadSettings() {
    final String? raw = _prefs.getString(_kSettings);
    if (raw == null || raw.isEmpty) return AppSettings();
    try {
      final dynamic decoded = jsonDecode(raw);
      if (decoded is! Map) return AppSettings();
      return AppSettings.fromJson(Map<String, dynamic>.from(decoded));
    } catch (_) {
      return AppSettings();
    }
  }

  Future<void> saveSettings(AppSettings settings) =>
      _prefs.setString(_kSettings, jsonEncode(settings.toJson()));

  Future<void> clearAll() async {
    await _prefs.remove(_kUsers);
    await _prefs.remove(_kDevices);
    await _prefs.remove(_kGroups);
    await _prefs.remove(_kSettings);
    await _prefs.remove(_kDowntimes);
    await _prefs.remove(_kOverrides);
    await _prefs.remove(_kActive);
  }
}
