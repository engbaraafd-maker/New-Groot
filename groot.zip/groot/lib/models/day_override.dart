/// استثناءات يوم واحد: غياب وتبديل.
///
/// لا تمسّ المجموعات الثابتة ولا التدوير إطلاقًا؛ تُطبَّق على ترتيب ذلك
/// اليوم فقط، ويعود كل شيء لأصله في اليوم التالي.
class DayOverride {
  DayOverride({
    required this.dateKey,
    Set<String>? absentUserIds,
    List<List<String>>? swaps,
  })  : absentUserIds = absentUserIds ?? <String>{},
        swaps = swaps ?? <List<String>>[];

  /// اليوم بصيغة yyyy-MM-dd.
  final String dateKey;

  /// المستخدمون الغائبون في هذا اليوم — تُعاد حصصهم على بقية مجموعتهم.
  Set<String> absentUserIds;

  /// أزواج التبديل: كل زوج [أ، ب] يتبادلان موقعيهما في ترتيب هذا اليوم.
  List<List<String>> swaps;

  bool get isEmpty => absentUserIds.isEmpty && swaps.isEmpty;

  /// خريطة التبديل في الاتجاهين.
  Map<String, String> get swapMap {
    final Map<String, String> map = <String, String>{};
    for (final List<String> pair in swaps) {
      if (pair.length != 2) continue;
      map[pair[0]] = pair[1];
      map[pair[1]] = pair[0];
    }
    return map;
  }

  void toggleAbsent(String userId) {
    if (absentUserIds.contains(userId)) {
      absentUserIds.remove(userId);
    } else {
      absentUserIds.add(userId);
      // الغائب لا يبقى طرفًا في تبديل.
      swaps.removeWhere((List<String> p) => p.contains(userId));
    }
  }

  void addSwap(String a, String b) {
    if (a == b) return;
    swaps.removeWhere((List<String> p) => p.contains(a) || p.contains(b));
    swaps.add(<String>[a, b]);
  }

  void removeSwapOf(String userId) {
    swaps.removeWhere((List<String> p) => p.contains(userId));
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'dateKey': dateKey,
        'absent': absentUserIds.toList(),
        'swaps': swaps,
      };

  static DayOverride fromJson(Map<String, dynamic> json) {
    final List<dynamic> absent = (json['absent'] as List<dynamic>?) ?? <dynamic>[];
    final List<dynamic> raw = (json['swaps'] as List<dynamic>?) ?? <dynamic>[];
    return DayOverride(
      dateKey: (json['dateKey'] as String?) ?? '',
      absentUserIds: absent.map((dynamic e) => e as String).toSet(),
      swaps: raw
          .map((dynamic e) =>
              (e as List<dynamic>).map((dynamic x) => x as String).toList())
          .toList(),
    );
  }
}

/// عطل جارٍ الآن على جهاز — بدأ ولم ينتهِ بعد.
class ActiveDowntime {
  ActiveDowntime({
    required this.deviceId,
    required this.startedAt,
    this.description,
  });

  /// معرّف الجهاز، أو '*' لكل الأجهزة.
  final String deviceId;
  final DateTime startedAt;
  final String? description;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'deviceId': deviceId,
        'startedAt': startedAt.toIso8601String(),
        'description': description,
      };

  static ActiveDowntime? fromJson(Map<String, dynamic> json) {
    final DateTime? t = DateTime.tryParse((json['startedAt'] as String?) ?? '');
    if (t == null) return null;
    return ActiveDowntime(
      deviceId: (json['deviceId'] as String?) ?? '*',
      startedAt: t,
      description: json['description'] as String?,
    );
  }
}
