import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/time_utils.dart';
import '../models/day_override.dart';
import '../models/schedule_entry.dart';
import '../models/schedule_report.dart';
import '../services/app_repository.dart';
import 'app_scope.dart';
import 'theme.dart';
import 'widgets/common.dart';

/// اللحظة الحالية على الخط الزمني.
class _NowContext {
  const _NowContext({required this.scheduleDate, required this.nowAbsolute});

  /// يوم الجدول الذي نحن داخله (قد يكون أمس إذا كنا بعد منتصف الليل).
  final DateTime scheduleDate;

  /// اللحظة الحالية بالدقائق على الخط الزمني المطلق لذلك الجدول.
  final int nowAbsolute;
}

/// شاشة «الآن»: من يعمل على كل جهاز هذه اللحظة، وكم بقي له، ومن التالي،
/// وزر تسجيل عطل لحظيًا.
class NowScreen extends StatefulWidget {
  const NowScreen({super.key});

  @override
  State<NowScreen> createState() => _NowScreenState();
}

class _NowScreenState extends State<NowScreen> {
  Timer? _timer;
  final Set<String> _alerted = <String>{};

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 20), (Timer _) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  /// تحديد الجدول الذي نحن داخله الآن: جدول اليوم أم جدول أمس الممتد.
  _NowContext? _context(AppRepository repo) {
    final DateTime now = DateTime.now();
    final int minuteOfDay = now.hour * 60 + now.minute;
    final int start = repo.settings.period.absoluteStart;

    for (int back = 0; back <= 1; back++) {
      final DateTime date = DateTime(now.year, now.month, now.day)
          .subtract(Duration(days: back));
      final int nowAbs = back == 0
          ? (minuteOfDay >= start ? minuteOfDay : -1)
          : minuteOfDay + TimeUtils.minutesPerDay;
      if (nowAbs < start) continue;

      final ScheduleComputation c = repo.computeDay(date);
      for (final ScheduleReport r in c.reports) {
        if (nowAbs >= r.scheduleStartMinute && nowAbs < r.scheduleEndMinute) {
          return _NowContext(scheduleDate: date, nowAbsolute: nowAbs);
        }
      }
    }
    return null;
  }

  void _fireAlert(String key) {
    if (_alerted.contains(key)) return;
    _alerted.add(key);
    HapticFeedback.heavyImpact();
    SystemSound.play(SystemSoundType.alert);
  }

  @override
  Widget build(BuildContext context) {
    final AppRepository repo = AppScope.of(context);
    final _NowContext? ctx = _context(repo);

    return Scaffold(
      appBar: const GrootAppBar(title: 'الآن'),
      body: ctx == null
          ? _OutsideHours(repo: repo)
          : _buildActive(context, repo, ctx),
    );
  }

  Widget _buildActive(
      BuildContext context, AppRepository repo, _NowContext ctx) {
    final ScheduleComputation result = repo.computeDay(ctx.scheduleDate);
    final DateTime now = DateTime.now();

    return ListView(
      padding: const EdgeInsets.only(bottom: 26),
      children: <Widget>[
        SectionCard(
          title: 'الساعة ${TimeUtils.formatHm(now.hour * 60 + now.minute)}',
          icon: Icons.schedule,
          child: Text(
            '${TimeUtils.formatDateArabic(ctx.scheduleDate)}'
            '${ctx.nowAbsolute >= TimeUtils.minutesPerDay ? ' (جدول أمس الممتد)' : ''}',
            style: const TextStyle(fontSize: 15.5),
          ),
        ),
        if (result.errors.isNotEmpty)
          WarningBanner(messages: result.errors, isError: true),
        for (final ScheduleReport r in result.reports)
          _DeviceNowCard(
            report: r,
            nowAbsolute: ctx.nowAbsolute,
            scheduleDate: ctx.scheduleDate,
            onAlert: _fireAlert,
          ),
      ],
    );
  }
}

/// حالة خارج فترة العمل.
class _OutsideHours extends StatelessWidget {
  const _OutsideHours({required this.repo});

  final AppRepository repo;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    final DateTime now = DateTime.now();
    final int minuteOfDay = now.hour * 60 + now.minute;
    final int start = repo.settings.period.absoluteStart;
    final int until = minuteOfDay <= start
        ? start - minuteOfDay
        : TimeUtils.minutesPerDay - minuteOfDay + start;

    return ListView(
      children: <Widget>[
        SectionCard(
          title: 'خارج فترة العمل',
          icon: Icons.nightlight_outlined,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                'الساعة الآن ${TimeUtils.formatHm(minuteOfDay)}',
                style: const TextStyle(fontSize: 16.5),
              ),
              const SizedBox(height: 8),
              Text(
                'يبدأ التشغيل الساعة ${repo.settings.period.startLabel}'
                ' — بعد ${TimeUtils.formatDuration(until)}',
                style: TextStyle(fontSize: 16, color: scheme.primary),
              ),
              const SizedBox(height: 10),
              Text(
                'فترة العمل: ${repo.settings.period.startLabel} ← '
                '${repo.settings.period.endLabel}',
                style: TextStyle(fontSize: 14.5, color: scheme.onSurfaceVariant),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

/// بطاقة جهاز واحد في شاشة «الآن».
class _DeviceNowCard extends StatelessWidget {
  const _DeviceNowCard({
    required this.report,
    required this.nowAbsolute,
    required this.scheduleDate,
    required this.onAlert,
  });

  final ScheduleReport report;
  final int nowAbsolute;
  final DateTime scheduleDate;
  final void Function(String key) onAlert;

  @override
  Widget build(BuildContext context) {
    final AppRepository repo = AppScope.of(context);
    final ColorScheme scheme = Theme.of(context).colorScheme;

    TimelineSegment? current;
    for (final TimelineSegment s in report.timeline) {
      if (s.startMinute <= nowAbsolute && nowAbsolute < s.endMinute) {
        current = s;
        break;
      }
    }

    ScheduleEntry? entry;
    for (final ScheduleEntry e in report.entries) {
      if (e.turnStartMinute <= nowAbsolute && nowAbsolute < e.turnEndMinute) {
        entry = e;
        break;
      }
    }

    ScheduleEntry? next;
    for (final ScheduleEntry e in report.entries) {
      if (e.turnStartMinute > nowAbsolute) {
        next = e;
        break;
      }
    }

    final String deviceId = report.deviceId ?? '*';
    final ActiveDowntime? active = repo.activeDowntimeFor(deviceId);

    final int remaining =
        entry == null ? 0 : entry.turnEndMinute - nowAbsolute;
    final bool soon = entry != null && remaining <= 5;
    if (soon) {
      onAlert('${report.deviceId}_${entry.userId}_5');
    }

    final Color stateColor = current == null
        ? scheme.outline
        : GrootTheme.segmentColor(scheme, current.type.name);

    return SectionCard(
      title: report.deviceName ?? 'جهاز',
      icon: Icons.smartphone,
      trailing: Chip(
        label: Text(report.groupName ?? '',
            style: const TextStyle(fontSize: 13.5)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          if (entry == null)
            Text(
              current == null
                  ? 'لا يوجد دور جارٍ'
                  : '${current.label} — بين الدورين',
              style: TextStyle(fontSize: 17, color: stateColor),
            )
          else ...<Widget>[
            Row(
              children: <Widget>[
                Container(
                  width: 6,
                  height: 46,
                  decoration: BoxDecoration(
                    color: stateColor,
                    borderRadius: const BorderRadius.all(Radius.circular(3)),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        entry.userName,
                        style: GrootTheme.display(24, scheme.onSurface),
                      ),
                      Text(
                        current == null
                            ? 'تشغيل'
                            : (current.type == SegmentType.operating
                                ? 'تشغيل'
                                : 'الآن: ${current.label} حتى '
                                    '${TimeUtils.formatHm(current.endMinute)}'),
                        style: TextStyle(fontSize: 14.5, color: stateColor),
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    Text(
                      TimeUtils.formatDuration(remaining < 0 ? 0 : remaining),
                      style: TextStyle(
                        fontSize: 21,
                        fontWeight: FontWeight.w800,
                        color: soon ? scheme.error : scheme.primary,
                      ),
                    ),
                    Text(
                      'حتى ${entry.turnEndLabel}',
                      style: TextStyle(
                          fontSize: 13, color: scheme.onSurfaceVariant),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 10),
            ClipRRect(
              borderRadius: const BorderRadius.all(Radius.circular(6)),
              child: LinearProgressIndicator(
                value: _progress(entry),
                minHeight: 8,
                backgroundColor: scheme.outlineVariant,
                valueColor: AlwaysStoppedAnimation<Color>(
                  soon ? scheme.error : scheme.primary,
                ),
              ),
            ),
            if (soon)
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(11),
                  decoration: BoxDecoration(
                    color: scheme.errorContainer,
                    borderRadius: const BorderRadius.all(Radius.circular(12)),
                  ),
                  child: Text(
                    'التسليم قريب — ${TimeUtils.formatDuration(remaining < 0 ? 0 : remaining)}'
                    '${next == null ? '' : ' ثم يبدأ ${next.userName}'}',
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      color: scheme.onErrorContainer,
                    ),
                  ),
                ),
              ),
          ],
          const SizedBox(height: 12),
          if (next != null)
            Row(
              children: <Widget>[
                Icon(Icons.arrow_back, size: 18, color: scheme.onSurfaceVariant),
                const SizedBox(width: 7),
                Text(
                  'التالي: ${next.userName} من ${next.turnStartLabel}',
                  style: TextStyle(
                      fontSize: 15, color: scheme.onSurfaceVariant),
                ),
              ],
            ),
          const SizedBox(height: 12),
          if (active == null)
            OutlinedButton.icon(
              onPressed: () => repo.startDowntimeNow(deviceId),
              style: OutlinedButton.styleFrom(
                minimumSize: const Size.fromHeight(50),
                foregroundColor: scheme.error,
                side: BorderSide(color: scheme.error),
              ),
              icon: const Icon(Icons.warning_amber_outlined),
              label: const Text('بدأ عطل الآن'),
            )
          else
            _ActiveFault(
              active: active,
              deviceId: deviceId,
              scheduleDate: scheduleDate,
            ),
        ],
      ),
    );
  }

  double _progress(ScheduleEntry e) {
    final int span = e.turnEndMinute - e.turnStartMinute;
    if (span <= 0) return 1;
    final double v = (nowAbsolute - e.turnStartMinute) / span;
    if (v < 0) return 0;
    if (v > 1) return 1;
    return v;
  }
}

/// عطل جارٍ: عدّاد وأزرار الإنهاء والإلغاء.
class _ActiveFault extends StatelessWidget {
  const _ActiveFault({
    required this.active,
    required this.deviceId,
    required this.scheduleDate,
  });

  final ActiveDowntime active;
  final String deviceId;
  final DateTime scheduleDate;

  @override
  Widget build(BuildContext context) {
    final AppRepository repo = AppScope.of(context);
    final ColorScheme scheme = Theme.of(context).colorScheme;
    int minutes = DateTime.now().difference(active.startedAt).inMinutes;
    if (minutes < 0) minutes = 0;

    return Container(
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: scheme.errorContainer,
        borderRadius: const BorderRadius.all(Radius.circular(13)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Icon(Icons.build_circle_outlined, color: scheme.onErrorContainer),
              const SizedBox(width: 9),
              Expanded(
                child: Text(
                  'عطل جارٍ منذ '
                  '${TimeUtils.formatHm(active.startedAt.hour * 60 + active.startedAt.minute)}',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: scheme.onErrorContainer,
                  ),
                ),
              ),
              Text(
                TimeUtils.formatDuration(minutes),
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                  color: scheme.onErrorContainer,
                ),
              ),
            ],
          ),
          const SizedBox(height: 11),
          Row(
            children: <Widget>[
              Expanded(
                child: FilledButton.icon(
                  onPressed: () async {
                    await repo.endDowntimeNow(deviceId, scheduleDate);
                    if (context.mounted) {
                      showMessage(context, 'تم تسجيل العطل وإعادة توزيع الوقت.');
                    }
                  },
                  icon: const Icon(Icons.stop_circle_outlined),
                  label: const Text('إنهاء العطل'),
                ),
              ),
              const SizedBox(width: 9),
              TextButton(
                onPressed: () async {
                  final bool ok = await confirmDialog(
                    context,
                    title: 'إلغاء العطل',
                    message: 'سيتم تجاهل هذا العطل ولن يُسجَّل. متأكد؟',
                    confirmLabel: 'إلغاء العطل',
                  );
                  if (ok) await repo.cancelActiveDowntime(deviceId);
                },
                child: const Text('تجاهل'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
