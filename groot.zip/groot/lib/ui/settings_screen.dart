import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/time_utils.dart';
import '../models/app_settings.dart';
import '../models/calc_rules.dart';
import '../models/prayer_settings.dart';
import '../models/time_period.dart';
import '../services/backup_service.dart';
import '../services/prayer_times_service.dart';
import '../services/app_repository.dart';
import 'app_scope.dart';
import 'widgets/common.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final AppRepository repo = AppScope.of(context);
    final AppSettings s = repo.settings;

    return Scaffold(
      appBar: const GrootAppBar(title: 'الإعدادات'),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 30),
        children: <Widget>[
          SectionCard(
            title: 'وقت العمل',
            icon: Icons.schedule_outlined,
            child: Column(
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Expanded(
                      child: TimeField(
                        label: 'بداية العمل',
                        minuteOfDay: s.period.startMinuteOfDay,
                        onChanged: (int v) {
                          s.period = TimePeriod(
                            startMinuteOfDay: v,
                            endMinuteOfDay: s.period.endMinuteOfDay,
                          );
                          repo.saveSettings();
                        },
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: TimeField(
                        label: 'نهاية العمل',
                        minuteOfDay: s.period.endMinuteOfDay,
                        onChanged: (int v) {
                          s.period = TimePeriod(
                            startMinuteOfDay: s.period.startMinuteOfDay,
                            endMinuteOfDay: v,
                          );
                          repo.saveSettings();
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Align(
                  alignment: AlignmentDirectional.centerStart,
                  child: Text(
                    'طول الفترة: ${TimeUtils.formatDuration(s.period.lengthMinutes)}'
                    '${s.period.crossesMidnight ? ' (تعبر منتصف الليل)' : ''}',
                    style: const TextStyle(fontSize: 15.5),
                  ),
                ),
              ],
            ),
          ),
          SectionCard(
            title: 'عدد الأجهزة',
            icon: Icons.smartphone_outlined,
            child: Row(
              children: <Widget>[
                Expanded(
                  child: Text(
                    'الأجهزة: ${repo.devices.length}   •   '
                    'النشطة: ${repo.activeDevices.length}',
                    style: const TextStyle(fontSize: 16),
                  ),
                ),
                IconButton.filledTonal(
                  onPressed: repo.devices.isEmpty
                      ? null
                      : () => repo.setDeviceCount(repo.devices.length - 1),
                  icon: const Icon(Icons.remove),
                ),
                const SizedBox(width: 8),
                IconButton.filledTonal(
                  onPressed: () => repo.setDeviceCount(repo.devices.length + 1),
                  icon: const Icon(Icons.add),
                ),
              ],
            ),
          ),
          SectionCard(
            title: 'تدوير المجموعات',
            icon: Icons.rotate_left,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                const Text(
                  'الجهاز رقم j في اليوم رقم d يأخذ المجموعة رقم '
                  '((j − d) باقي قسمة عدد الأجهزة). النمط يعود لنفسه بعد عدد '
                  'أيام يساوي عدد الأجهزة. الأشخاص داخل المجموعة يدورون '
                  'تدويرًا عكسيًا: آخر عنصر يصبح الأول.',
                  style: TextStyle(fontSize: 15),
                ),
                const SizedBox(height: 10),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('تاريخ بداية الدورة (اليوم 1)'),
                  subtitle: Text(
                    TimeUtils.formatDateArabic(s.anchorDate),
                    style: const TextStyle(fontSize: 15.5),
                  ),
                  trailing: const Icon(Icons.edit_calendar_outlined),
                  onTap: () async {
                    final DateTime? picked = await showDatePicker(
                      context: context,
                      initialDate: s.anchorDate,
                      firstDate: DateTime(2020),
                      lastDate: DateTime(2100),
                    );
                    if (picked != null) {
                      s.anchorDateKey = TimeUtils.dateKey(picked);
                      await repo.saveSettings();
                    }
                  },
                ),
              ],
            ),
          ),
          const PrayerSection(),
          SectionCard(
            title: 'قواعد الحساب',
            icon: Icons.rule_outlined,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                const Text('التعامل مع التوقفات (صلاة وراحة)',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                for (final BreakPolicy p in BreakPolicy.values)
                  ChoiceTile(
                    label: CalcRulesLabels.breakPolicy(p),
                    selected: s.rules.breakPolicy == p,
                    onTap: () {
                      s.rules = s.rules.copyWith(breakPolicy: p);
                      repo.saveSettings();
                    },
                  ),
                const Divider(height: 24),
                const Text('التعامل مع الأعطال',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                for (final DowntimePolicy p in DowntimePolicy.values)
                  ChoiceTile(
                    label: CalcRulesLabels.downtime(p),
                    selected: s.rules.downtimePolicy == p,
                    onTap: () {
                      s.rules = s.rules.copyWith(downtimePolicy: p);
                      repo.saveSettings();
                    },
                  ),
                const Divider(height: 24),
                const Text('الدقائق والأشخاص الزائدون عند عدم القسمة بالتساوي',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                for (final RemainderPolicy p in RemainderPolicy.values)
                  ChoiceTile(
                    label: CalcRulesLabels.remainder(p),
                    selected: s.rules.remainderPolicy == p,
                    onTap: () {
                      s.rules = s.rules.copyWith(remainderPolicy: p);
                      repo.saveSettings();
                    },
                  ),
              ],
            ),
          ),
          SectionCard(
            title: 'المظهر',
            icon: Icons.brightness_6_outlined,
            child: Column(
              children: <Widget>[
                for (final AppThemeMode m in AppThemeMode.values)
                  ChoiceTile(
                    label: m == AppThemeMode.system
                        ? 'حسب النظام'
                        : (m == AppThemeMode.light ? 'فاتح' : 'داكن'),
                    selected: s.themeMode == m,
                    onTap: () {
                      s.themeMode = m;
                      repo.saveSettings();
                    },
                  ),
              ],
            ),
          ),
          const BackupSection(),
          SectionCard(
            title: 'البيانات',
            icon: Icons.storage_outlined,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                const Text(
                  'كل البيانات محفوظة محليًا على الجهاز ولا تحتاج إنترنت.',
                  style: TextStyle(fontSize: 15),
                ),
                const SizedBox(height: 10),
                OutlinedButton.icon(
                  onPressed: () async {
                    final bool ok = await confirmDialog(
                      context,
                      title: 'حذف كل البيانات',
                      message: 'سيتم حذف المستخدمين والأجهزة والمجموعات '
                          'والأعطال والإعدادات نهائيًا. هل أنت متأكد؟',
                      confirmLabel: 'حذف الكل',
                    );
                    if (!ok) return;
                    await repo.resetAll();
                    if (context.mounted) {
                      showMessage(context, 'تم حذف جميع البيانات.');
                    }
                  },
                  icon: const Icon(Icons.delete_forever_outlined),
                  label: const Text('حذف كل البيانات'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// قسم مواقيت الصلاة التلقائية.
class PrayerSection extends StatelessWidget {
  const PrayerSection({super.key});

  @override
  Widget build(BuildContext context) {
    final AppRepository repo = AppScope.of(context);
    final PrayerSettings ps = repo.settings.prayer;
    final DateTime today = DateTime.now();
    final PrayerTimesResult t = ps.timesFor(today);

    return SectionCard(
      title: 'مواقيت الصلاة',
      icon: Icons.mosque_outlined,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: ps.autoEnabled,
            title: const Text('حساب تلقائي حسب المدينة',
                style: TextStyle(fontSize: 16.5)),
            subtitle: const Text(
              'تُحسب فلكيًا داخل التطبيق لكل يوم، بدون إنترنت.',
              style: TextStyle(fontSize: 14),
            ),
            onChanged: (bool v) {
              ps.autoEnabled = v;
              repo.saveSettings();
            },
          ),
          if (ps.autoEnabled) ...<Widget>[
            const Divider(height: 20),
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('المدينة'),
              subtitle: Text(
                '${ps.cityName}  •  '
                '${ps.latitude.toStringAsFixed(3)}, '
                '${ps.longitude.toStringAsFixed(3)}',
                style: const TextStyle(fontSize: 15),
              ),
              trailing: const Icon(Icons.location_city_outlined),
              onTap: () async {
                final CityPreset? picked = await showDialog<CityPreset>(
                  context: context,
                  builder: (BuildContext ctx) => SimpleDialog(
                    title: const Text('اختر المدينة'),
                    children: <Widget>[
                      for (final CityPreset c in CityPreset.egypt)
                        SimpleDialogOption(
                          onPressed: () => Navigator.of(ctx).pop(c),
                          child: Text(c.name,
                              style: const TextStyle(fontSize: 17)),
                        ),
                    ],
                  ),
                );
                if (picked != null) {
                  ps.cityName = picked.name;
                  ps.latitude = picked.latitude;
                  ps.longitude = picked.longitude;
                  await repo.saveSettings();
                }
              },
            ),
            const Divider(height: 20),
            const Text('حساب العصر',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
            ChoiceTile(
              label: 'الجمهور (ظل المثل)',
              selected: ps.asrFactor == PrayerTimesService.asrFactorStandard,
              onTap: () {
                ps.asrFactor = PrayerTimesService.asrFactorStandard;
                repo.saveSettings();
              },
            ),
            ChoiceTile(
              label: 'الحنفي (ظل المثلين)',
              selected: ps.asrFactor == PrayerTimesService.asrFactorHanafi,
              onTap: () {
                ps.asrFactor = PrayerTimesService.asrFactorHanafi;
                repo.saveSettings();
              },
            ),
            const Divider(height: 20),
            const Text('مدة كل صلاة',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            Text(
              'مواقيت اليوم في ${ps.cityName}:',
              style: const TextStyle(fontSize: 14.5),
            ),
            const SizedBox(height: 6),
            for (final PrayerSlot slot in ps.slots)
              _SlotRow(slot: slot, computedMinute: t.byKey(slot.key)),
          ],
        ],
      ),
    );
  }
}

class _SlotRow extends StatelessWidget {
  const _SlotRow({required this.slot, required this.computedMinute});

  final PrayerSlot slot;
  final int computedMinute;

  @override
  Widget build(BuildContext context) {
    final AppRepository repo = AppScope.of(context);
    final ColorScheme scheme = Theme.of(context).colorScheme;
    final int resolved = slot.resolve(computedMinute);

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: <Widget>[
          Checkbox(
            value: slot.enabled,
            onChanged: (bool? v) {
              slot.enabled = v ?? false;
              repo.saveSettings();
            },
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(slot.name, style: const TextStyle(fontSize: 16)),
                Row(
                  children: <Widget>[
                    Text(
                      TimeUtils.formatHm(resolved),
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        color: slot.isAdjusted ? scheme.tertiary : scheme.primary,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      slot.modeLabel,
                      style: TextStyle(
                          fontSize: 13, color: scheme.onSurfaceVariant),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Text(
            '${slot.durationMinutes} د',
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
          ),
          IconButton(
            tooltip: 'تعديل',
            icon: const Icon(Icons.tune),
            onPressed: () => _editSlot(context, repo, slot, computedMinute),
          ),
        ],
      ),
    );
  }
}

/// حوار تعديل صلاة واحدة: الاحتساب، المدة، وطريقة تحديد الوقت.
Future<void> _editSlot(
  BuildContext context,
  AppRepository repo,
  PrayerSlot slot,
  int computedMinute,
) async {
  bool enabled = slot.enabled;
  int duration = slot.durationMinutes;
  int offset = slot.offsetMinutes;
  int? manual = slot.manualMinuteOfDay;
  // 0 = تلقائي، 1 = تلقائي مع تعديل، 2 = وقت ثابت
  int mode = manual != null ? 2 : (offset != 0 ? 1 : 0);

  final bool? saved = await showDialog<bool>(
    context: context,
    builder: (BuildContext ctx) {
      return StatefulBuilder(
        builder: (BuildContext ctx, StateSetter setState) {
          final int preview = mode == 2
              ? (manual ?? computedMinute)
              : (mode == 1 ? computedMinute + offset : computedMinute);
          final int shown = ((preview % 1440) + 1440) % 1440;

          return AlertDialog(
            title: Text(slot.name),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    'الوقت المحسوب فلكيًا: ${TimeUtils.formatHm(computedMinute)}',
                    style: const TextStyle(fontSize: 15),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'الوقت المعتمد: ${TimeUtils.formatHm(shown)}',
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const Divider(height: 20),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    value: enabled,
                    title: const Text('تُحتسب كتوقف'),
                    onChanged: (bool v) => setState(() => enabled = v),
                  ),
                  const SizedBox(height: 6),
                  const Text('المدة',
                      style: TextStyle(
                          fontSize: 15, fontWeight: FontWeight.w600)),
                  Row(
                    children: <Widget>[
                      IconButton(
                        icon: const Icon(Icons.remove_circle_outline),
                        onPressed: duration <= 0
                            ? null
                            : () => setState(
                                () => duration = (duration - 5).clamp(0, 240)),
                      ),
                      Expanded(
                        child: Text(
                          '$duration دقيقة',
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                              fontSize: 17, fontWeight: FontWeight.w700),
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.add_circle_outline),
                        onPressed: () => setState(
                            () => duration = (duration + 5).clamp(0, 240)),
                      ),
                    ],
                  ),
                  const Divider(height: 20),
                  const Text('تحديد الوقت',
                      style: TextStyle(
                          fontSize: 15, fontWeight: FontWeight.w600)),
                  ChoiceTile(
                    label: 'تلقائي (محسوب فلكيًا)',
                    selected: mode == 0,
                    onTap: () => setState(() {
                      mode = 0;
                      offset = 0;
                      manual = null;
                    }),
                  ),
                  ChoiceTile(
                    label: 'تلقائي مع تعديل بالدقائق',
                    selected: mode == 1,
                    onTap: () => setState(() {
                      mode = 1;
                      manual = null;
                    }),
                  ),
                  if (mode == 1)
                    Row(
                      children: <Widget>[
                        IconButton(
                          icon: const Icon(Icons.remove_circle_outline),
                          onPressed: () => setState(
                              () => offset = (offset - 1).clamp(-120, 120)),
                        ),
                        Expanded(
                          child: Text(
                            offset > 0 ? '+$offset دقيقة' : '$offset دقيقة',
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                                fontSize: 17, fontWeight: FontWeight.w700),
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.add_circle_outline),
                          onPressed: () => setState(
                              () => offset = (offset + 1).clamp(-120, 120)),
                        ),
                      ],
                    ),
                  ChoiceTile(
                    label: 'وقت ثابت يدوي',
                    selected: mode == 2,
                    onTap: () => setState(() {
                      mode = 2;
                      manual = manual ?? computedMinute;
                    }),
                  ),
                  if (mode == 2)
                    Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: TimeField(
                        label: 'الوقت',
                        minuteOfDay: manual ?? computedMinute,
                        onChanged: (int v) => setState(() => manual = v),
                      ),
                    ),
                  if (mode == 2)
                    const Padding(
                      padding: EdgeInsets.only(top: 6),
                      child: Text(
                        'تنبيه: الوقت الثابت لا يتغيّر مع تغيّر الفصول.',
                        style: TextStyle(fontSize: 13.5),
                      ),
                    ),
                ],
              ),
            ),
            actions: <Widget>[
              TextButton(
                onPressed: () => Navigator.of(ctx).pop(false),
                child: const Text('إلغاء'),
              ),
              FilledButton(
                onPressed: () => Navigator.of(ctx).pop(true),
                child: const Text('حفظ'),
              ),
            ],
          );
        },
      );
    },
  );

  if (saved != true) return;
  slot.enabled = enabled;
  slot.durationMinutes = duration;
  slot.offsetMinutes = mode == 1 ? offset : 0;
  slot.manualMinuteOfDay = mode == 2 ? manual : null;
  await repo.saveSettings();
}

/// نسخ احتياطي واستعادة.
class BackupSection extends StatelessWidget {
  const BackupSection({super.key});

  @override
  Widget build(BuildContext context) {
    final AppRepository repo = AppScope.of(context);

    return SectionCard(
      title: 'نسخة احتياطية',
      icon: Icons.backup_outlined,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          const Text(
            'كل بياناتك محفوظة على هذا الهاتف فقط. لو ضاع الهاتف أو مُسحت '
            'بيانات التطبيق ضاع كل شيء. انسخ النسخة الاحتياطية واحفظها في '
            'رسالة أو ملاحظة، وتستطيع استعادتها في أي وقت.',
            style: TextStyle(fontSize: 14.5),
          ),
          const SizedBox(height: 12),
          Row(
            children: <Widget>[
              Expanded(
                child: FilledButton.icon(
                  onPressed: () => _export(context, repo),
                  icon: const Icon(Icons.copy_all_outlined),
                  label: const Text('نسخ البيانات'),
                ),
              ),
              const SizedBox(width: 9),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => _import(context, repo),
                  icon: const Icon(Icons.restore),
                  label: const Text('استعادة'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Future<void> _export(BuildContext context, AppRepository repo) async {
    final String text = BackupService.export(repo);
    await Clipboard.setData(ClipboardData(text: text));
    if (!context.mounted) return;
    showMessage(context,
        'نُسخت البيانات (${text.length} حرفًا) — الصقها في مكان آمن.');
  }

  Future<void> _import(BuildContext context, AppRepository repo) async {
    final TextEditingController ctrl = TextEditingController();
    final bool? go = await showDialog<bool>(
      context: context,
      builder: (BuildContext ctx) => AlertDialog(
        title: const Text('استعادة نسخة احتياطية'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const Text(
              'الصق نص النسخة الاحتياطية هنا. سيحلّ محل كل البيانات الحالية.',
              style: TextStyle(fontSize: 14.5),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: ctrl,
              maxLines: 5,
              decoration: const InputDecoration(
                hintText: '{ "app": "groot", ... }',
                border: OutlineInputBorder(),
              ),
            ),
          ],
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('استعادة'),
          ),
        ],
      ),
    );

    if (go != true) return;
    if (!context.mounted) return;

    final bool sure = await confirmDialog(
      context,
      title: 'تأكيد الاستعادة',
      message: 'سيتم استبدال كل البيانات الحالية. لا يمكن التراجع.',
      confirmLabel: 'استبدال',
    );
    if (!sure) return;

    final RestoreResult r = BackupService.parse(ctrl.text, repo);
    if (context.mounted) {
      showMessage(context, r.message, error: !r.ok);
    }
  }
}
