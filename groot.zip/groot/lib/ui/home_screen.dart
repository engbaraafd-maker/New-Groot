import 'package:flutter/material.dart';

import '../core/time_utils.dart';
import '../services/app_repository.dart';
import 'app_scope.dart';
import 'day_schedule_screen.dart';
import 'devices_screen.dart';
import 'groups_screen.dart';
import 'now_screen.dart';
import 'settings_screen.dart';
import 'theme.dart';
import 'time_calc_screen.dart';
import 'today_order_screen.dart';
import 'users_screen.dart';
import 'widgets/common.dart';
import 'widgets/ornament.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        padding: const EdgeInsets.only(bottom: 28),
        children: <Widget>[
          const _HeroHeader(),
          const SizedBox(height: 14),
          BigMenuButton(
            label: 'الآن',
            subtitle: 'من يعمل هذه اللحظة، وكم بقي، وتسجيل عطل',
            icon: Icons.play_circle_outline,
            onTap: () => _go(context, const NowScreen()),
          ),
          BigMenuButton(
            label: 'المستخدمون',
            subtitle: 'إضافة وتعديل وحذف وإعادة ترتيب',
            icon: Icons.people_alt_outlined,
            onTap: () => _go(context, const UsersScreen()),
          ),
          BigMenuButton(
            label: 'الأجهزة',
            subtitle: 'إدارة الأجهزة وعددها',
            icon: Icons.smartphone_outlined,
            onTap: () => _go(context, const DevicesScreen()),
          ),
          BigMenuButton(
            label: 'المجموعات',
            subtitle: 'المجموعات الثابتة وإعادة التوزيع',
            icon: Icons.groups_2_outlined,
            onTap: () => _go(context, const GroupsScreen()),
          ),
          BigMenuButton(
            label: 'ترتيب اليوم',
            subtitle: 'أي مجموعة على أي جهاز، وترتيب الأشخاص',
            icon: Icons.today_outlined,
            onTap: () => _go(context, const TodayOrderScreen()),
          ),
          BigMenuButton(
            label: 'حساب الوقت',
            subtitle: 'الفترة ومواقيت الصلاة والأعطال',
            icon: Icons.calculate_outlined,
            onTap: () => _go(context, const TimeCalcScreen()),
          ),
          BigMenuButton(
            label: 'جدول اليوم',
            subtitle: 'الخط الزمني التفصيلي والتقرير',
            icon: Icons.view_timeline_outlined,
            onTap: () => _go(context, DayScheduleScreen(date: DateTime.now())),
          ),
          BigMenuButton(
            label: 'الإعدادات',
            subtitle: 'قواعد الحساب والمواقيت والمظهر',
            icon: Icons.settings_outlined,
            onTap: () => _go(context, const SettingsScreen()),
          ),
        ],
      ),
    );
  }

  void _go(BuildContext context, Widget screen) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (BuildContext _) => screen),
    );
  }
}

/// ترويسة الشاشة الرئيسية: كحلي عميق بزخرفة هندسية ذهبية.
class _HeroHeader extends StatelessWidget {
  const _HeroHeader();

  @override
  Widget build(BuildContext context) {
    final AppRepository repo = AppScope.of(context);
    final double topInset = MediaQuery.of(context).padding.top;
    final DateTime today = DateTime.now();

    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[
            GrootPalette.navyDeepest,
            GrootPalette.navy,
          ],
        ),
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(26),
          bottomRight: Radius.circular(26),
        ),
      ),
      child: ClipRRect(
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(26),
          bottomRight: Radius.circular(26),
        ),
        child: Stack(
          children: <Widget>[
            const Positioned.fill(
              child: GeometricOrnament(
                color: GrootPalette.gold,
                opacity: 0.10,
                cell: 58,
              ),
            ),
            Padding(
              padding: EdgeInsets.fromLTRB(20, topInset + 22, 20, 22),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  const Text(
                    'Groot',
                    style: TextStyle(
                      fontFamily: GrootTheme.displayFont,
                      fontSize: 42,
                      fontWeight: FontWeight.w700,
                      color: GrootPalette.goldLight,
                      letterSpacing: 5,
                    ),
                  ),
                  const SizedBox(height: 2),
                  const GoldRule(color: GrootPalette.gold, width: 130),
                  const SizedBox(height: 6),
                  const Text(
                    'إدارة المجموعات وجدولة التشغيل',
                    style: TextStyle(
                      fontSize: 15,
                      color: GrootPalette.tan,
                      letterSpacing: 0.3,
                    ),
                  ),
                  const SizedBox(height: 18),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: <Widget>[
                      _StatPill(
                        value: '${repo.users.length}',
                        label: 'مستخدم',
                      ),
                      _StatPill(
                        value: '${repo.activeDevices.length}',
                        label: 'جهاز',
                      ),
                      _StatPill(
                        value: '${repo.groups.length}',
                        label: 'مجموعة',
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Text(
                    TimeUtils.formatDateArabic(today),
                    style: const TextStyle(
                      fontSize: 14.5,
                      color: GrootPalette.tanLight,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    '${repo.settings.period.startLabel}  ←  '
                    '${repo.settings.period.endLabel}'
                    '${repo.settings.period.crossesMidnight ? '  (تعبر منتصف الليل)' : ''}',
                    style: const TextStyle(
                      fontSize: 14,
                      color: GrootPalette.tanDeep,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// رقم إحصائي صغير داخل إطار ذهبي.
class _StatPill extends StatelessWidget {
  const _StatPill({required this.value, required this.label});

  final String value;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 88,
      padding: const EdgeInsets.symmetric(vertical: 9),
      decoration: BoxDecoration(
        borderRadius: const BorderRadius.all(Radius.circular(12)),
        border: Border.all(color: GrootPalette.goldDeep, width: 1),
      ),
      child: Column(
        children: <Widget>[
          Text(
            value,
            style: const TextStyle(
              fontSize: 21,
              fontWeight: FontWeight.w800,
              color: GrootPalette.goldLight,
            ),
          ),
          const SizedBox(height: 1),
          Text(
            label,
            style: const TextStyle(fontSize: 12.5, color: GrootPalette.tan),
          ),
        ],
      ),
    );
  }
}
