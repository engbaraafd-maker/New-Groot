import 'package:flutter/material.dart';

import '../core/time_utils.dart';
import '../services/app_repository.dart';
import 'app_scope.dart';
import 'day_schedule_screen.dart';
import 'devices_screen.dart';
import 'groups_screen.dart';
import 'settings_screen.dart';
import 'time_calc_screen.dart';
import 'today_order_screen.dart';
import 'users_screen.dart';
import 'widgets/common.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final AppRepository repo = AppScope.of(context);
    final ColorScheme scheme = Theme.of(context).colorScheme;
    final DateTime today = DateTime.now();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Groot'),
        backgroundColor: scheme.primaryContainer,
        foregroundColor: scheme.onPrimaryContainer,
      ),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 24),
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  TimeUtils.formatDateArabic(today),
                  style: const TextStyle(fontSize: 17),
                ),
                const SizedBox(height: 6),
                Text(
                  'المستخدمون: ${repo.users.length}  •  '
                  'الأجهزة النشطة: ${repo.activeDevices.length}  •  '
                  'المجموعات: ${repo.groups.length}',
                  style: TextStyle(fontSize: 15, color: scheme.onSurfaceVariant),
                ),
                const SizedBox(height: 4),
                Text(
                  'فترة التشغيل: ${repo.settings.period.startLabel} ← '
                  '${repo.settings.period.endLabel}'
                  '${repo.settings.period.crossesMidnight ? ' (تعبر منتصف الليل)' : ''}',
                  style: TextStyle(fontSize: 15, color: scheme.onSurfaceVariant),
                ),
              ],
            ),
          ),
          BigMenuButton(
            label: 'المستخدمون',
            subtitle: 'إضافة وتعديل وحذف وإعادة ترتيب',
            icon: Icons.people_alt_outlined,
            onTap: () => _go(context, const UsersScreen()),
          ),
          BigMenuButton(
            label: 'الأجهزة',
            subtitle: 'إدارة الأجهزة وعددها',
            icon: Icons.smartphone_outlined,
            onTap: () => _go(context, const DevicesScreen()),
          ),
          BigMenuButton(
            label: 'المجموعات',
            subtitle: 'إنشاء المجموعات الثابتة وإعادة التوزيع',
            icon: Icons.groups_2_outlined,
            onTap: () => _go(context, const GroupsScreen()),
          ),
          BigMenuButton(
            label: 'ترتيب اليوم',
            subtitle: 'أي مجموعة على أي جهاز، وترتيب الأشخاص',
            icon: Icons.today_outlined,
            onTap: () => _go(context, const TodayOrderScreen()),
          ),
          BigMenuButton(
            label: 'حساب الوقت',
            subtitle: 'الفترة والتوقفات والأعطال',
            icon: Icons.calculate_outlined,
            onTap: () => _go(context, const TimeCalcScreen()),
          ),
          BigMenuButton(
            label: 'جدول اليوم',
            subtitle: 'الخط الزمني التفصيلي والتقرير',
            icon: Icons.view_timeline_outlined,
            onTap: () => _go(
              context,
              DayScheduleScreen(date: DateTime.now()),
            ),
          ),
          BigMenuButton(
            label: 'الإعدادات',
            subtitle: 'قواعد الحساب والتدوير والمظهر',
            icon: Icons.settings_outlined,
            onTap: () => _go(context, const SettingsScreen()),
          ),
        ],
      ),
    );
  }

  void _go(BuildContext context, Widget screen) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (BuildContext _) => screen),
    );
  }
}
