import 'package:flutter/material.dart';

/// ثيم التطبيق: بسيط، واضح، بخط كبير مناسب للشاشات الصغيرة.
///
/// مقصود أن يكون الثيم بأقل عدد ممكن من إعدادات الثيمات الفرعية،
/// حتى يبقى المشروع متوافقًا مع إصدارات Flutter المختلفة.
class GrootTheme {
  const GrootTheme._();

  static const Color seed = Color(0xFF2E7D32);

  static ThemeData light() => _base(Brightness.light);

  static ThemeData dark() => _base(Brightness.dark);

  static const TextTheme _textTheme = TextTheme(
    titleLarge: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
    titleMedium: TextStyle(fontSize: 19, fontWeight: FontWeight.w600),
    titleSmall: TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
    bodyLarge: TextStyle(fontSize: 18),
    bodyMedium: TextStyle(fontSize: 16.5),
    bodySmall: TextStyle(fontSize: 15),
    labelLarge: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
  );

  static ThemeData _base(Brightness brightness) {
    final ColorScheme scheme = ColorScheme.fromSeed(
      seedColor: seed,
      brightness: brightness,
    );
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      textTheme: _textTheme,
    );
  }

  /// شكل الأزرار الكبيرة المستخدمة في الشاشة الرئيسية.
  static ButtonStyle bigButtonStyle() => FilledButton.styleFrom(
        minimumSize: const Size.fromHeight(60),
        textStyle: const TextStyle(fontSize: 19, fontWeight: FontWeight.w700),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(18)),
        ),
      );

  static ButtonStyle mediumButtonStyle() => OutlinedButton.styleFrom(
        minimumSize: const Size.fromHeight(52),
        textStyle: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(16)),
        ),
      );

  /// ألوان مقاطع الخط الزمني.
  static Color segmentColor(ColorScheme scheme, String type) {
    switch (type) {
      case 'operating':
        return scheme.primary;
      case 'prayer':
        return const Color(0xFF00897B);
      case 'rest':
        return const Color(0xFF6D4C41);
      case 'downtime':
        return scheme.error;
      default:
        return scheme.outline;
    }
  }
}
