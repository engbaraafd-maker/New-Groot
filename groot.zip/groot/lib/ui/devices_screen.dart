import 'package:flutter/material.dart';

import '../models/device.dart';
import '../services/app_repository.dart';
import 'app_scope.dart';
import 'widgets/common.dart';

class DevicesScreen extends StatelessWidget {
  const DevicesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final AppRepository repo = AppScope.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('الأجهزة'),
        backgroundColor: Theme.of(context).colorScheme.primaryContainer,
        foregroundColor: Theme.of(context).colorScheme.onPrimaryContainer,
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _editDevice(context, repo, null),
        icon: const Icon(Icons.add),
        label: const Text('إضافة جهاز'),
      ),
      body: Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
            child: SectionCard(
              title: 'عدد الأجهزة',
              icon: Icons.tune,
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: Text(
                      'الإجمالي: ${repo.devices.length}   •   '
                      'النشطة: ${repo.activeDevices.length}',
                      style: const TextStyle(fontSize: 16.5),
                    ),
                  ),
                  IconButton.filledTonal(
                    onPressed: repo.devices.isEmpty
                        ? null
                        : () => repo.setDeviceCount(repo.devices.length - 1),
                    icon: const Icon(Icons.remove),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filledTonal(
                    onPressed: () => repo.setDeviceCount(repo.devices.length + 1),
                    icon: const Icon(Icons.add),
                  ),
                ],
              ),
            ),
          ),
          Expanded(
            child: repo.devices.isEmpty
                ? const EmptyHint(
                    message: 'لا توجد أجهزة بعد.\nأضف جهازًا واحدًا على الأقل.',
                    icon: Icons.smartphone_outlined,
                  )
                : ReorderableListView.builder(
                    padding: const EdgeInsets.only(bottom: 90, top: 6),
                    itemCount: repo.devices.length,
                    onReorder: repo.reorderDevices,
                    itemBuilder: (BuildContext context, int index) {
                      final Device d = repo.devices[index];
                      return Card(
                        key: ValueKey<String>(d.id),
                        margin: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 5),
                        shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(Radius.circular(16)),
                        ),
                        child: ListTile(
                          leading: CircleAvatar(child: Text('${index + 1}')),
                          title: Text(
                            d.name,
                            style: const TextStyle(
                                fontSize: 18, fontWeight: FontWeight.w600),
                          ),
                          subtitle: Text(d.active ? 'نشط' : 'موقوف'),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              PopupMenuButton<String>(
                                tooltip: 'خيارات',
                                onSelected: (String value) {
                                  if (value == 'edit') {
                                    _editDevice(context, repo, d);
                                  } else if (value == 'delete') {
                                    _deleteDevice(context, repo, d);
                                  } else if (value == 'toggle') {
                                    repo.updateDevice(d.id, active: !d.active);
                                  }
                                },
                                itemBuilder: (BuildContext _) =>
                                    <PopupMenuEntry<String>>[
                                  const PopupMenuItem<String>(
                                    value: 'edit',
                                    child: Text('تعديل الاسم'),
                                  ),
                                  PopupMenuItem<String>(
                                    value: 'toggle',
                                    child: Text(d.active ? 'إيقاف' : 'تفعيل'),
                                  ),
                                  const PopupMenuItem<String>(
                                    value: 'delete',
                                    child: Text('حذف'),
                                  ),
                                ],
                              ),
                              const Icon(Icons.drag_handle),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Future<void> _deleteDevice(
      BuildContext context, AppRepository repo, Device d) async {
    final bool ok = await confirmDialog(
      context,
      title: 'حذف جهاز',
      message:
          'حذف «${d.name}» يغيّر عدد الأجهزة، وبالتالي عدد المجموعات. '
          'ستحتاج إلى إعادة توزيع المجموعات. هل تريد المتابعة؟',
      confirmLabel: 'حذف',
    );
    if (!ok) return;
    await repo.deleteDevice(d.id);
  }

  Future<void> _editDevice(
      BuildContext context, AppRepository repo, Device? device) async {
    final TextEditingController ctrl = TextEditingController(
      text: device?.name ?? 'جهاز ${repo.devices.length + 1}',
    );
    final bool? saved = await showDialog<bool>(
      context: context,
      builder: (BuildContext ctx) {
        String? error;
        return StatefulBuilder(
          builder: (BuildContext ctx, StateSetter setState) {
            return AlertDialog(
              title: Text(device == null ? 'إضافة جهاز' : 'تعديل اسم الجهاز'),
              content: TextField(
                controller: ctrl,
                autofocus: true,
                decoration: InputDecoration(
                  labelText: 'اسم الجهاز',
                  errorText: error,
                  border: const OutlineInputBorder(),
                ),
              ),
              actions: <Widget>[
                TextButton(
                  onPressed: () => Navigator.of(ctx).pop(false),
                  child: const Text('إلغاء'),
                ),
                FilledButton(
                  onPressed: () {
                    if (ctrl.text.trim().isEmpty) {
                      setState(() => error = 'اسم الجهاز مطلوب.');
                      return;
                    }
                    Navigator.of(ctx).pop(true);
                  },
                  child: const Text('حفظ'),
                ),
              ],
            );
          },
        );
      },
    );
    if (saved != true) return;
    if (device == null) {
      await repo.addDevice(ctrl.text);
    } else {
      await repo.updateDevice(device.id, name: ctrl.text);
    }
  }
}
