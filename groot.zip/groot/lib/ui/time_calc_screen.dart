import 'package:flutter/material.dart';

import '../core/time_utils.dart';
import '../models/break_event.dart';
import '../models/device.dart';
import '../models/downtime_event.dart';
import '../models/prayer_settings.dart';
import '../models/time_period.dart';
import '../services/prayer_times_service.dart';
import '../services/app_repository.dart';
import 'app_scope.dart';
import 'day_schedule_screen.dart';
import 'widgets/common.dart';

/// شاشة «حساب الوقت»: الفترة + التوقفات + الأعطال ثم عرض الجدول.
class TimeCalcScreen extends StatefulWidget {
  const TimeCalcScreen({super.key, this.initialDate});

  final DateTime? initialDate;

  @override
  State<TimeCalcScreen> createState() => _TimeCalcScreenState();
}

class _TimeCalcScreenState extends State<TimeCalcScreen> {
  late DateTime _date = widget.initialDate ?? DateTime.now();

  @override
  Widget build(BuildContext context) {
    final AppRepository repo = AppScope.of(context);
    final TimePeriod period = repo.settings.period;
    final List<DowntimeEvent> dayDowntimes = repo.downtimesForDate(_date);

    return Scaffold(
      appBar: AppBar(
        title: const Text('حساب الوقت'),
        backgroundColor: Theme.of(context).colorScheme.primaryContainer,
        foregroundColor: Theme.of(context).colorScheme.onPrimaryContainer,
      ),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 100),
        children: <Widget>[
          SectionCard(
            title: 'فترة التشغيل',
            icon: Icons.timelapse_outlined,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Expanded(
                      child: TimeField(
                        label: 'وقت البداية',
                        minuteOfDay: period.startMinuteOfDay,
                        onChanged: (int v) {
                          repo.settings.period = TimePeriod(
                            startMinuteOfDay: v,
                            endMinuteOfDay: period.endMinuteOfDay,
                          );
                          repo.saveSettings();
                        },
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: TimeField(
                        label: 'وقت النهاية',
                        minuteOfDay: period.endMinuteOfDay,
                        onChanged: (int v) {
                          repo.settings.period = TimePeriod(
                            startMinuteOfDay: period.startMinuteOfDay,
                            endMinuteOfDay: v,
                          );
                          repo.saveSettings();
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Text(
                  'طول الفترة: ${TimeUtils.formatDuration(period.lengthMinutes)}'
                  '${period.crossesMidnight ? '  •  الفترة تعبر منتصف الليل، وقد '
                      'تم اعتبار وقت النهاية في اليوم التالي.' : ''}',
                  style: const TextStyle(fontSize: 15.5),
                ),
              ],
            ),
          ),
          _PrayerTimesCard(date: _date),
          SectionCard(
            title: 'توقفات يدوية إضافية (راحة وغيرها)',
            icon: Icons.mosque_outlined,
            trailing: IconButton.filledTonal(
              tooltip: 'إضافة توقف',
              icon: const Icon(Icons.add),
              onPressed: () => _editBreak(context, repo, null),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                const Text(
                  'هذه توقفات ثابتة الوقت كل يوم. الصلوات تأتي تلقائيًا من '
                  'البطاقة أعلاه ولا تحتاج إدخالًا.',
                  style: TextStyle(fontSize: 14.5),
                ),
                const SizedBox(height: 6),
                if (repo.settings.breaks.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 10),
                    child: Text('لا توجد توقفات معرّفة.',
                        style: TextStyle(fontSize: 15)),
                  ),
                for (final BreakEvent b in repo.settings.breaks)
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: Icon(
                      b.isPrayer ? Icons.mosque : Icons.local_cafe_outlined,
                    ),
                    title: Text(b.name, style: const TextStyle(fontSize: 17)),
                    subtitle: Text(
                      '${b.startLabel} • ${b.durationMinutes} دقيقة • ${b.kindLabel}',
                      style: const TextStyle(fontSize: 14.5),
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        Switch(
                          value: b.enabled,
                          onChanged: (bool v) =>
                              repo.updateBreak(b.copyWith(enabled: v)),
                        ),
                        IconButton(
                          icon: const Icon(Icons.edit_outlined),
                          onPressed: () => _editBreak(context, repo, b),
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete_outline),
                          onPressed: () => repo.deleteBreak(b.id),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
          SectionCard(
            title: 'الأعطال (وقت ضائع)',
            icon: Icons.build_circle_outlined,
            trailing: IconButton.filledTonal(
              tooltip: 'إضافة عطل',
              icon: const Icon(Icons.add),
              onPressed: () => _editDowntime(context, repo, null),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Expanded(
                      child: Text(
                        'أعطال يوم ${TimeUtils.formatDateArabic(_date)}',
                        style: const TextStyle(fontSize: 15.5),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.chevron_right),
                      onPressed: () => setState(
                          () => _date = _date.subtract(const Duration(days: 1))),
                    ),
                    IconButton(
                      icon: const Icon(Icons.chevron_left),
                      onPressed: () => setState(
                          () => _date = _date.add(const Duration(days: 1))),
                    ),
                  ],
                ),
                if (dayDowntimes.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 10),
                    child: Text('لا توجد أعطال مسجلة في هذا اليوم.',
                        style: TextStyle(fontSize: 15)),
                  ),
                for (final DowntimeEvent d in dayDowntimes)
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.warning_amber_outlined),
                    title: Text(
                      (d.description == null || d.description!.isEmpty)
                          ? 'عطل'
                          : d.description!,
                      style: const TextStyle(fontSize: 17),
                    ),
                    subtitle: Text(
                      '${d.startLabel} • ${d.durationMinutes} دقيقة • '
                      '${d.deviceId == null ? 'كل الأجهزة' : _deviceName(repo, d.deviceId!)}',
                      style: const TextStyle(fontSize: 14.5),
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        IconButton(
                          icon: const Icon(Icons.edit_outlined),
                          onPressed: () => _editDowntime(context, repo, d),
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete_outline),
                          onPressed: () => repo.deleteDowntime(d.id),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.of(context).push(
            MaterialPageRoute<void>(
              builder: (BuildContext _) => DayScheduleScreen(date: _date),
            ),
          );
        },
        icon: const Icon(Icons.play_arrow),
        label: const Text('احسب الجدول'),
      ),
    );
  }

  String _deviceName(AppRepository repo, String id) {
    for (int i = 0; i < repo.devices.length; i++) {
      if (repo.devices[i].id == id) return repo.devices[i].name;
    }
    return 'جهاز محذوف';
  }

  Future<void> _editBreak(
      BuildContext context, AppRepository repo, BreakEvent? existing) async {
    final TextEditingController nameCtrl =
        TextEditingController(text: existing?.name ?? '');
    final TextEditingController durCtrl = TextEditingController(
        text: (existing?.durationMinutes ?? 25).toString());
    int start = existing?.startMinuteOfDay ?? 15 * 60;
    BreakKind kind = existing?.kind ?? BreakKind.prayer;
    String? error;

    final bool? saved = await showDialog<bool>(
      context: context,
      builder: (BuildContext ctx) {
        return StatefulBuilder(
          builder: (BuildContext ctx, StateSetter setState) {
            return AlertDialog(
              title: Text(existing == null ? 'إضافة توقف' : 'تعديل توقف'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    TextField(
                      controller: nameCtrl,
                      decoration: InputDecoration(
                        labelText: 'الاسم (مثال: صلاة العصر)',
                        errorText: error,
                        border: const OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    SegmentedButton<BreakKind>(
                      segments: const <ButtonSegment<BreakKind>>[
                        ButtonSegment<BreakKind>(
                            value: BreakKind.prayer, label: Text('صلاة')),
                        ButtonSegment<BreakKind>(
                            value: BreakKind.rest, label: Text('راحة')),
                      ],
                      selected: <BreakKind>{kind},
                      onSelectionChanged: (Set<BreakKind> s) =>
                          setState(() => kind = s.first),
                    ),
                    const SizedBox(height: 12),
                    TimeField(
                      label: 'وقت البداية',
                      minuteOfDay: start,
                      onChanged: (int v) => setState(() => start = v),
                    ),
                    const SizedBox(height: 12),
                    MinutesField(label: 'المدة', controller: durCtrl),
                  ],
                ),
              ),
              actions: <Widget>[
                TextButton(
                  onPressed: () => Navigator.of(ctx).pop(false),
                  child: const Text('إلغاء'),
                ),
                FilledButton(
                  onPressed: () {
                    final int? dur = int.tryParse(durCtrl.text.trim());
                    if (nameCtrl.text.trim().isEmpty) {
                      setState(() => error = 'اسم التوقف مطلوب.');
                      return;
                    }
                    if (dur == null || dur <= 0) {
                      setState(() => error = 'المدة يجب أن تكون رقمًا أكبر من صفر.');
                      return;
                    }
                    Navigator.of(ctx).pop(true);
                  },
                  child: const Text('حفظ'),
                ),
              ],
            );
          },
        );
      },
    );

    if (saved != true) return;
    final int dur = int.tryParse(durCtrl.text.trim()) ?? 0;
    if (existing == null) {
      await repo.addBreak(
        BreakEvent(
          id: repo.newId('brk'),
          name: nameCtrl.text.trim(),
          kind: kind,
          startMinuteOfDay: start,
          durationMinutes: dur,
        ),
      );
    } else {
      await repo.updateBreak(
        existing.copyWith(
          name: nameCtrl.text.trim(),
          kind: kind,
          startMinuteOfDay: start,
          durationMinutes: dur,
        ),
      );
    }
  }

  Future<void> _editDowntime(
      BuildContext context, AppRepository repo, DowntimeEvent? existing) async {
    final TextEditingController descCtrl =
        TextEditingController(text: existing?.description ?? '');
    final TextEditingController durCtrl = TextEditingController(
        text: (existing?.durationMinutes ?? 20).toString());
    int start = existing?.startMinuteOfDay ?? repo.settings.period.startMinuteOfDay;
    String? deviceId = existing?.deviceId;
    String? error;

    final bool? saved = await showDialog<bool>(
      context: context,
      builder: (BuildContext ctx) {
        return StatefulBuilder(
          builder: (BuildContext ctx, StateSetter setState) {
            return AlertDialog(
              title: Text(existing == null ? 'إضافة عطل' : 'تعديل عطل'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    TextField(
                      controller: descCtrl,
                      decoration: InputDecoration(
                        labelText: 'الوصف (اختياري)',
                        errorText: error,
                        border: const OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TimeField(
                      label: 'وقت بداية العطل',
                      minuteOfDay: start,
                      onChanged: (int v) => setState(() => start = v),
                    ),
                    const SizedBox(height: 12),
                    MinutesField(label: 'المدة', controller: durCtrl),
                    const SizedBox(height: 12),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('الجهاز', style: TextStyle(fontSize: 14)),
                      subtitle: Text(
                        deviceId == null
                            ? 'كل الأجهزة'
                            : _deviceName(repo, deviceId!),
                        style: const TextStyle(
                            fontSize: 17, fontWeight: FontWeight.w600),
                      ),
                      trailing: const Icon(Icons.arrow_drop_down),
                      onTap: () async {
                        final String? picked = await showDialog<String>(
                          context: ctx,
                          builder: (BuildContext dctx) => SimpleDialog(
                            title: const Text('اختر الجهاز'),
                            children: <Widget>[
                              SimpleDialogOption(
                                onPressed: () => Navigator.of(dctx).pop('__all__'),
                                child: const Text('كل الأجهزة'),
                              ),
                              for (final Device d in repo.devices)
                                SimpleDialogOption(
                                  onPressed: () => Navigator.of(dctx).pop(d.id),
                                  child: Text(d.name),
                                ),
                            ],
                          ),
                        );
                        if (picked != null) {
                          setState(() {
                            deviceId = picked == '__all__' ? null : picked;
                          });
                        }
                      },
                    ),
                  ],
                ),
              ),
              actions: <Widget>[
                TextButton(
                  onPressed: () => Navigator.of(ctx).pop(false),
                  child: const Text('إلغاء'),
                ),
                FilledButton(
                  onPressed: () {
                    final int? dur = int.tryParse(durCtrl.text.trim());
                    if (dur == null || dur <= 0) {
                      setState(() =>
                          error = 'مدة العطل يجب أن تكون رقمًا أكبر من صفر.');
                      return;
                    }
                    Navigator.of(ctx).pop(true);
                  },
                  child: const Text('حفظ'),
                ),
              ],
            );
          },
        );
      },
    );

    if (saved != true) return;
    final int dur = int.tryParse(durCtrl.text.trim()) ?? 0;
    if (existing == null) {
      await repo.addDowntime(
        DowntimeEvent(
          id: repo.newId('dwn'),
          dateKey: TimeUtils.dateKey(_date),
          startMinuteOfDay: start,
          durationMinutes: dur,
          description: descCtrl.text.trim(),
          deviceId: deviceId,
        ),
      );
    } else {
      await repo.updateDowntime(
        DowntimeEvent(
          id: existing.id,
          dateKey: existing.dateKey,
          startMinuteOfDay: start,
          durationMinutes: dur,
          description: descCtrl.text.trim(),
          deviceId: deviceId,
        ),
      );
    }
  }
}

/// بطاقة تعرض مواقيت الصلاة المحسوبة تلقائيًا لليوم المختار.
class _PrayerTimesCard extends StatelessWidget {
  const _PrayerTimesCard({required this.date});

  final DateTime date;

  @override
  Widget build(BuildContext context) {
    final AppRepository repo = AppScope.of(context);
    final PrayerSettings ps = repo.settings.prayer;

    if (!ps.autoEnabled) {
      return const SectionCard(
        title: 'مواقيت الصلاة',
        icon: Icons.mosque_outlined,
        child: Text(
          'المواقيت التلقائية موقوفة. فعّلها من شاشة الإعدادات، أو أضف '
          'الصلوات يدويًا بالأسفل.',
          style: TextStyle(fontSize: 15),
        ),
      );
    }

    final PrayerTimesResult t = repo.prayerTimesFor(date);
    return SectionCard(
      title: 'مواقيت الصلاة — ${ps.cityName}',
      icon: Icons.mosque_outlined,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            'محسوبة تلقائيًا ليوم ${TimeUtils.formatDateArabic(date)} '
            'بدون إنترنت، وتتغيّر يوميًا بنفسها.',
            style: const TextStyle(fontSize: 14.5),
          ),
          const SizedBox(height: 8),
          for (final PrayerSlot slot in ps.slots)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 3),
              child: Row(
                children: <Widget>[
                  Icon(
                    slot.enabled
                        ? Icons.check_circle_outline
                        : Icons.remove_circle_outline,
                    size: 20,
                    color: slot.enabled
                        ? Theme.of(context).colorScheme.primary
                        : Theme.of(context).colorScheme.outline,
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(slot.name, style: const TextStyle(fontSize: 16)),
                  ),
                  Text(
                    TimeUtils.formatHm(ps.resolvedMinute(slot, t)),
                    style: const TextStyle(
                        fontSize: 17, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    slot.enabled
                        ? '${slot.durationMinutes} د'
                        : 'غير محتسب',
                    style: const TextStyle(fontSize: 14.5),
                  ),
                  if (slot.isAdjusted)
                    const Padding(
                      padding: EdgeInsets.only(right: 6),
                      child: Icon(Icons.edit_outlined, size: 16),
                    ),
                ],
              ),
            ),
          const SizedBox(height: 6),
          Text(
            'الشروق ${TimeUtils.formatHm(t.sunrise)}',
            style: TextStyle(
                fontSize: 14,
                color: Theme.of(context).colorScheme.onSurfaceVariant),
          ),
        ],
      ),
    );
  }
}
